/**********************************************************************
Copyright (c) 2004 Kikuchi Kousuke and others. All rights reserved.
Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.

Contributors:
    ...
**********************************************************************/
package org.datanucleus.enhancer.bcel.method;

import org.apache.bcel.Constants;
import org.apache.bcel.generic.InstructionConstants;
import org.apache.bcel.generic.InstructionHandle;
import org.apache.bcel.generic.Type;
import org.datanucleus.enhancer.ClassEnhancer;
import org.datanucleus.enhancer.bcel.BCELClassEnhancer;
import org.datanucleus.enhancer.bcel.BCELClassMethod;

/**
 * create jdoNewInstance method.
 * @version $Revision: 1.3 $
 */
public class JdoNewInstance1 extends BCELClassMethod
{
    /**
     * @param methodName
     * @param type
     * @param resultType
     * @param argType
     * @param argName
     * @param synthetic
     * @param gen
     */
    public JdoNewInstance1(
        String methodName,
        int type,
        Type resultType,
        Type[] argType,
        String[] argName,
        boolean synthetic,
        BCELClassEnhancer gen)
    {
        super(methodName, type, resultType, argType, argName, synthetic, gen);
    }

    public static JdoNewInstance1 getInstance(BCELClassEnhancer gen)
    {
        return new JdoNewInstance1(
            "jdoNewInstance",
            Constants.ACC_PUBLIC,
            BCELClassEnhancer.OT_PersistenceCapable,
            new Type[] { BCELClassEnhancer.OT_StateManager },
            new String[] { "sm" },
            false,
            gen);
    }

    /* (non-Javadoc)
     * @see org.datanucleus.enhancer.gen.Callback#execute()
     */
    public void execute()
    {
        if (classGen.getJavaClass().isAbstract())
        {
            createThrowException(ClassEnhancer.CN_JDOFatalInternalException, "Cannot instantiate abstract class.");            
            il.append(InstructionConstants.RETURN);
        }
        else
        {
            InstructionHandle lv_result[] = new InstructionHandle[2];
    
            lv_result[0] = il.append(factory.createNew(getClassEnhancer().classType));
            il.append(InstructionConstants.DUP);
            il.append(
                factory.createInvoke(
                    className,
                    Constants.CONSTRUCTOR_NAME,
                    Type.VOID,
                    Type.NO_ARGS,
                    Constants.INVOKESPECIAL));
            il.append(InstructionConstants.ASTORE_2);
            il.append(InstructionConstants.ALOAD_2);
            il.append(InstructionConstants.DUP);
            il.append(InstructionConstants.DUP);
            il.append(InstructionConstants.ICONST_1);
            il.append(factory.createPutField(className, ClassEnhancer.FN_Flag, Type.BYTE));
            il.append(InstructionConstants.ALOAD_1);
            il.append(
                factory.createPutField(
                    className,
                    ClassEnhancer.FN_StateManager,
                    BCELClassEnhancer.OT_StateManager));
    
            lv_result[1] = il.append(InstructionConstants.ARETURN);
            methodGen.addLocalVariable("result", getClassEnhancer().classType, lv_result[0], lv_result[1]);
        }
    }
}
