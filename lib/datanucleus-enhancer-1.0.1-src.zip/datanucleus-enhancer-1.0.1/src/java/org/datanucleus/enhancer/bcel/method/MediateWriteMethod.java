/**********************************************************************
Copyright (c) 2004 Kikuchi Kousuke and others. All rights reserved.
Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
 

Contributors:
2005 Andy Jefferson - changed to use "detachedState"
    ...
**********************************************************************/
package org.datanucleus.enhancer.bcel.method;

import org.apache.bcel.Constants;
import org.apache.bcel.generic.BranchInstruction;
import org.apache.bcel.generic.GOTO;
import org.apache.bcel.generic.IFNONNULL;
import org.apache.bcel.generic.IF_ICMPEQ;
import org.apache.bcel.generic.InstructionConstants;
import org.apache.bcel.generic.InstructionFactory;
import org.apache.bcel.generic.InstructionHandle;
import org.apache.bcel.generic.Type;
import org.datanucleus.enhancer.ClassEnhancer;
import org.datanucleus.enhancer.bcel.BCELClassEnhancer;
import org.datanucleus.enhancer.bcel.BCELClassMethod;
import org.datanucleus.enhancer.bcel.BCELUtils;
import org.datanucleus.enhancer.bcel.metadata.BCELFieldPropertyMetaData;
import org.datanucleus.enhancer.bcel.metadata.BCELMember;

/**
 * @version $Revision: 1.7 $
 */
public class MediateWriteMethod extends BCELClassMethod
{
    /** target field */
    protected BCELFieldPropertyMetaData fieldConfig;

    /**
     * Constructor.
     * @param methodName method name
     * @param type method modifier
     * @param resultType return type
     * @param argType argment types
     * @param argName argment names
     * @param synthetic synthetic flag
     * @param gen target class generator
     * @param fieldConfig target field.
     */
    public MediateWriteMethod(
        String methodName,
        int type,
        Type resultType,
        Type[] argType,
        String[] argName,
        boolean synthetic,
        BCELClassEnhancer gen,
        BCELFieldPropertyMetaData fieldConfig)
    {
        super(methodName, type, resultType, argType, argName, synthetic, gen);

        this.fieldConfig = fieldConfig;
    }

    public void execute()
    {
        BCELMember targetField = fieldConfig.getEnhanceField();
        Type smType = BCELUtils.getJDOMethodType(targetField.getType());
        Type nativeType = targetField.getType();
        String fieldName = targetField.getName();
        InstructionHandle last;
        GOTO go[] = new GOTO[2];
        go[0] = new GOTO(null);
        go[1] = new GOTO(null);
        il.append(InstructionConstants.ALOAD_0);
        il.append(factory.createGetField(className, ClassEnhancer.FN_StateManager, BCELClassEnhancer.OT_StateManager));
        BranchInstruction hasStateManager = new IFNONNULL(null);
        il.append(hasStateManager);
        il.append(InstructionConstants.ALOAD_0);
        il.append(InstructionFactory.createLoad((Type)argTypes[1], 1));
        il.append(factory.createPutField(className, fieldName, (Type)argTypes[1]));
        il.append(go[0]);

        hasStateManager.setTarget(il.append(InstructionConstants.ALOAD_0));
        il.append(factory.createGetField(className, ClassEnhancer.FN_StateManager, BCELClassEnhancer.OT_StateManager));
        il.append(InstructionConstants.ALOAD_0);
        il.append(BCELUtils.getBIPUSH(fieldConfig.getFieldId()));
        if (cmd.getPersistenceCapableSuperclass() != null)
        {
            il.append(factory.createGetStatic(className, ClassEnhancer.FN_JdoInheritedFieldCount, Type.INT));
            il.append(InstructionConstants.IADD);
        }
        il.append(InstructionConstants.ALOAD_0);
        il.append(factory.createGetField(className, fieldName, nativeType));
        il.append(InstructionFactory.createLoad(nativeType, 1));
        il.append(factory.createInvoke(ClassEnhancer.CN_StateManager, "set" + BCELUtils.getJDOMethodName(smType) + "Field", 
            Type.VOID, new Type[]{BCELClassEnhancer.OT_PersistenceCapable, Type.INT, smType, smType}, Constants.INVOKEINTERFACE));
        il.append(go[1]);

        //----detach------
        if (cmd.isDetachable())
        {
            // jdoIsDetached()
            last = il.append(InstructionConstants.ALOAD_0);
            il.append(factory.createInvoke(ClassEnhancer.CN_PersistenceCapable, ClassEnhancer.MN_JdoIsDetached, 
                Type.BOOLEAN, Type.NO_ARGS, Constants.INVOKEINTERFACE));

            // 1
            il.append(InstructionConstants.ICONST_1);
            // if (jdoIsDetached() == 1)
            IF_ICMPEQ ifIsDetached = new IF_ICMPEQ(null);
            il.append(ifIsDetached);
            // return;
            il.append(InstructionConstants.RETURN);

            // ((BitSet)jdoDetachedState[3]).set(?)
            //   jdoDetachedState[3]
            ifIsDetached.setTarget(il.append(InstructionConstants.ALOAD_0));
            il.append(factory.createGetField(className, ClassEnhancer.FN_JdoDetachedState, BCELClassEnhancer.OT_ObjectArray));
            il.append(InstructionConstants.ICONST_3);
            il.append(InstructionConstants.AALOAD);
            il.append(factory.createCheckCast(BCELClassEnhancer.OT_BitSet)); // Cast to BitSet

            //   the field index: 0, 1, 2...
            il.append(BCELUtils.getBIPUSH(fieldConfig.getFieldId()));
            if (cmd.getPersistenceCapableSuperclass() != null)
            {
                // add to field index the parentFieldCount
                il.append(factory.createGetStatic(className, ClassEnhancer.FN_JdoInheritedFieldCount, Type.INT));
                il.append(InstructionConstants.IADD);
            }
            //   set(?)
            il.append(factory.createInvoke(ClassEnhancer.CN_BitSet, "set", Type.VOID, new Type[]{Type.INT}, Constants.INVOKEVIRTUAL));
            //----detach------

            il.append(InstructionConstants.RETURN);
            go[0].setTarget(last);
            go[1].setTarget(last);
            methodGen.setInstructionList(il);
        }
        else
        {
            last = il.append(InstructionConstants.RETURN);
            go[0].setTarget(last);
            go[1].setTarget(last);
            methodGen.setInstructionList(il);
        }
    }
}