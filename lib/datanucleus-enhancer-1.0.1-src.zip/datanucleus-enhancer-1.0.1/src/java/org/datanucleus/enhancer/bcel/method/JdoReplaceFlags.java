/**********************************************************************
Copyright (c) 2004 Kikuchi Kousuke and others. All rights reserved.
Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.

Contributors:
    ...
**********************************************************************/
package org.datanucleus.enhancer.bcel.method;


import org.apache.bcel.Constants;
import org.apache.bcel.generic.*;
import org.datanucleus.enhancer.ClassEnhancer;
import org.datanucleus.enhancer.bcel.BCELClassEnhancer;
import org.datanucleus.enhancer.bcel.BCELClassMethod;

/**
 * create jdoReplaceFlags method.
 * @version $Revision: 1.3 $
 */
public class JdoReplaceFlags extends BCELClassMethod
{
    /**
     * @param methodName
     * @param type
     * @param resultType
     * @param argType
     * @param argName
     * @param synthetic
     * @param gen
     */
    public JdoReplaceFlags(
        String methodName,
        int type,
        Type resultType,
        Type[] argType,
        String[] argName,
        boolean synthetic,
        BCELClassEnhancer gen)
    {
        super(methodName, type, resultType, argType, argName, synthetic, gen);
    }

    public static JdoReplaceFlags getInstance(BCELClassEnhancer gen)
    {
        return new JdoReplaceFlags(
            "jdoReplaceFlags",
            Constants.ACC_PUBLIC | Constants.ACC_FINAL,
            Type.VOID,
            Type.NO_ARGS,
            null,
            false,
            gen);
    }

    /* (non-Javadoc)
     * @see org.datanucleus.enhancer.gen.Callback#execute()
     */
    public void execute() 
    {
        il.append(InstructionConstants.ALOAD_0);
        il.append(
            factory.createGetField(
                className,
                ClassEnhancer.FN_StateManager,
                BCELClassEnhancer.OT_StateManager));
        IFNULL ifnull = new IFNULL(null);
        il.append(ifnull);

        il.append(InstructionConstants.ALOAD_0);
        il.append(InstructionConstants.DUP);
        il.append(
            factory.createGetField(
                className,
                ClassEnhancer.FN_StateManager,
                BCELClassEnhancer.OT_StateManager));
        il.append(InstructionConstants.ALOAD_0);
        il.append(
            factory.createInvoke(
                ClassEnhancer.CN_StateManager,
                "replacingFlags",
                Type.BYTE,
                new Type[] { BCELClassEnhancer.OT_PersistenceCapable },
                Constants.INVOKEINTERFACE));
        il.append(factory.createPutField(className, ClassEnhancer.FN_Flag, Type.BYTE));

        InstructionHandle ifnullTarget = il.append(InstructionConstants.RETURN);
        ifnull.setTarget(ifnullTarget);
    }
}
