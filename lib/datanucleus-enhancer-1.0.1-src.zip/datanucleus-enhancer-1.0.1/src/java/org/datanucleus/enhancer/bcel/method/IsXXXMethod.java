/**********************************************************************
Copyright (c) 2004 Kikuchi Kousuke and others. All rights reserved.
Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
 

Contributors:
    ...
**********************************************************************/
package org.datanucleus.enhancer.bcel.method;


import org.apache.bcel.Constants;
import org.apache.bcel.generic.*;
import org.datanucleus.enhancer.ClassEnhancer;
import org.datanucleus.enhancer.bcel.BCELClassEnhancer;
import org.datanucleus.enhancer.bcel.BCELClassMethod;

/**
 * Create jdoIsNew and jdoIsDirty methods in base class.
 * @version $Revision: 1.3 $
 */
public class IsXXXMethod extends BCELClassMethod
{
    protected String invokeMethodName;
    /**
     * @param methodName Name of the method
     * @param type Type
     * @param resultType Type of result from method
     * @param argType Argument types
     * @param argName Argument names
     * @param synthetic Whether synthetic or not
     * @param gen Generator base
     * @param invokeMethodName Method name to invoke
     */
    public IsXXXMethod(
        String methodName,
        int type,
        Type resultType,
        Type[] argType,
        String[] argName,
        boolean synthetic,
        BCELClassEnhancer gen,
        String invokeMethodName)
    {
        super(methodName, type, resultType, argType, argName, synthetic, gen);
        this.invokeMethodName = invokeMethodName;
    }

    /* (non-Javadoc)
     * @see org.datanucleus.enhancer.gen.Callback#execute()
     */
    public void execute()
    {
        il.append(InstructionConstants.ALOAD_0);
        il.append(
            factory.createGetField(
                className,
                ClassEnhancer.FN_StateManager,
                BCELClassEnhancer.OT_StateManager));
        IFNULL ifnull = new IFNULL(null);
        il.append(ifnull);
        il.append(InstructionConstants.ALOAD_0);
        il.append(
            factory.createGetField(
                className,
                ClassEnhancer.FN_StateManager,
                BCELClassEnhancer.OT_StateManager));
        il.append(InstructionConstants.ALOAD_0);
        il.append(
            factory.createInvoke(
                ClassEnhancer.CN_StateManager,
                invokeMethodName,
                Type.BOOLEAN,
                new Type[] { BCELClassEnhancer.OT_PersistenceCapable },
                Constants.INVOKEINTERFACE));
        GOTO go = new GOTO(null);
        il.append(go);
        InstructionHandle ifnullTarget = il.append(InstructionConstants.ICONST_0);
        InstructionHandle gotoTarget = il.append(InstructionConstants.IRETURN);
        ifnull.setTarget(ifnullTarget);
        go.setTarget(gotoTarget);
    }
}
