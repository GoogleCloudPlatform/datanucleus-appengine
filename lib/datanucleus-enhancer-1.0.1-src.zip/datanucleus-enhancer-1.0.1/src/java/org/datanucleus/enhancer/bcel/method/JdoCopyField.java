/**********************************************************************
Copyright (c) 2004 Kikuchi Kousuke and others. All rights reserved.
Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.

Contributors:
    Andy Jefferson - fix so that if we have no fields, pass to superclass
    ...
**********************************************************************/
package org.datanucleus.enhancer.bcel.method;

import org.apache.bcel.Constants;
import org.apache.bcel.generic.BranchInstruction;
import org.apache.bcel.generic.GOTO;
import org.apache.bcel.generic.InstructionConstants;
import org.apache.bcel.generic.InstructionHandle;
import org.apache.bcel.generic.ObjectType;
import org.apache.bcel.generic.TABLESWITCH;
import org.apache.bcel.generic.Type;
import org.datanucleus.enhancer.ClassEnhancer;
import org.datanucleus.enhancer.bcel.BCELClassEnhancer;
import org.datanucleus.enhancer.bcel.BCELClassMethod;
import org.datanucleus.enhancer.bcel.BCELUtils;
import org.datanucleus.enhancer.bcel.metadata.BCELFieldPropertyMetaData;
import org.datanucleus.enhancer.bcel.metadata.BCELMember;
import org.datanucleus.metadata.AbstractMemberMetaData;
import org.datanucleus.util.ClassUtils;

/**
 * create jdoCopyField method.
 * @version $Revision: 1.12 $
 */
public class JdoCopyField extends BCELClassMethod
{
    /**
     * @param methodName
     * @param type
     * @param resultType
     * @param argType
     * @param argName
     * @param synthetic
     * @param gen
     */
    public JdoCopyField(
        String methodName,
        int type,
        Type resultType,
        Type[] argType,
        String[] argName,
        boolean synthetic,
        BCELClassEnhancer gen)
    {
        super(methodName, type, resultType, argType, argName, synthetic, gen);
    }

    /**
     * create instance.
     * @param gen generator
     * @return JdoCopyField instance
     */
    public static JdoCopyField getInstance(BCELClassEnhancer gen)
    {
        return new JdoCopyField(
            "jdoCopyField",
            Constants.ACC_PROTECTED | Constants.ACC_FINAL,
            Type.VOID,
            new Type[] { gen.classType, Type.INT },
            new String[] { "obj", "index" },
            true,
            gen);
    }

    /* (non-Javadoc)
     * @see org.datanucleus.enhancer.gen.Callback#execute()
     */
    public void execute()
    {
        AbstractMemberMetaData targetFields[] = cmd.getManagedMembers();

        // We have no fields so pass up to superclass if possible
        if ((targetFields == null) || (targetFields.length == 0))
        {
            if (cmd.getPersistenceCapableSuperclass() != null)
            {
                ObjectType pcscType = new ObjectType(cmd.getPersistenceCapableSuperclass());
                il.append(InstructionConstants.ALOAD_0);
                il.append(InstructionConstants.ALOAD_1);
                il.append(InstructionConstants.ILOAD_2);
                il.append(factory.createInvoke(
                    cmd.getPersistenceCapableSuperclass(),
                    methodGen.getName(),
                    Type.VOID,
                    new Type[] { pcscType, Type.INT },
                    Constants.INVOKESPECIAL));
            }
            il.append(InstructionConstants.RETURN);
            return;
        }

        // Create "switch" statement to handle our own fields here, and pass
        // all others up to superclasses
        InstructionHandle swichBlock;
        InstructionHandle switchTable[] = new InstructionHandle[targetFields.length];
        InstructionHandle swichDefaultBlock;
        InstructionHandle last;
        BranchInstruction gotoLast[] = new BranchInstruction[targetFields.length];
        int fieldIndexes[] = new int[targetFields.length];
        for (int i = 0; i < targetFields.length; i++)
        {
            fieldIndexes[i] = i;
        }
        il.append(InstructionConstants.ILOAD_2);
        if (cmd.getPersistenceCapableSuperclass() != null)
        {
            il.append(
                factory.createGetStatic(className, ClassEnhancer.FN_JdoInheritedFieldCount, Type.INT));
            il.append(InstructionConstants.ISUB);
        }
        swichBlock = il.append(InstructionConstants.NOP);
        for (int i = 0; i < targetFields.length; i++)
        {
            switchTable[i] = il.append(InstructionConstants.ALOAD_0);
            il.append(InstructionConstants.ALOAD_1);
            BCELMember field = ((BCELFieldPropertyMetaData)targetFields[i]).getEnhanceField();
            if (!targetFields[i].isProperty())
            {
                // fieldName = obj.fieldName
                il.append(
                    factory.createGetField(
                        className,
                        targetFields[i].getName(),
                        field.getType()));
                il.append(
                    factory.createPutField(
                        className,
                        targetFields[i].getName(),
                        field.getType()));
            }
            else
            {
                //setFieldName(obj.getFieldName());
                
                String fieldName = ClassUtils.getFieldNameForJavaBeanGetter(field.getName());
                il.append(factory.createInvoke(
                    className,
                    "jdo"+BCELUtils.getGetterName(fieldName),
                    field.getType(),
                    new Type[] {},
                    Constants.INVOKEVIRTUAL));

                il.append(factory.createInvoke(
                    className,
                    "jdo"+BCELUtils.getSetterName(fieldName),
                    Type.VOID,
                    new Type[] { field.getType() },
                    Constants.INVOKEVIRTUAL));
            }
            gotoLast[i] = new GOTO(null);
            il.append(gotoLast[i]);
        }
        if (cmd.getPersistenceCapableSuperclass() == null)
        {
            swichDefaultBlock =
                createThrowException(
                    ClassEnhancer.CN_IllegalArgumentException,
                    "out of field index :",
                    InstructionConstants.ILOAD_2);
        }
        else
        {
            ObjectType pcscType = new ObjectType(cmd.getPersistenceCapableSuperclass());
            swichDefaultBlock = il.append(InstructionConstants.ALOAD_0);
            il.append(InstructionConstants.ALOAD_1);
            il.append(InstructionConstants.ILOAD_2);
            il.append(
                factory.createInvoke(
                    cmd.getPersistenceCapableSuperclass(),
                    methodGen.getName(),
                    Type.VOID,
                    new Type[] { pcscType, Type.INT },
                    Constants.INVOKESPECIAL));

        }
        TABLESWITCH switchInstruction =
            new TABLESWITCH(fieldIndexes, switchTable, swichDefaultBlock);
        il.insert(swichBlock, switchInstruction);
        last = il.append(InstructionConstants.RETURN);
        for (int i = 0; i < gotoLast.length; i++)
        {
            gotoLast[i].setTarget(last);
        }
    }
}
