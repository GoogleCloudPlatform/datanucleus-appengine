/**********************************************************************
Copyright (c) 2004 Kikuchi Kousuke and others. All rights reserved.
Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.

Contributors:
    ...
**********************************************************************/
package org.datanucleus.enhancer.bcel.method;

import org.apache.bcel.Constants;
import org.apache.bcel.generic.InstructionConstants;
import org.apache.bcel.generic.LDC;
import org.apache.bcel.generic.Type;
import org.datanucleus.enhancer.ClassEnhancer;
import org.datanucleus.enhancer.bcel.BCELClassEnhancer;
import org.datanucleus.enhancer.bcel.BCELClassMethod;

/**
 * Create persistenceCapableSuperclass init method.
 * @version $Revision: 1.4 $
 */
public class InitPersistenceCapableSuperClass extends BCELClassMethod
{
    /**
     * @param methodName
     * @param type
     * @param resultType
     * @param argType
     * @param argName
     * @param synthetic
     * @param gen
     */
    public InitPersistenceCapableSuperClass(
        String methodName,
        int type,
        Type resultType,
        Type[] argType,
        String[] argName,
        boolean synthetic,
        BCELClassEnhancer gen)
    {
        super(methodName, type, resultType, argType, argName, synthetic, gen);
    }

    /**
     * Create and return instance of this class.
     * @param gen target class generator
     * @return instance of this class
     */
    public static InitPersistenceCapableSuperClass getInstance(BCELClassEnhancer gen)
    {
        return new InitPersistenceCapableSuperClass(
            ClassEnhancer.MN_JdoPersistenceCapableSuperclassInit,
            Constants.ACC_PRIVATE | Constants.ACC_STATIC,
            BCELClassEnhancer.OT_CLASS,
            Type.NO_ARGS,
            null,
            true,
            gen);
    }

    /* (non-Javadoc)
     * @see org.datanucleus.enhancer.gen.Callback#execute()
     */
    public void execute()
    {
        String ppsc = cmd.getPersistenceCapableSuperclass();
        if ((ppsc == null) || (ppsc.length() == 0))
        {
            super.execute();
            return;
        }
        il.append(new LDC(constantPoolGen.addString(ppsc)));
        il.append(
            factory.createInvoke(
                className,
                ClassEnhancer.MN_jdoLoadClass,
                BCELClassEnhancer.OT_CLASS,
                new Type[] { Type.STRING },
                Constants.INVOKESTATIC));
        il.append(InstructionConstants.ARETURN);
    }
}
