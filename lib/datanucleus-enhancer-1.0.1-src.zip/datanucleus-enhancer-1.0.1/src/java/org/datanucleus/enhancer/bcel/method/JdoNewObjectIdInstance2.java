/**********************************************************************
Copyright (c) 2004 Kikuchi Kousuke and others. All rights reserved.
Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
 

Contributors:
2004 Erik Bengtson - added SingleField handling
2004 Andy Jefferson - fixed the SingleFieldIdentity version
2005 Andy Jefferson - changed to take Object argument
    ...
**********************************************************************/
package org.datanucleus.enhancer.bcel.method;

import org.apache.bcel.Constants;
import org.apache.bcel.generic.BranchInstruction;
import org.apache.bcel.generic.IFNONNULL;
import org.apache.bcel.generic.IF_ICMPEQ;
import org.apache.bcel.generic.InstructionConstants;
import org.apache.bcel.generic.InstructionFactory;
import org.apache.bcel.generic.ObjectType;
import org.apache.bcel.generic.Type;
import org.datanucleus.enhancer.ClassEnhancer;
import org.datanucleus.enhancer.bcel.BCELClassEnhancer;
import org.datanucleus.enhancer.bcel.BCELClassMethod;

/**
 * Create the jdoNewObjectIdInstance(Object) method.
 * 
 * @version $Revision: 1.5 $
 */
public class JdoNewObjectIdInstance2 extends BCELClassMethod
{
    /**
     * @param methodName
     * @param type
     * @param resultType
     * @param argType
     * @param argName
     * @param synthetic
     * @param gen
     */
    public JdoNewObjectIdInstance2(
        String methodName,
        int type,
        Type resultType,
        Type[] argType,
        String[] argName,
        boolean synthetic,
        BCELClassEnhancer gen)
    {
        super(methodName, type, resultType, argType, argName, synthetic, gen);
    }

    public static JdoNewObjectIdInstance2 getInstance(BCELClassEnhancer gen)
    {
        return new JdoNewObjectIdInstance2(
            "jdoNewObjectIdInstance",
            Constants.ACC_PUBLIC | Constants.ACC_FINAL,
            Type.OBJECT,
            new Type[] { Type.OBJECT },
            new String[] { "key" },
            false,
            gen);
    }

    /* (non-Javadoc)
     * @see org.datanucleus.enhancer.gen.Callback#execute()
     */
    public void execute()
    {
        String oidClassName = cmd.getObjectidClass();
        if (cmd.getMetaDataManager().getApiAdapter().isSingleFieldIdentityClass(oidClassName))
        {
            // Creates the following method:
            // public Object jdoNewObjectIdInstance(Object key)
            // {
            //     if (key instanceof String)
            //         return new oidType(getClass(), (String)key);
            //     else
            //         return new oidType(getClass(), (oidKeyType)key);
            // }
            ObjectType oidType;
            ObjectType oidKeyType;
            if (oidClassName.equals(ClassEnhancer.CN_StringIdentity))
            {
                oidType = BCELClassEnhancer.OT_StringIdentity;
                oidKeyType = Type.STRING;
            }
            else if (oidClassName.equals(ClassEnhancer.CN_LongIdentity))
            {
                oidType = BCELClassEnhancer.OT_LongIdentity;
                oidKeyType = new ObjectType(Long.class.getName());
            }
            else if (oidClassName.equals(ClassEnhancer.CN_IntIdentity))
            {
                oidType = BCELClassEnhancer.OT_IntIdentity;
                oidKeyType = new ObjectType(Integer.class.getName());
            }
            else if (oidClassName.equals(ClassEnhancer.CN_ShortIdentity))
            {
                oidType = BCELClassEnhancer.OT_ShortIdentity;
                oidKeyType = new ObjectType(Short.class.getName());
            }
            else if (oidClassName.equals(ClassEnhancer.CN_ByteIdentity))
            {
                oidType = BCELClassEnhancer.OT_ByteIdentity;
                oidKeyType = new ObjectType(Byte.class.getName());
            }
            else if (oidClassName.equals(ClassEnhancer.CN_CharIdentity))
            {
                oidType = BCELClassEnhancer.OT_CharIdentity;
                oidKeyType = new ObjectType(Long.class.getName());
            }
            else
            {
                oidType = BCELClassEnhancer.OT_ObjectIdentity;
                oidKeyType = new ObjectType(Object.class.getName());
            }

            il.append(InstructionConstants.ALOAD_1);
            BranchInstruction checkKeyIsNull = new IFNONNULL(null);
            il.append(checkKeyIsNull);
            createThrowException(ClassEnhancer.CN_IllegalArgumentException, "key is null");
            checkKeyIsNull.setTarget(il.append(InstructionConstants.ALOAD_1));
            il.append(factory.createInstanceOf(Type.STRING));
            il.append(InstructionConstants.ICONST_1);
            BranchInstruction isInstanceof = new IF_ICMPEQ(null);
            il.append(isInstanceof);

            // new oidType(getClass(), (oidKeyType)key);
            il.append(factory.createNew(oidType));
            il.append(InstructionConstants.DUP);
            il.append(InstructionConstants.ALOAD_0);
            il.append(factory.createInvoke("java.lang.Object", "getClass", BCELClassEnhancer.OT_CLASS, Type.NO_ARGS, Constants.INVOKEVIRTUAL));
            il.append(InstructionConstants.ALOAD_1);
            il.append(factory.createCheckCast(oidKeyType));
            il.append(factory.createInvoke(oidType.getClassName(), Constants.CONSTRUCTOR_NAME, Type.VOID, 
                new Type[] { BCELClassEnhancer.OT_CLASS, oidKeyType }, Constants.INVOKESPECIAL));

            // "return"
            il.append(InstructionFactory.createReturn(Type.OBJECT));

            // "new oidType(getClass(), (String)key);"
            isInstanceof.setTarget(il.append(factory.createNew(oidType)));
            il.append(InstructionConstants.DUP);
            il.append(InstructionConstants.ALOAD_0);
            il.append(factory.createInvoke("java.lang.Object", "getClass", BCELClassEnhancer.OT_CLASS, Type.NO_ARGS, Constants.INVOKEVIRTUAL));
            il.append(InstructionConstants.ALOAD_1);
            il.append(factory.createCheckCast(Type.STRING));
            il.append(factory.createInvoke(oidType.getClassName(), Constants.CONSTRUCTOR_NAME, Type.VOID, 
                new Type[] { BCELClassEnhancer.OT_CLASS, Type.STRING }, Constants.INVOKESPECIAL));

            // "return"
            il.append(InstructionFactory.createReturn(Type.OBJECT));

        }
        // Users Application Identity class
        else if (oidClassName != null && oidClassName.length() > 0)
        {
            // Creates the following method
            // public Object jdoNewObjectIdInstance(Object key)
            // {
            //     return new oidType((String)key);
            // }
            ObjectType objectIdClassType = new ObjectType(oidClassName);
            il.append(factory.createNew(objectIdClassType));
            il.append(InstructionConstants.DUP);
            il.append(InstructionConstants.ALOAD_1);
            il.append(factory.createCheckCast(Type.STRING));
            il.append(factory.createInvoke(oidClassName, Constants.CONSTRUCTOR_NAME, Type.VOID, 
                new Type[] { Type.STRING }, Constants.INVOKESPECIAL));
            il.append(InstructionFactory.createReturn(objectIdClassType));
        }
        else
        {
            super.execute();
        }
    }
}