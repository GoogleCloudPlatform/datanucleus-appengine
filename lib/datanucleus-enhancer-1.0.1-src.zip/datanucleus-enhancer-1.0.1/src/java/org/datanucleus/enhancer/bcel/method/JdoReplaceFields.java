/**********************************************************************
Copyright (c) 2004 Kikuchi Kousuke and others. All rights reserved.
Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.

Contributors:
    ...
**********************************************************************/
package org.datanucleus.enhancer.bcel.method;


import org.apache.bcel.Constants;
import org.apache.bcel.generic.ArrayType;
import org.apache.bcel.generic.Type;
import org.datanucleus.enhancer.bcel.BCELClassEnhancer;

/**
 * create jdoReplaceFields method.
 * @version $Id: JdoReplaceFields.java,v 1.1 2006/07/18 07:24:26 andy_jefferson Exp $
 */
public class JdoReplaceFields extends SwitchInverseTarget 
{
	/**
	 * @param methodName
	 * @param type
	 * @param resultType
	 * @param argType
	 * @param argName
	 * @param synthetic
	 * @param gen
	 * @param invokeMethodName
	 */
	public JdoReplaceFields(
		String methodName,
		int type,
		Type resultType,
		Type[] argType,
		String[] argName,
		boolean synthetic,
		BCELClassEnhancer gen,
		String invokeMethodName)
    {
		super(methodName, type, resultType, argType, argName, synthetic, gen, invokeMethodName);
	}

	public static JdoReplaceFields getInstance(BCELClassEnhancer gen)
    {
		return new JdoReplaceFields(
			"jdoReplaceFields",
			Constants.ACC_PUBLIC | Constants.ACC_FINAL,
			Type.VOID,
			new Type[] { new ArrayType(Type.INT, 1)},
			new String[] { "fieldId" },
			false,
			gen,
			"jdoReplaceField");
	}
}
