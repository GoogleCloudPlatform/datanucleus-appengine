/**********************************************************************
Copyright (c) 2004 Kikuchi Kousuke and others. All rights reserved.
Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.

Contributors:
    ...
**********************************************************************/
package org.datanucleus.enhancer.bcel.method;


import org.apache.bcel.Constants;
import org.apache.bcel.generic.*;
import org.datanucleus.enhancer.ClassEnhancer;
import org.datanucleus.enhancer.bcel.BCELClassEnhancer;
import org.datanucleus.enhancer.bcel.BCELClassMethod;
import org.datanucleus.enhancer.bcel.BCELUtils;
import org.datanucleus.metadata.AbstractMemberMetaData;

/**
 * Create jdoFieldNames init method.
 * @version $Revision: 1.7 $
 */
public class InitFieldNames extends BCELClassMethod
{
    /**
     * @param methodName
     * @param type
     * @param resultType
     * @param argType
     * @param argName
     * @param synthetic
     * @param gen
     */
    public InitFieldNames(String methodName, int type, Type resultType, Type[] argType, String[] argName,
        boolean synthetic, BCELClassEnhancer gen)
    {
        super(methodName, type, resultType, argType, argName, synthetic, gen);
    }

    /**
     * Create and return instance of this class.
     * @param gen target class generator
     * @return instance of this class
     */
    public static InitFieldNames getInstance(BCELClassEnhancer gen)
    {
        return new InitFieldNames(
            ClassEnhancer.MN_FieldNamesInitMethod,
            Constants.ACC_PRIVATE | Constants.ACC_STATIC | Constants.ACC_FINAL,
            new ArrayType(Type.STRING, 1),
            Type.NO_ARGS,
            null,
            true,
            gen);
    }

    /* (non-Javadoc)
     * @see org.datanucleus.enhancer.gen.Callback#execute()
     */
    public void execute()
    {
        AbstractMemberMetaData fields[] = cmd.getManagedMembers();
        if (fields != null)
        {
            String name[] = new String[fields.length];
            int index[] = new int[fields.length];
            for (int i = 0; i < fields.length; i++)
            {
                name[i] = fields[i].getName();
                index[i] = constantPoolGen.addString(name[i]);
            }

            // Create array of Strings
            il.append(BCELUtils.getBIPUSH(name.length));
            il.append(new ANEWARRAY(constantPoolGen.addClass(Type.STRING)));

            // Populate the array elements
            for (int i = 0; i < name.length; i++)
            {
                il.append(InstructionConstants.DUP);
                il.append(BCELUtils.getBIPUSH(i));
                il.append(new LDC(index[i]));
                il.append(InstructionConstants.AASTORE);
            }
            il.append(InstructionConstants.ARETURN);
        }
        else
        {
            // Create an empty array
            il.append(InstructionConstants.ICONST_0);
            il.append(new ANEWARRAY(constantPoolGen.addClass(Type.STRING)));
            il.append(InstructionConstants.ARETURN);
        }
    }
}