/**********************************************************************
Copyright (c) 2004 Kikuchi Kousuke and others. All rights reserved.
Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.

Contributors:
    ...
**********************************************************************/
package org.datanucleus.enhancer.bcel.method;


import org.apache.bcel.Constants;
import org.apache.bcel.generic.*;
import org.datanucleus.enhancer.ClassEnhancer;
import org.datanucleus.enhancer.bcel.BCELClassEnhancer;
import org.datanucleus.enhancer.bcel.BCELClassMethod;

/**
 * create jdoReplaceStateManager method.
 */
public class JdoReplaceStateManager extends BCELClassMethod
{
    /**
     * @param methodName
     * @param type
     * @param resultType
     * @param argType
     * @param argName
     * @param synthetic
     * @param gen
     */
    public JdoReplaceStateManager(
        String methodName,
        int type,
        Type resultType,
        Type[] argType,
        String[] argName,
        boolean synthetic,
        BCELClassEnhancer gen)
    {
        super(methodName, type, resultType, argType, argName, synthetic, gen);
    }

    public static JdoReplaceStateManager getInstance(BCELClassEnhancer gen)
    {
        return new JdoReplaceStateManager(
            "jdoReplaceStateManager",
            Constants.ACC_PUBLIC | Constants.ACC_FINAL | Constants.ACC_SYNCHRONIZED,
            Type.VOID,
            new Type[] { new ObjectType(ClassEnhancer.CN_StateManager)},
            new String[] { "stateManager" },
            false,
            gen);
    }

    /* (non-Javadoc)
     * @see org.datanucleus.enhancer.gen.Callback#execute()
     */
    public void execute()
    {
        InstructionHandle ifnullTarget1 = null;
        InstructionHandle ifnullTarget2 = null;
        InstructionHandle lvSecurityManager[] = new InstructionHandle[2];

        il.append(InstructionConstants.ALOAD_0);
        il.append(
            factory.createGetField(
                className,
                ClassEnhancer.FN_StateManager,
                BCELClassEnhancer.OT_StateManager));

        IFNULL ifnull1 = new IFNULL(ifnullTarget1);
        il.append(ifnull1);
        il.append(InstructionConstants.ALOAD_0);
        il.append(InstructionConstants.DUP);
        il.append(
            factory.createGetField(
                className,
                ClassEnhancer.FN_StateManager,
                BCELClassEnhancer.OT_StateManager));
        il.append(InstructionConstants.ALOAD_0);
        il.append(InstructionConstants.ALOAD_1);
        il.append(
            factory.createInvoke(
                ClassEnhancer.CN_StateManager,
                "replacingStateManager",
                BCELClassEnhancer.OT_StateManager,
                new Type[] { BCELClassEnhancer.OT_PersistenceCapable, BCELClassEnhancer.OT_StateManager },
                Constants.INVOKEINTERFACE));

        il.append(
            factory.createPutField(
                className,
                ClassEnhancer.FN_StateManager,
                BCELClassEnhancer.OT_StateManager));
        il.append(InstructionConstants.RETURN);

        // TODO This should call JDOImplHelper.checkAuthorizedStateManager(sm);
        lvSecurityManager[0] =
            ifnullTarget1 =
                il.append(
                    factory.createInvoke(
                        "java.lang.System",
                        "getSecurityManager",
                        new ObjectType("java.lang.SecurityManager"),
                        Type.NO_ARGS,
                        Constants.INVOKESTATIC));
        ifnull1.setTarget(ifnullTarget1);
        il.append(new ASTORE(2));
        il.append(new ALOAD(2));
        IFNULL ifnull2 = new IFNULL(ifnullTarget2);
        il.append(ifnull2);
        il.append(new ALOAD(2));
        il.append(factory.createNew(new ObjectType("javax.jdo.spi.JDOPermission")));
        il.append(InstructionConstants.DUP);
        il.append(new LDC(constantPoolGen.addString("setStateManager")));
        il.append(
            factory.createInvoke(
                "javax.jdo.spi.JDOPermission",
                Constants.CONSTRUCTOR_NAME,
                Type.VOID,
                new Type[] { Type.STRING },
                Constants.INVOKESPECIAL));
        lvSecurityManager[1] =
            il.append(
                factory.createInvoke(
                    "java.lang.SecurityManager",
                    "checkPermission",
                    Type.VOID,
                    new Type[] { new ObjectType("java.security.Permission")},
                    Constants.INVOKEVIRTUAL));
        methodGen.addLocalVariable(
            "securityManager",
            new ObjectType("java.lang.SecurityManager"),
            lvSecurityManager[0],
            lvSecurityManager[1]);

        ifnullTarget2 = il.append(InstructionConstants.ALOAD_0);
        ifnull2.setTarget(ifnullTarget2);
        il.append(InstructionConstants.ALOAD_1);
        il.append(
            factory.createPutField(
                className,
                ClassEnhancer.FN_StateManager,
                BCELClassEnhancer.OT_StateManager));
        il.append(InstructionConstants.ALOAD_0);
        il.append(InstructionConstants.ICONST_1);
        il.append(factory.createPutField(className, ClassEnhancer.FN_Flag, Type.BYTE));

        il.append(InstructionConstants.RETURN);
    }
}
