/**********************************************************************
Copyright (c) 2004 Kikuchi Kousuke and others. All rights reserved.
Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.

Contributors:
    ...
**********************************************************************/
package org.datanucleus.enhancer.bcel.method;

import org.apache.bcel.Constants;
import org.apache.bcel.generic.ArrayType;
import org.apache.bcel.generic.BasicType;
import org.apache.bcel.generic.BranchInstruction;
import org.apache.bcel.generic.CHECKCAST;
import org.apache.bcel.generic.IFNONNULL;
import org.apache.bcel.generic.InstructionConstants;
import org.apache.bcel.generic.InstructionHandle;
import org.apache.bcel.generic.TABLESWITCH;
import org.apache.bcel.generic.Type;
import org.datanucleus.enhancer.ClassEnhancer;
import org.datanucleus.enhancer.bcel.BCELClassEnhancer;
import org.datanucleus.enhancer.bcel.BCELClassMethod;
import org.datanucleus.enhancer.bcel.BCELUtils;
import org.datanucleus.enhancer.bcel.metadata.BCELFieldPropertyMetaData;
import org.datanucleus.enhancer.bcel.metadata.BCELMember;
import org.datanucleus.metadata.AbstractMemberMetaData;
import org.datanucleus.util.ClassUtils;

/**
 * create jdoReplaceField method.
 * @version $Revision: 1.12 $
 */
public class JdoReplaceField extends BCELClassMethod
{
    /**
     * @param methodName
     * @param type
     * @param resultType
     * @param argType
     * @param argName
     * @param synthetic
     * @param gen
     */
    public JdoReplaceField(String methodName, int type, Type resultType, Type[] argType, String[] argName,
        boolean synthetic, BCELClassEnhancer gen)
    {
        super(methodName, type, resultType, argType, argName, synthetic, gen);
    }

    public static JdoReplaceField getInstance(BCELClassEnhancer gen)
    {
        return new JdoReplaceField(
            "jdoReplaceField",
            Constants.ACC_PUBLIC,
            Type.VOID,
            new Type[] { Type.INT },
            new String[] { "fieldIndex" },
            false,
            gen);
    }

    /* (non-Javadoc)
     * @see org.datanucleus.enhancer.gen.Callback#execute()
     */
    public void execute()
    {
        int fieldNum = cmd.getNoOfManagedMembers();

        // We have no fields so pass up to superclass if possible
        if (fieldNum == 0)
        {
            if (cmd.getPersistenceCapableSuperclass() != null)
            {
                il.append(InstructionConstants.ALOAD_0);
                il.append(InstructionConstants.ILOAD_1);
                il.append(factory.createInvoke(
                    cmd.getPersistenceCapableSuperclass(),
                    methodGen.getName(),
                    Type.VOID,
                    (Type[])this.argTypes,
                    Constants.INVOKESPECIAL));
            }
            il.append(InstructionConstants.RETURN);
            return;
        }

        // Create "switch" statement to handle our own fields here, and pass
        // all others up to superclasses
        AbstractMemberMetaData targetFields[] = cmd.getManagedMembers();
        InstructionHandle switchTable[] = new InstructionHandle[targetFields.length];
        InstructionHandle swichDefaultBlock;
        int fieldIndexes[] = new int[targetFields.length];
        for (int i = 0; i < targetFields.length; i++)
        {
            fieldIndexes[i] = i;
        }

        // if(___jdo$StateManager == null)
        // throw new IllegalStateException("state manager is null");
        il.append(InstructionConstants.ALOAD_0);
        il.append(
            factory.createGetField(
                className,
                ClassEnhancer.FN_StateManager,
                BCELClassEnhancer.OT_StateManager));
        BranchInstruction smPresented = new IFNONNULL(null);
        il.append(smPresented);
        createThrowException(ClassEnhancer.CN_IllegalStateException, "state manager is null");

        smPresented.setTarget(il.append(InstructionConstants.ILOAD_1));
        if (cmd.getPersistenceCapableSuperclass() != null)
        {
            il.append(
                factory.createGetStatic(className, ClassEnhancer.FN_JdoInheritedFieldCount, Type.INT));
            il.append(InstructionConstants.ISUB);
        }

        // swichBlock = il.append(InstructionFactory.NOP);
        for (int i = 0; i < targetFields.length; i++)
        {
            Type jdoObjectType = null;
            BCELMember field = ((BCELFieldPropertyMetaData)targetFields[i]).getEnhanceField();
            if (field.getType().getClass().equals(BasicType.class))
            {
                jdoObjectType = field.getType();
            }
            else if (field.getType().equals(Type.STRING))
            {
                jdoObjectType = Type.STRING;
            }
            else
            {
                jdoObjectType = Type.OBJECT;
            }
            switchTable[i] = il.append(InstructionConstants.ALOAD_0);
            il.append(InstructionConstants.DUP);
            
            //stateManager field 
            il.append(
                    factory.createGetField(
                        className,
                        ClassEnhancer.FN_StateManager,
                        BCELClassEnhancer.OT_StateManager));
            //jdoStateManager.replacingXXXField(this, fieldIndex);
            il.append(InstructionConstants.ALOAD_0);
            il.append(InstructionConstants.ILOAD_1);
            il.append(
                factory.createInvoke(
                    ClassEnhancer.CN_StateManager,
                    "replacing" + BCELUtils.getJDOMethodName(field.getType()) + "Field",
                    jdoObjectType,
                    new Type[] { BCELClassEnhancer.OT_PersistenceCapable, Type.INT },
                    Constants.INVOKEINTERFACE));
            if (jdoObjectType == Type.OBJECT)
            {
                String type = null;
                if (field.getType() instanceof ArrayType)
                    type = field.getType().getSignature();
                else
                    type = field.getType().toString();
                il.append(new CHECKCAST(constantPoolGen.addClass(type)));
            }
            if (!targetFields[i].isProperty())
            {
                //field = jdoStateManager.replacingXXXField(this, fieldIndex);
                il.append(factory.createPutField(className, field.getName(), field.getType()));
            }
            else
            {
                //setFieldName(jdoStateManager.replacingXXXField(this, fieldIndex));
                
                String fieldName = ClassUtils.getFieldNameForJavaBeanGetter(field.getName());
                il.append(factory.createInvoke(
                    className,
                    "jdo"+BCELUtils.getSetterName(fieldName),
                    Type.VOID,
                    new Type[] {field.getType()},
                    Constants.INVOKEVIRTUAL));
            }
            il.append(InstructionConstants.RETURN);
        }
        if (cmd.getPersistenceCapableSuperclass() == null)
        {
            swichDefaultBlock =
                createThrowException(
                    ClassEnhancer.CN_IllegalArgumentException,
                    "out of field index :",
                    InstructionConstants.ILOAD_1);
        }
        else
        {
            swichDefaultBlock = il.append(InstructionConstants.ALOAD_0);
            il.append(InstructionConstants.ILOAD_1);
            il.append(
                factory.createInvoke(
                    cmd.getPersistenceCapableSuperclass(),
                    methodGen.getName(),
                    Type.VOID,
                    (Type[])this.argTypes,
                    Constants.INVOKESPECIAL));
            il.append(InstructionConstants.RETURN);
        }

        TABLESWITCH switchInstruction =
            new TABLESWITCH(fieldIndexes, switchTable, swichDefaultBlock);
        il.insert(switchTable[0], switchInstruction);
    }
}
