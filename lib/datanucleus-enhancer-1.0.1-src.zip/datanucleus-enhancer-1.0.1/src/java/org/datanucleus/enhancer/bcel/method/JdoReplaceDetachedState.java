/**********************************************************************
Copyright (c) 2005 Andy Jefferson and others. All rights reserved.
Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
 

Contributors:
    ...
**********************************************************************/
package org.datanucleus.enhancer.bcel.method;


import org.apache.bcel.Constants;
import org.apache.bcel.generic.*;
import org.datanucleus.enhancer.ClassEnhancer;
import org.datanucleus.enhancer.bcel.BCELClassEnhancer;
import org.datanucleus.enhancer.bcel.BCELClassMethod;

/**
 * Create jdoReplaceDetachedState() method. The generated code will be as follows :-
 * <pre>
 * if (jdoStateManager == null)
 * {
 * 	   throw new IllegalStateException("state manager is null");
 * }
 * else
 * {
 *     jdoDetachedState = jdoStateManager.replacingDetachedState(this, jdoDetachedState);
 * }
 * </pre>
 * @version $Revision: 1.3 $
 * @since 1.1
 */
public class JdoReplaceDetachedState extends BCELClassMethod
{
    /**
     * @param methodName
     * @param type
     * @param resultType
     * @param argType
     * @param argName
     * @param synthetic
     * @param gen
     */
    public JdoReplaceDetachedState(
        String methodName,
        int type,
        Type resultType,
        Type[] argType,
        String[] argName,
        boolean synthetic,
        BCELClassEnhancer gen)
    {
        super(methodName, type, resultType, argType, argName, synthetic, gen);
    }

    public static JdoReplaceDetachedState getInstance(BCELClassEnhancer gen)
    {
        return new JdoReplaceDetachedState("jdoReplaceDetachedState",
            Constants.ACC_PUBLIC | Constants.ACC_FINAL | Constants.ACC_SYNCHRONIZED,
            Type.VOID,
            Type.NO_ARGS,
            null,
            false,
            gen);
    }

    /* (non-Javadoc)
     * @see org.datanucleus.enhancer.gen.Callback#execute()
     */
    public void execute()
    {
        // if (jdoStateManager == null)
        il.append(InstructionConstants.ALOAD_0);
        il.append(factory.createGetField(className, ClassEnhancer.FN_StateManager, BCELClassEnhancer.OT_StateManager));
        BranchInstruction smPresented = new IFNONNULL(null);
        il.append(smPresented);

        // throw new IllegalStateException("state manager is null");
        createThrowException(ClassEnhancer.CN_IllegalStateException, "state manager is null");

        // jdoStateManager
        smPresented.setTarget(il.append(InstructionConstants.ALOAD_0));
        il.append(InstructionConstants.DUP);
        il.append(factory.createGetField(className, ClassEnhancer.FN_StateManager, BCELClassEnhancer.OT_StateManager));

        // this
        il.append(InstructionConstants.ALOAD_0);

        // jdoDetachedState
        il.append(InstructionConstants.ALOAD_0);
        il.append(factory.createGetField(className, ClassEnhancer.FN_JdoDetachedState, BCELClassEnhancer.OT_ObjectArray));

        // replacingDetachedState
        il.append(factory.createInvoke(ClassEnhancer.CN_StateManager, "replacingDetachedState", BCELClassEnhancer.OT_ObjectArray, 
            new Type[]{BCELClassEnhancer.OT_Detachable, BCELClassEnhancer.OT_ObjectArray}, Constants.INVOKEINTERFACE));

        // jdoDetachedState =
        il.append(factory.createPutField(className, ClassEnhancer.FN_JdoDetachedState, BCELClassEnhancer.OT_ObjectArray));
        il.append(InstructionConstants.RETURN);
    }
}