/**********************************************************************
Copyright (c) 2004 Kikuchi Kousuke and others. All rights reserved.
Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
 

Contributors:
    ...
**********************************************************************/
package org.datanucleus.enhancer.bcel.method;

import org.apache.bcel.classfile.Method;
import org.datanucleus.enhancer.bcel.BCELClassEnhancer;
import org.datanucleus.enhancer.bcel.BCELClassMethod;
import org.datanucleus.enhancer.bcel.BCELUtils;
import org.datanucleus.util.NucleusLogger;


/**
 * @version $Revision: 1.2 $
 */
public abstract class ReplaceMethodCallback extends BCELClassMethod
{
    protected Method originalMethod;

    /**
     * @param originalMethod The original method to replace
     * @param gen The generator base
     */
    public ReplaceMethodCallback(Method originalMethod, BCELClassEnhancer gen)
    {
        super(originalMethod.getName(),
              originalMethod.getModifiers(),
              originalMethod.getReturnType(),
              originalMethod.getArgumentTypes(),
              null,
              false,
              gen);
        this.originalMethod = originalMethod;
    }

    public void close()
    {
        if (originalMethod == null)
        {
            super.close();
            return;
        }

        if (methodGen != null)
        {
            methodGen.setMaxStack();
            methodGen.setMaxLocals();
            Method m = methodGen.getMethod();
            classGen.replaceMethod(originalMethod, m);
            if (synthetic)
            {
                BCELUtils.addSynthetic(m, classGen.getConstantPool());
            }
            if (NucleusLogger.ENHANCER.isDebugEnabled())
            {
                StringBuffer sb = new StringBuffer();
                sb.append("replace method: ");
                sb.append(methodName).append("(");
                for (int i = 0; i < argTypes.length; i++)
                {
                    if (i != 0)
                    {
                        sb.append(", ");
                    }
                    sb.append(argTypes[i]).append(" ");
                }
                sb.append(")");
                NucleusLogger.ENHANCER.debug(sb.toString());
            }

            methodGen.update();
            classGen.update();
            il.dispose();
        }
    }
}