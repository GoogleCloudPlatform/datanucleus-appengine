/**********************************************************************
Copyright (c) 2004 Erik Bengtson and others. All rights reserved.
Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.

Contributors:
    ...
**********************************************************************/
package org.datanucleus.enhancer.bcel.method;


import org.apache.bcel.Constants;
import org.apache.bcel.generic.Type;
import org.datanucleus.enhancer.ClassEnhancer;
import org.datanucleus.enhancer.bcel.BCELClassEnhancer;

/**
 * create JdoPreSerialize method.
 * @version $Revision: 1.2 $
 */
public class JdoPreSerialize extends SimpleStateManagerCall
{
    /**
     * @param methodName
     * @param type
     * @param resultType
     * @param argType
     * @param argName
     * @param synthetic
     * @param gen
     * @param invokeMethod
     */
    public JdoPreSerialize(
        String methodName,
        int type,
        Type resultType,
        Type[] argType,
        String[] argName,
        boolean synthetic,
        BCELClassEnhancer gen,
        String invokeMethod)
    {
        super(methodName, type, resultType, argType, argName, synthetic, gen, invokeMethod);
    }

    public static JdoPreSerialize getInstance(BCELClassEnhancer gen)
    {
        return new JdoPreSerialize(
                ClassEnhancer.MN_JdoPreSerialize,
            Constants.ACC_PROTECTED | Constants.ACC_FINAL,
            Type.VOID,
            Type.NO_ARGS,
            null,
            false,
            gen,
            "preSerialize");
    }
}