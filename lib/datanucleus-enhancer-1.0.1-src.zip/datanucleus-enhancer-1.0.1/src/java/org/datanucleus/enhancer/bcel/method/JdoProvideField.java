/**********************************************************************
Copyright (c) 2004 Kikuchi Kousuke and others. All rights reserved.
Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.

Contributors:
    Andy Jefferson - fix so that if we have no fields, pass to superclass
    ...
**********************************************************************/
package org.datanucleus.enhancer.bcel.method;

import org.apache.bcel.Constants;
import org.apache.bcel.generic.BasicType;
import org.apache.bcel.generic.IFNONNULL;
import org.apache.bcel.generic.InstructionConstants;
import org.apache.bcel.generic.InstructionHandle;
import org.apache.bcel.generic.TABLESWITCH;
import org.apache.bcel.generic.Type;
import org.datanucleus.enhancer.ClassEnhancer;
import org.datanucleus.enhancer.bcel.BCELClassEnhancer;
import org.datanucleus.enhancer.bcel.BCELClassMethod;
import org.datanucleus.enhancer.bcel.BCELUtils;
import org.datanucleus.enhancer.bcel.metadata.BCELFieldPropertyMetaData;
import org.datanucleus.enhancer.bcel.metadata.BCELMember;
import org.datanucleus.metadata.AbstractMemberMetaData;
import org.datanucleus.util.ClassUtils;

/**
 * create jdoProvideField method.
 * @version $Revision: 1.12 $
 */
public class JdoProvideField extends BCELClassMethod
{
    /**
     * @param methodName
     * @param type
     * @param resultType
     * @param argType
     * @param argName
     * @param synthetic
     * @param gen
     */
    public JdoProvideField(String methodName, int type, Type resultType, Type[] argType, String[] argName,
        boolean synthetic, BCELClassEnhancer gen)
    {
        super(methodName, type, resultType, argType, argName, synthetic, gen);
    }

    public static JdoProvideField getInstance(BCELClassEnhancer gen)
    {
        return new JdoProvideField(
            "jdoProvideField",
            Constants.ACC_PUBLIC,
            Type.VOID,
            new Type[] { Type.INT },
            new String[] { "fieldIndex" },
            false,
            gen);
    }

    /* (non-Javadoc)
     * @see org.datanucleus.enhancer.gen.Callback#execute()
     */
    public void execute()
    {
        AbstractMemberMetaData targetFields[] = cmd.getManagedMembers();

        // We have no fields so pass up to superclass if possible
        if ((targetFields == null) || (targetFields.length == 0))
        {
            if (cmd.getPersistenceCapableSuperclass() != null)
            {
                il.append(InstructionConstants.ALOAD_0);
                il.append(InstructionConstants.ILOAD_1);
                il.append(factory.createInvoke(
                    cmd.getPersistenceCapableSuperclass(),
                    methodGen.getName(),
                    Type.VOID,
                    (Type[])this.argTypes,
                    Constants.INVOKESPECIAL));
            }
            il.append(InstructionConstants.RETURN);
            return;
        }

        // Create "switch" statement to handle our own fields here, and pass
        // all others up to superclasses
        InstructionHandle swichBlock;
        InstructionHandle switchTable[] = new InstructionHandle[targetFields.length];
        InstructionHandle swichDefaultBlock;
        int fieldIndexes[] = new int[targetFields.length];
        for (int i = 0; i < targetFields.length; i++)
        {
            fieldIndexes[i] = i;
        }

        // if(___jdo$StateManager == null)
        // throw new IllegalStateException("state manager is null");
        il.append(InstructionConstants.ALOAD_0);
        il.append(
            factory.createGetField(
                className,
                ClassEnhancer.FN_StateManager,
                BCELClassEnhancer.OT_StateManager));
        IFNONNULL smPresented = new IFNONNULL(null);
        il.append(smPresented);
        createThrowException(ClassEnhancer.CN_IllegalStateException, "state manager is null");

        smPresented.setTarget(il.append(InstructionConstants.ILOAD_1));
        if (cmd.getPersistenceCapableSuperclass() != null)
        {
            il.append(
                factory.createGetStatic(className, ClassEnhancer.FN_JdoInheritedFieldCount, Type.INT));
            il.append(InstructionConstants.ISUB);
        }
        swichBlock = il.append(InstructionConstants.NOP);
        for (int i = 0; i < targetFields.length; i++)
        {
            BCELMember f = ((BCELFieldPropertyMetaData)targetFields[i]).getEnhanceField();
            Type jdoObjectType = null;
            if (f.getType().getClass().equals(BasicType.class))
            {
                jdoObjectType = f.getType();
            }
            else if (f.getType().equals(Type.STRING))
            {
                jdoObjectType = f.getType();
            }
            else
            {
                jdoObjectType = Type.OBJECT;
            }
            switchTable[i] = il.append(InstructionConstants.ALOAD_0);
            il.append(
                factory.createGetField(
                    className,
                    ClassEnhancer.FN_StateManager,
                    BCELClassEnhancer.OT_StateManager));
            il.append(InstructionConstants.ALOAD_0);
            il.append(InstructionConstants.ILOAD_1);
            il.append(InstructionConstants.ALOAD_0);
            if (!targetFields[i].isProperty())
            {
                il.append(factory.createGetField(className, f.getName(), f.getType()));
            }
            else
            {
                //getFieldName();
                
                String fieldName = ClassUtils.getFieldNameForJavaBeanGetter(f.getName());
                il.append(factory.createInvoke(
                    className,
                    "jdo"+BCELUtils.getGetterName(fieldName),
                    f.getType(),
                    new Type[] {},
                    Constants.INVOKEVIRTUAL));
            }
            il.append(
                factory.createInvoke(
                    ClassEnhancer.CN_StateManager,
                    "provided" + BCELUtils.getJDOMethodName(f.getType()) + "Field",
                    Type.VOID,
                    new Type[] { BCELClassEnhancer.OT_PersistenceCapable, Type.INT, jdoObjectType },
                    Constants.INVOKEINTERFACE));
            il.append(InstructionConstants.RETURN);
        }
        if (cmd.getPersistenceCapableSuperclass() == null)
        {
            swichDefaultBlock =
                createThrowException(
                    ClassEnhancer.CN_IllegalArgumentException,
                    "out of field index :",
                    InstructionConstants.ILOAD_1);
        }
        else
        {
            swichDefaultBlock = il.append(InstructionConstants.ALOAD_0);
            il.append(InstructionConstants.ILOAD_1);
            il.append(
                factory.createInvoke(
                    cmd.getPersistenceCapableSuperclass(),
                    methodGen.getName(),
                    Type.VOID,
                    (Type[])this.argTypes,
                    Constants.INVOKESPECIAL));

            il.append(InstructionConstants.RETURN);
        }

        TABLESWITCH switchInstruction =
            new TABLESWITCH(fieldIndexes, switchTable, swichDefaultBlock);
        il.insert(swichBlock, switchInstruction);
    }
}
