/**********************************************************************
Copyright (c) 2004 Kikuchi Kousuke and others. All rights reserved.
Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.

Contributors:
2004 Andy Jefferson - fixed the SingleFieldIdentity version
    ...
**********************************************************************/
package org.datanucleus.enhancer.bcel.method;

import org.apache.bcel.Constants;
import org.apache.bcel.generic.InstructionConstants;
import org.apache.bcel.generic.InstructionFactory;
import org.apache.bcel.generic.ObjectType;
import org.apache.bcel.generic.Type;
import org.datanucleus.enhancer.ClassEnhancer;
import org.datanucleus.enhancer.bcel.BCELClassEnhancer;
import org.datanucleus.enhancer.bcel.BCELClassMethod;
import org.datanucleus.enhancer.bcel.BCELUtils;
import org.datanucleus.enhancer.bcel.metadata.BCELFieldPropertyMetaData;
import org.datanucleus.enhancer.bcel.metadata.BCELMember;
import org.datanucleus.metadata.AbstractMemberMetaData;

/**
 * Create the jdoNewObjectIdInstance() method.
 * 
 * @version $Revision: 1.12 $
 */
public class JdoNewObjectIdInstance1 extends BCELClassMethod
{
    /**
     * @param methodName
     * @param type
     * @param resultType
     * @param argType
     * @param argName
     * @param synthetic
     * @param gen
     */
    public JdoNewObjectIdInstance1(String methodName, int type, Type resultType, Type[] argType, String[] argName,
        boolean synthetic, BCELClassEnhancer gen)
    {
        super(methodName, type, resultType, argType, argName, synthetic, gen);
    }

    public static JdoNewObjectIdInstance1 getInstance(BCELClassEnhancer gen)
    {
        return new JdoNewObjectIdInstance1(
            "jdoNewObjectIdInstance",
            Constants.ACC_PUBLIC | Constants.ACC_FINAL,
            Type.OBJECT,
            Type.NO_ARGS,
            null,
            false,
            gen);
    }
    
    /* (non-Javadoc)
     * @see org.datanucleus.enhancer.gen.Callback#execute()
     */
    public void execute()
    {
        String oidClassName = cmd.getObjectidClass();
        if (cmd.getMetaDataManager().getApiAdapter().isSingleFieldIdentityClass(oidClassName))
        {
            AbstractMemberMetaData fields[] = cmd.getManagedMembers();
            ObjectType oidType;

            if (oidClassName.equals(ClassEnhancer.CN_StringIdentity))
            {
                oidType = BCELClassEnhancer.OT_StringIdentity;
            }
            else if (oidClassName.equals(ClassEnhancer.CN_LongIdentity))
            {
                oidType = BCELClassEnhancer.OT_LongIdentity;
            }
            else if (oidClassName.equals(ClassEnhancer.CN_IntIdentity))
            {
                oidType = BCELClassEnhancer.OT_IntIdentity;
            }
            else if (oidClassName.equals(ClassEnhancer.CN_ShortIdentity))
            {
                oidType = BCELClassEnhancer.OT_ShortIdentity;
            }
            else if (oidClassName.equals(ClassEnhancer.CN_ByteIdentity))
            {
                oidType = BCELClassEnhancer.OT_ByteIdentity;
            }
            else if (oidClassName.equals(ClassEnhancer.CN_CharIdentity))
            {
                oidType = BCELClassEnhancer.OT_CharIdentity;
            }
            else
            {
                oidType = BCELClassEnhancer.OT_ObjectIdentity;
            }

            // Creates the following method:
            // public Object jdoNewObjectIdInstance()
            // {
            //     return new oidType(getClass());
            // }
            for (int i = 0; i < fields.length; i++) 
            {
	            AbstractMemberMetaData f = (AbstractMemberMetaData)fields[i];
                BCELMember fieldMethod = ((BCELFieldPropertyMetaData)f).getEnhanceField();
                
                if (f.isPrimaryKey())
                {
                    il.append(factory.createNew(oidType));
                    il.append(InstructionConstants.DUP);
                    il.append(InstructionConstants.ALOAD_0);
                    il.append(factory.createInvoke(className, "getClass", BCELClassEnhancer.OT_CLASS, Type.NO_ARGS, Constants.INVOKEVIRTUAL));
                    il.append(InstructionConstants.ALOAD_0);
                    
                    createGetField(f.getName(),fieldMethod.getType(), f.isProperty());
                    if (oidType == BCELClassEnhancer.OT_ObjectIdentity)
                    {
                        // ObjectIdentity case where we override the field type and just use Object
                        il.append(factory.createInvoke(oidType.getClassName(), Constants.CONSTRUCTOR_NAME, Type.VOID, 
                            new Type[]{BCELClassEnhancer.OT_CLASS, Type.OBJECT}, Constants.INVOKESPECIAL));
                    }
                    else
                    {
                        il.append(factory.createInvoke(oidType.getClassName(), Constants.CONSTRUCTOR_NAME, Type.VOID, 
                            new Type[]{BCELClassEnhancer.OT_CLASS, fieldMethod.getType()}, Constants.INVOKESPECIAL));
                    }
                    il.append(InstructionFactory.createReturn(oidType));
                    break;
                }
            }/*
              * il.append(factory.createNew(oidType));
              * il.append(InstructionConstants.DUP);
              * il.append(InstructionFactory.createLoad(Type.OBJECT, 0));
              * il.append(factory.createInvoke("java.lang.Object", "getClass",
              * Generator.OT_CLASS, Type.NO_ARGS, Constants.INVOKEVIRTUAL));
              * il.append(factory.createInvoke(oidType.getClassName(), "
              * <init>", Type.VOID, new Type[]{Generator.OT_CLASS},
              * Constants.INVOKESPECIAL));
              * il.append(InstructionFactory.createReturn(Type.OBJECT));
              */
        }
        // Users Application Identity class
        else if (oidClassName != null && oidClassName.length() > 0)
        {
            ObjectType objectIdClassType = new ObjectType(oidClassName);
            il.append(factory.createNew(objectIdClassType));
            il.append(InstructionConstants.DUP);
            il.append(factory.createInvoke(oidClassName, Constants.CONSTRUCTOR_NAME, Type.VOID, Type.NO_ARGS, Constants.INVOKESPECIAL));
            il.append(InstructionFactory.createReturn(objectIdClassType));
        }
        else
        {
            super.execute();
        }
    }
    
    private void createGetField(String fieldName, Type fieldType, boolean isProperty)
    {
        if( isProperty )
        {
            il.append(factory.createInvoke(
                className,
                "jdo"+BCELUtils.getGetterName(fieldName),
                fieldType,
                new Type[] {},
                Constants.INVOKEVIRTUAL));
        }
        else
        {
            il.append(factory.createGetField(getClassEnhancer().className, fieldName, fieldType));
        }
    }
    
}