/**********************************************************************
Copyright (c) 2004 Erik Bengtson and others. All rights reserved.
Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.

Contributors:
    ...
**********************************************************************/
package org.datanucleus.enhancer.bcel.method;


import org.apache.bcel.Constants;
import org.apache.bcel.generic.*;
import org.datanucleus.enhancer.ClassEnhancer;
import org.datanucleus.enhancer.bcel.BCELClassEnhancer;
import org.datanucleus.enhancer.bcel.BCELClassMethod;

/**
 * @version $Revision: 1.3 $
 */
public class SwitchInverseTarget extends BCELClassMethod
{
    protected String invokeMethodName;
    /**
     * @param methodName
     * @param type
     * @param resultType
     * @param argType
     * @param argName
     * @param synthetic
     * @param gen
     */
    public SwitchInverseTarget(
        String methodName,
        int type,
        Type resultType,
        Type[] argType,
        String[] argName,
        boolean synthetic,
        BCELClassEnhancer gen,
        String invokeMethodName)
    {
        super(methodName, type, resultType, argType, argName, synthetic, gen);
        this.invokeMethodName = invokeMethodName;
    }

    /* (non-Javadoc)
     * @see org.datanucleus.enhancer.gen.Callback#execute()
     */
    public void execute()
    {
        InstructionHandle lv_i[] = new InstructionHandle[2];
        InstructionHandle last;
        BranchInstruction br = null;
        // if(fieldId == null)
        //   throw new IllegalArgumentException("argment is null");
        il.append(InstructionConstants.ALOAD_1);
        IFNONNULL ifnonnull = new IFNONNULL(null);
        il.append(ifnonnull);
        createThrowException(ClassEnhancer.CN_IllegalArgumentException, "argument is null");
        ifnonnull.setTarget(il.append(InstructionConstants.NOP));

        String pcsc = cmd.getPersistenceCapableSuperclass();
        if ((pcsc == null) || (pcsc.length() == 0))
        {
            il.append(InstructionConstants.ALOAD_1);
            lv_i[0] = il.append(InstructionConstants.ARRAYLENGTH);
            il.append(InstructionConstants.ISTORE_2);

            il.append(InstructionConstants.ILOAD_2);
            br = new IFLE(null);
            il.append(br);

            il.append(InstructionConstants.ICONST_0);
            il.append(new ISTORE(3));
            InstructionHandle for1 = il.append(InstructionConstants.ALOAD_0);
            il.append(InstructionConstants.ALOAD_1);
            il.append(new ILOAD(3));
            il.append(InstructionConstants.IALOAD);
            il.append(
                factory.createInvoke(
                    className,
                    invokeMethodName,
                    Type.VOID,
                    new Type[] { Type.INT },
                    Constants.INVOKEVIRTUAL));

            il.append(new ILOAD(3));
            il.append(InstructionConstants.ICONST_1);
            il.append(InstructionConstants.IADD);
            il.append(InstructionConstants.DUP);
            il.append(new ISTORE(3));
            il.append(InstructionConstants.ILOAD_2);
            il.append(new IF_ICMPLT(for1));

        }
        else 
        {
            il.append(InstructionConstants.ALOAD_1);
            lv_i[0] = il.append(InstructionConstants.ARRAYLENGTH);
            il.append(InstructionConstants.ICONST_1);
            il.append(InstructionConstants.ISUB);
            il.append(InstructionConstants.ISTORE_2);

            il.append(InstructionConstants.ILOAD_2);
            br = new IFLE(null);
            il.append(br);
            
            InstructionHandle for1 = il.append(InstructionConstants.ALOAD_0);
            il.append(InstructionConstants.ALOAD_1);
            il.append(InstructionConstants.ILOAD_2);
            il.append(InstructionConstants.IALOAD);
            il.append(
                factory.createInvoke(
                    className,
                    invokeMethodName,
                    Type.VOID,
                    new Type[] { Type.INT },
                    Constants.INVOKEVIRTUAL));

            il.append(InstructionConstants.ILOAD_2);
            il.append(InstructionConstants.ICONST_1);
            il.append(InstructionConstants.ISUB);
            il.append(InstructionConstants.DUP);
            il.append(InstructionConstants.ISTORE_2);
            il.append(InstructionConstants.ICONST_0);
            il.append(new IF_ICMPGE(for1));

        }
        lv_i[1] = last = il.append(InstructionConstants.RETURN);
        if (br != null)
        {
            br.setTarget(last);
        }
        methodGen.addLocalVariable("i", Type.INT, lv_i[0], lv_i[1]);
    }
}
