/**********************************************************************
Copyright (c) 12-May-2004 Kikuchi Kousuke and others. All rights reserved.
Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.

Contributors:
    ...
**********************************************************************/
package org.datanucleus.enhancer.bcel.method;

import org.apache.bcel.Constants;
import org.apache.bcel.generic.ArrayType;
import org.apache.bcel.generic.InstructionConstants;
import org.apache.bcel.generic.Type;
import org.datanucleus.enhancer.ClassEnhancer;
import org.datanucleus.enhancer.bcel.BCELClassEnhancer;
import org.datanucleus.enhancer.bcel.BCELClassMethod;
import org.datanucleus.enhancer.bcel.BCELUtils;
import org.datanucleus.metadata.AbstractMemberMetaData;

/**
 * Create jdoFieldFlags init method.
 * @version $Revision: 1.8 $
 */
public class InitFieldFlags extends BCELClassMethod
{
	/**
	 * @param methodName method name
	 * @param type 
	 * @param resultType
	 * @param argType
	 * @param argName
	 * @param synthetic
	 * @param gen
	 */
	public InitFieldFlags(String methodName, int type, Type resultType, Type[] argType, String[] argName,
        boolean synthetic, BCELClassEnhancer gen)
    {
		super(methodName, type, resultType, argType, argName, synthetic, gen);
	}

	/**
	 * Create and return instance of this class.
	 * @param gen target class generator
	 * @return instance of this class
	 */
	public static InitFieldFlags getInstance(BCELClassEnhancer gen)
    {
		return new InitFieldFlags(
			ClassEnhancer.MN_FieldFlagsInitMethod,
			Constants.ACC_PRIVATE | Constants.ACC_STATIC | Constants.ACC_FINAL,
			new ArrayType(Type.BYTE, 1),
			Type.NO_ARGS,
			null,
			true,
			gen);
	}

	public void execute()
    {
        AbstractMemberMetaData fields[] = cmd.getManagedMembers();
        int numFields = (fields == null ? 0 : fields.length);

        // Create array of bytes
		il.append(BCELUtils.getBIPUSH(numFields));
		il.append(factory.createNewArray(Type.BYTE, (short)1));

        // Populate the array elements
		for (int i = 0; i < numFields; i++)
        {
			il.append(InstructionConstants.DUP);
			il.append(BCELUtils.getBIPUSH(i));
			il.append(BCELUtils.getBIPUSH(((AbstractMemberMetaData)fields[i]).getJdoFieldFlag()));
			il.append(InstructionConstants.BASTORE);
		}

		il.append(InstructionConstants.ARETURN);
	}
}