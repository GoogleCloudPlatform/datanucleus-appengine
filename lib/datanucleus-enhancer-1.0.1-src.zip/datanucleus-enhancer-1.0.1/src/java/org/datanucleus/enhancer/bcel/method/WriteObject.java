/**********************************************************************
Copyright (c) 2004 Kikuchi Kousuke and others. All rights reserved.
Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.

Contributors:
    ...
**********************************************************************/
package org.datanucleus.enhancer.bcel.method;

import org.apache.bcel.Constants;
import org.apache.bcel.generic.InstructionConstants;
import org.apache.bcel.generic.ObjectType;
import org.apache.bcel.generic.Type;
import org.datanucleus.enhancer.bcel.BCELClassEnhancer;
import org.datanucleus.enhancer.bcel.BCELClassMethod;

/**
 * Create WriteObject method.
 * @version $Revision: 1.2 $
 */
public class WriteObject extends BCELClassMethod
{
    protected static String CN_ObjectOutputStreamName = "java.io.ObjectOutputStream";

    /**
     * @param methodName
     * @param type
     * @param resultType
     * @param argType
     * @param argName
     * @param synthetic
     * @param gen
     */
    public WriteObject(
        String methodName,
        int type,
        Type resultType,
        Type[] argType,
        String[] argName,
        boolean synthetic,
        BCELClassEnhancer gen)
    {
        super(methodName, type, resultType, argType, argName, synthetic, gen);
    }

    public static WriteObject getInstance(BCELClassEnhancer gen)
    {
        return new WriteObject(
            "writeObject",
            Constants.ACC_PRIVATE | Constants.ACC_FINAL,
            Type.VOID,
            new Type[] { new ObjectType(CN_ObjectOutputStreamName)},
            new String[] { "out" },
            true,
            gen);
    }

    public void execute()
    {
        il.append(InstructionConstants.ALOAD_0);
        il.append(
            factory.createInvoke(
                className,
                "jdoPreSerialize",
                Type.VOID,
                Type.NO_ARGS,
                Constants.INVOKESPECIAL));

       il.append(InstructionConstants.ALOAD_1);
       il.append(
            factory.createInvoke(
                CN_ObjectOutputStreamName,
                "defaultWriteObject",
                Type.VOID,
                Type.NO_ARGS,
                Constants.INVOKEVIRTUAL));
        il.append(InstructionConstants.RETURN);
        methodGen.addException("java.io.IOException");
    }
}
