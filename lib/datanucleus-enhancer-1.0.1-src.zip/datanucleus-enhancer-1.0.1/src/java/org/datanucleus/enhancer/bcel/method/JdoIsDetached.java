/**********************************************************************
Copyright (c) 2004 Erik Bengtson and others. All rights reserved.
Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
 

Contributors:
2005 Andy Jefferson - converted to use "detachedState"
2007 Andy Jefferson - changed to call jdoIsDetachedInternal()
    ...
**********************************************************************/
package org.datanucleus.enhancer.bcel.method;

import org.apache.bcel.Constants;
import org.apache.bcel.generic.IFNONNULL;
import org.apache.bcel.generic.InstructionConstants;
import org.apache.bcel.generic.InstructionHandle;
import org.apache.bcel.generic.Type;
import org.datanucleus.enhancer.ClassEnhancer;
import org.datanucleus.enhancer.bcel.BCELClassEnhancer;
import org.datanucleus.enhancer.bcel.BCELClassMethod;

/**
 * Creates the jdoIsDetached() method found in the root persistent class in a hierarchy. The method looks like this :-
 * <pre>
 * public boolean jdoIsDetached()
 * {
 *     if (jdoStateManager == null && jdoDetachedState != null) 
 *     {
 *         return true;
 *     }
 *     return false;
 * }
 * </pre>
 * and if not detachable will get
 * <pre>
 * public boolean jdoIsDetached()
 * {
 *     return false;
 * }
 * </pre>
 * @version $Revision: 1.4 $
 * @since 1.1
 */
public class JdoIsDetached extends BCELClassMethod
{
    /**
     * @param methodName
     * @param type
     * @param resultType
     * @param argType
     * @param argName
     * @param synthetic
     * @param gen
     */
    public JdoIsDetached(
        String methodName,
        int type,
        Type resultType,
        Type[] argType,
        String[] argName,
        boolean synthetic,
        BCELClassEnhancer gen)
    {
        super(methodName, type, resultType, argType, argName, synthetic, gen);
    }

    public static JdoIsDetached getInstance(BCELClassEnhancer gen)
    {
        return new JdoIsDetached(
            ClassEnhancer.MN_JdoIsDetached,
            Constants.ACC_PUBLIC,
            Type.BOOLEAN,
            Type.NO_ARGS,
            null,
            false,
            gen);
    }

    public void execute()
    {
        if (!enhancer.getClassMetaData().isDetachable())
        {
            // "return false;"
            super.execute();
        }
        else
        {
            // if (jdoStateManager != null)
            il.append(InstructionConstants.ALOAD_0);
            il.append(factory.createGetField(className, ClassEnhancer.FN_StateManager, BCELClassEnhancer.OT_StateManager));

            IFNONNULL ifnonnullSM = new IFNONNULL(null);
            il.append(ifnonnullSM);

            // jdoDetachedState != null
            il.append(InstructionConstants.ALOAD_0);
            il.append(factory.createGetField(className, ClassEnhancer.FN_JdoDetachedState, BCELClassEnhancer.OT_ObjectArray));

            IFNONNULL ifnonnullObjectId = new IFNONNULL(null);
            il.append(ifnonnullObjectId);

            il.append(InstructionConstants.ICONST_0);
            il.append(InstructionConstants.IRETURN);

            ifnonnullObjectId.setTarget(il.append(InstructionConstants.ICONST_1));
            il.append(InstructionConstants.IRETURN);

            // target
            InstructionHandle ifnonnullTarget = il.append(InstructionConstants.ICONST_0);
            ifnonnullSM.setTarget(ifnonnullTarget);

            // return
            il.append(InstructionConstants.IRETURN);
        }
    }
}