/**********************************************************************
Copyright (c) 2004 Kikuchi Kousuke and others. All rights reserved.
Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.

Contributors:
    ...
**********************************************************************/
package org.datanucleus.enhancer.bcel.method;

import org.apache.bcel.Constants;
import org.apache.bcel.generic.ArrayType;
import org.apache.bcel.generic.BasicType;
import org.apache.bcel.generic.InstructionConstants;
import org.apache.bcel.generic.LDC;
import org.apache.bcel.generic.ObjectType;
import org.apache.bcel.generic.Type;
import org.datanucleus.enhancer.ClassEnhancer;
import org.datanucleus.enhancer.bcel.BCELClassEnhancer;
import org.datanucleus.enhancer.bcel.BCELClassMethod;
import org.datanucleus.enhancer.bcel.BCELUtils;
import org.datanucleus.enhancer.bcel.metadata.BCELFieldPropertyMetaData;
import org.datanucleus.enhancer.bcel.metadata.BCELMember;
import org.datanucleus.metadata.AbstractMemberMetaData;

/**
 * Create jdoFieldTypes init method.
 * @version $Revision: 1.9 $
 */
public class InitFieldTypes extends BCELClassMethod
{
    /**
     * @param methodName
     * @param type
     * @param resultType
     * @param argType
     * @param argName
     * @param synthetic
     * @param gen
     */
    public InitFieldTypes(String methodName, int type, Type resultType, Type[] argType, String[] argName,
        boolean synthetic, BCELClassEnhancer gen)
    {
        super(methodName, type, resultType, argType, argName, synthetic, gen);
    }

    /**
     * Create and return instance of this class.
     * @param gen target class generator
     * @return instance of this class
     */
    public static InitFieldTypes getInstance(BCELClassEnhancer gen)
    {
        return new InitFieldTypes(
            ClassEnhancer.MN_FieldTypesInitMethod,
            Constants.ACC_PRIVATE | Constants.ACC_STATIC | Constants.ACC_FINAL,
            new ArrayType(BCELClassEnhancer.OT_CLASS, 1),
            Type.NO_ARGS,
            null,
            true,
            gen);
    }

    protected void loadClass(BCELMember f)
    {
        Type t = f.getType();
        if (t instanceof BasicType)
        {
            String primitiveClassName =
                BCELUtils.getPrimitiveWrapperType((BasicType)f.getType()).getClassName();
            il.append(factory.createGetStatic(primitiveClassName, "TYPE", BCELClassEnhancer.OT_CLASS));
        }
        else if (t instanceof ArrayType)
        {
            String classSig = f.getType().getSignature();
            int cpIndex = constantPoolGen.addString(classSig.replace('/', '.'));
            il.append(new LDC(cpIndex));
            il.append(
                factory.createInvoke(
                    className,
                    ClassEnhancer.MN_jdoLoadClass,
                    BCELClassEnhancer.OT_CLASS,
                    new Type[] { Type.STRING },
                    Constants.INVOKESTATIC));
        }
        else
        {
            int cpIndex = constantPoolGen.addString(((ObjectType)t).getClassName());
            il.append(new LDC(cpIndex));
            il.append(
                factory.createInvoke(
                    className,
                    ClassEnhancer.MN_jdoLoadClass,
                    BCELClassEnhancer.OT_CLASS,
                    new Type[] { Type.STRING },
                    Constants.INVOKESTATIC));

        }
    }

    /* (non-Javadoc)
     * @see org.datanucleus.enhancer.gen.Callback#execute()
     */
    public void execute() 
    {
        AbstractMemberMetaData fields[] = cmd.getManagedMembers();
        int numFields = (fields == null ? 0 : fields.length);

        // Create array of Classes
        il.append(BCELUtils.getBIPUSH(numFields));
        il.append(factory.createNewArray(BCELClassEnhancer.OT_CLASS, (byte)1));

        // Populate the array elements
        for (int i = 0; i < numFields; i++)
        {
            il.append(InstructionConstants.DUP);
            il.append(BCELUtils.getBIPUSH(i));
            loadClass(((BCELFieldPropertyMetaData)fields[i]).getEnhanceField());
            il.append(InstructionConstants.AASTORE);
        }

        il.append(InstructionConstants.ARETURN);
    }
}