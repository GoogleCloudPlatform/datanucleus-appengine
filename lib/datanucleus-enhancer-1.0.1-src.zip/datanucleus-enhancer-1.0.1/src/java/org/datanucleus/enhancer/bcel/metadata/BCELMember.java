/**********************************************************************
Copyright (c) 2007 Erik Bengtson and others. All rights reserved. 
Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License. 
 

Contributors:
    ...
**********************************************************************/
package org.datanucleus.enhancer.bcel.metadata;

import org.apache.bcel.classfile.Attribute;
import org.apache.bcel.classfile.Field;
import org.apache.bcel.classfile.Method;
import org.apache.bcel.generic.Type;
import org.datanucleus.enhancer.bcel.BCELUtils;

/**
 * Wrapper to represent a BCEL Field or BCEL Method in a single class.
 *
 * @version $Revision: 1.1 $
 */
public class BCELMember
{
    final Type type;
    
    final String name;
    
    final Attribute[] attributes;
    
    final int accessFlags;
    
    final boolean synthetic;
    
    final boolean _public;
    
    final boolean _static;
    
    final boolean _final;
    
    final boolean _protected;
    
    final boolean _private;

    final boolean method;
    
    /**
     * Constructor for BCEL Field.
     * @param field
     */
    public BCELMember(Field field)
    {
        this.type = field.getType();
        this.name = field.getName();
        this.attributes = field.getAttributes();
        this.accessFlags = field.getAccessFlags();
        this.synthetic = BCELUtils.isSynthetic(this.attributes);
        this._public = field.isPublic();
        this._static = field.isStatic();
        this._final = field.isFinal();
        this._protected = field.isProtected();
        this._private = field.isPrivate();
        this.method = false;
    }
    
    /**
     * Constructor for BCEL Method.
     * @param method
     */
    public BCELMember(Method method)
    {
        this.type = method.getReturnType();
        this.name = method.getName();
        this.attributes = method.getAttributes();
        this.accessFlags = method.getAccessFlags();
        this.synthetic = BCELUtils.isSynthetic(this.attributes);
        this._public = method.isPublic();
        this._static = method.isStatic();
        this._final = method.isFinal();
        this._protected = method.isProtected();
        this._private = method.isPrivate();        
        this.method = true;
    }
    
    public Type getType()
    {
        return type;
    }
    
    /**
     * @return If this instance wraps a BCEL Method, returns the full getter name (getX or isX)
     */
    public String getName()
    {
        return name;
    }    

    public Attribute[] getAttributes()
    {
        return attributes;
    }
    
    public int getAccessFlags()
    {
        return accessFlags;
    }

    public boolean isSynthetic()
    {
        return synthetic;
    }

    public boolean isFinal()
    {
        return _final;
    }
    
    public boolean isPrivate()
    {
        return _private;
    }
    
    public boolean isProtected()
    {
        return _protected;
    }
    
    public boolean isPublic()
    {
        return _public;
    }
    
    public boolean isStatic()
    {
        return _static;
    }
    
    public boolean isMethod()
    {
        return method;
    }
}