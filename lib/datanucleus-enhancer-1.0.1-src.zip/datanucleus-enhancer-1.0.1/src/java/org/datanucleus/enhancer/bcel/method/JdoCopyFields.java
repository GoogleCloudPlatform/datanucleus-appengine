/**********************************************************************
Copyright (c) 2004 Kikuchi Kousuke and others. All rights reserved.
Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.

Contributors:
    ...
**********************************************************************/
package org.datanucleus.enhancer.bcel.method;


import org.apache.bcel.Constants;
import org.apache.bcel.generic.*;
import org.datanucleus.enhancer.ClassEnhancer;
import org.datanucleus.enhancer.bcel.BCELClassEnhancer;
import org.datanucleus.enhancer.bcel.BCELClassMethod;

/**
 * create jdoCopyFields method.
 * @version $Revision: 1.4 $
 */
public class JdoCopyFields extends BCELClassMethod
{
    /**
     * @param methodName
     * @param type
     * @param resultType
     * @param argType
     * @param argName
     * @param synthetic
     * @param gen
     */
    public JdoCopyFields(
        String methodName,
        int type,
        Type resultType,
        Type[] argType,
        String[] argName,
        boolean synthetic,
        BCELClassEnhancer gen)
    {
        super(methodName, type, resultType, argType, argName, synthetic, gen);
    }

    /**
     * Create and return instance of this class.
     * @param gen target class generator
     * @return instance of this class
     */
    public static JdoCopyFields getInstance(BCELClassEnhancer gen)
    {
        return new JdoCopyFields(
            "jdoCopyFields",
            Constants.ACC_PUBLIC,
            Type.VOID,
            new Type[] { Type.OBJECT, new ArrayType(Type.INT, 1)},
            new String[] { "obj", "fieldNumbers" },
            false,
            gen);
    }

    /* (non-Javadoc)
     * @see org.datanucleus.enhancer.gen.Callback#execute()
     */
    public void execute()
    {
        String illegalStateExceptionName = "java.lang.IllegalStateException";
        InstructionHandle lv_me[] = new InstructionHandle[2];
        InstructionHandle lv_i[] = new InstructionHandle[2];
        InstructionHandle for1[] = new InstructionHandle[2];

        // if(___jdo$StateManager == null)
        // throw new IllegalStateException("state manager is null");
        il.append(InstructionConstants.ALOAD_0);
        il.append(
            factory.createGetField(
                className,
                ClassEnhancer.FN_StateManager,
                BCELClassEnhancer.OT_StateManager));
        IFNONNULL ifnull1 = new IFNONNULL(null);
        il.append(ifnull1);
        createThrowException(illegalStateExceptionName, "state manager is null");

        // if(fieldNumbers == null)
        // throw new IllegalArgumentException("fieldNumbers is null");
        ifnull1.setTarget(il.append(InstructionConstants.ALOAD_2));
        IFNONNULL ifnull2 = new IFNONNULL(null);
        il.append(ifnull2);
        createThrowException(illegalStateExceptionName, "fieldNumbers is null");

        // if(!(obj instanceof TestBean))
        //  throw new IllegalArgumentException("object is TestBean");
        ifnull2.setTarget(il.append(InstructionConstants.ALOAD_1));
        il.append(factory.createInstanceOf(getClassEnhancer().classType));
        il.append(InstructionConstants.ICONST_1);
        IF_ICMPEQ if_icmpeq = new IF_ICMPEQ(null);
        il.append(if_icmpeq);
        createThrowException(ClassEnhancer.CN_IllegalArgumentException, "object is not " + className);

        // TestBean me = (TestBean)obj;
        if_icmpeq.setTarget(il.append(InstructionConstants.ALOAD_1));
        il.append(new CHECKCAST(constantPoolGen.addClass(getClassEnhancer().classType)));
        lv_me[0] = il.append(new ASTORE(3));

        // if(___jdo$StateManager != me.___jdo$StateManager)
        //  throw new IllegalArgumentException("state manager unmatch");
        il.append(InstructionConstants.ALOAD_0);
        il.append(
            factory.createGetField(
                className,
                ClassEnhancer.FN_StateManager,
                BCELClassEnhancer.OT_StateManager));
        il.append(new ALOAD(3));
        il.append(
            factory.createGetField(
                className,
                ClassEnhancer.FN_StateManager,
                BCELClassEnhancer.OT_StateManager));
        IF_ACMPEQ if_acmpeq = new IF_ACMPEQ(null);
        il.append(if_acmpeq);
        createThrowException(ClassEnhancer.CN_IllegalArgumentException, "state manager unmatch");

        if_acmpeq.setTarget(il.append(InstructionConstants.ALOAD_2));
        lv_i[0] = il.append(InstructionConstants.ARRAYLENGTH);
        il.append(InstructionConstants.ICONST_1);
        il.append(InstructionConstants.ISUB);
        il.append(new ISTORE(4));

        il.append(new ILOAD(4));
        BranchInstruction br = new IFLT(null);
        il.append(br);
        
        for1[0] = il.append(InstructionConstants.ALOAD_0);
        il.append(new ALOAD(3));
        il.append(InstructionConstants.ALOAD_2);
        il.append(new ILOAD(4));
        il.append(InstructionConstants.IALOAD);
        il.append(
            factory.createInvoke(
                className,
                "jdoCopyField",
                Type.VOID,
                new Type[] { getClassEnhancer().classType, Type.INT },
                Constants.INVOKEVIRTUAL));

        il.append(new ILOAD(4));
        il.append(InstructionConstants.ICONST_1);
        il.append(InstructionConstants.ISUB);
        il.append(InstructionConstants.DUP);
        il.append(new ISTORE(4));
        il.append(InstructionConstants.ICONST_0);
        il.append(new IF_ICMPGE(for1[0]));

        lv_i[1] = il.append(InstructionConstants.NOP);
        lv_me[1] = il.append(InstructionConstants.RETURN);

        if (br != null)
        {
            br.setTarget(lv_me[1]);
        }
        
        methodGen.addLocalVariable("me", getClassEnhancer().classType, lv_me[0], lv_me[1]);
        methodGen.addLocalVariable("i", Type.INT, lv_i[0], lv_i[1]);
    }
}
