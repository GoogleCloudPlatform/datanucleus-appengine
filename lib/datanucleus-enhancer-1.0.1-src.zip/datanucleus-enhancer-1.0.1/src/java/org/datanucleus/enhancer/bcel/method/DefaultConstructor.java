/**********************************************************************
Copyright (c) 2004 Andy Jefferson and others. All rights reserved.
Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License. 


Contributors:
    ...
**********************************************************************/
package org.datanucleus.enhancer.bcel.method;

import org.apache.bcel.Constants;
import org.apache.bcel.generic.Type;
import org.datanucleus.enhancer.bcel.BCELClassEnhancer;
import org.datanucleus.enhancer.bcel.BCELClassMethod;
import org.datanucleus.util.NucleusLogger;

/**
 * Representation of a (protected) Default Constructor.
 * The constructor simply calls its superclass default constructor.
 * 
 * @version $Revision: 1.2 $
 */
public class DefaultConstructor extends BCELClassMethod
{
    /**
     * Constructor
     * @param methodName Name of the method ("<init>" for a constructor)
     * @param type Access type
     * @param resultType Result type from the method
     * @param argType Argument types
     * @param argName Argument names
     * @param synthetic Whether is synthetic or not
     * @param gen The generator
     */
    public DefaultConstructor(
        String methodName,
        int type,
        Type resultType,
        Type[] argType,
        String[] argName,
        boolean synthetic,
        BCELClassEnhancer gen)
    {
        super(methodName, type, resultType, argType, argName, synthetic, gen);
    }

    public static DefaultConstructor getInstance(BCELClassEnhancer gen)
    {
        return new DefaultConstructor(
            "<init>",
            Constants.ACC_PROTECTED,
            Type.VOID,
            Type.NO_ARGS,
            null,
            false,
            gen);
    }

    /**
     * Execute the method
     */
    public void execute()
    {
        // Nothing to do here, we build it in the close() method.
    }

    /**
     * Close the method, updating the class.
     */
    public void close()
    {
        // Use the BCEL convenience method to add the constructor.
        NucleusLogger.ENHANCER.debug(LOCALISER.msg("Enhancer.AddConstructor", classGen.getClassName() + "()"));
        classGen.addEmptyConstructor(Constants.ACC_PUBLIC);
        classGen.update();
        il.dispose();
    }
}