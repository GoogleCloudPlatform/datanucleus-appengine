/**********************************************************************
Copyright (c) 2004 Kikuchi Kousuke and others. All rights reserved. 
Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License. 
 

Contributors:
2004 Erik Bengtson - added attach/detach support
2004 Andy Jefferson - added isDetachable flag
2005 Andy Jefferson - changed to use "detachedState"
    ...
**********************************************************************/
package org.datanucleus.enhancer.bcel.method;


import org.apache.bcel.Constants;
import org.apache.bcel.generic.GOTO;
import org.apache.bcel.generic.IFNULL;
import org.apache.bcel.generic.IF_ICMPEQ;
import org.apache.bcel.generic.IF_ICMPGT;
import org.apache.bcel.generic.InstructionConstants;
import org.apache.bcel.generic.InstructionHandle;
import org.apache.bcel.generic.Type;
import org.datanucleus.enhancer.ClassEnhancer;
import org.datanucleus.enhancer.bcel.BCELClassEnhancer;
import org.datanucleus.enhancer.bcel.BCELClassMethod;

/**
 * Create jdoIsDirty() method.
 * @version $Revision: 1.5 $
 */
public class JdoIsDirty extends BCELClassMethod 
{
    public static JdoIsDirty getInstance(BCELClassEnhancer gen)
    {
        return new JdoIsDirty("jdoIsDirty", Constants.ACC_PUBLIC | Constants.ACC_FINAL,
            Type.BOOLEAN, Type.NO_ARGS, null, false, gen);
    }

    /**
     * Constructor
     * @param methodName Name of the method
     * @param type
     * @param resultType
     * @param argType
     * @param argName
     * @param synthetic
     * @param gen
     */
    public JdoIsDirty(String methodName, int type, Type resultType, Type[] argType, String[] argName,
        boolean synthetic, BCELClassEnhancer gen)
    {
        super(methodName, type, resultType, argType, argName, synthetic, gen);
    }

    /* (non-Javadoc)
     * @see org.datanucleus.enhancer.gen.Callback#execute()
     */
    public void execute()
    {
        // jdoStateManager
        il.append(InstructionConstants.ALOAD_0);
        il.append(factory.createGetField(className, ClassEnhancer.FN_StateManager, BCELClassEnhancer.OT_StateManager));
        //if (jdoStateManager == null)
        IFNULL ifnull = new IFNULL(null);
        il.append(ifnull);
        // jdoStateManager
        il.append(InstructionConstants.ALOAD_0);
        il.append(factory.createGetField(className, ClassEnhancer.FN_StateManager, BCELClassEnhancer.OT_StateManager));
        // jdoStateManager.isDirty()
        il.append(InstructionConstants.ALOAD_0);
        il.append(factory.createInvoke(ClassEnhancer.CN_StateManager, "isDirty", Type.BOOLEAN, new Type[]{BCELClassEnhancer.OT_PersistenceCapable},
            Constants.INVOKEINTERFACE));

        if (!enhancer.getClassMetaData().isDetachable())
        {
            GOTO go = new GOTO(null);
            il.append(go);
            InstructionHandle ifnullTarget = il.append(InstructionConstants.ICONST_0);
            InstructionHandle gotoTarget = il.append(InstructionConstants.IRETURN);
            ifnull.setTarget(ifnullTarget);
            go.setTarget(gotoTarget);
        }
        else
        {
            il.append(InstructionConstants.IRETURN);

            // jdoIsDetached()
            ifnull.setTarget(il.append(InstructionConstants.ALOAD_0));
            il.append(factory.createInvoke(ClassEnhancer.CN_PersistenceCapable, ClassEnhancer.MN_JdoIsDetached,
                Type.BOOLEAN, Type.NO_ARGS, Constants.INVOKEINTERFACE));

            // 1
            il.append(InstructionConstants.ICONST_1);

            // if (jdoIsDetached() == 1)
            IF_ICMPEQ ifIsDetached = new IF_ICMPEQ(null);
            il.append(ifIsDetached);

            // return 0;
            il.append(InstructionConstants.ICONST_0);
            il.append(InstructionConstants.IRETURN);

            // ((BitSet)jdoDetachedState[3]).length()
            ifIsDetached.setTarget(il.append(InstructionConstants.ALOAD_0));
            il.append(factory.createGetField(className, ClassEnhancer.FN_JdoDetachedState, BCELClassEnhancer.OT_ObjectArray));
            il.append(InstructionConstants.ICONST_3);
            il.append(InstructionConstants.AALOAD);
            il.append(factory.createCheckCast(BCELClassEnhancer.OT_BitSet)); // Cast to BitSet

            il.append(factory.createInvoke(ClassEnhancer.CN_BitSet, "length", Type.INT, Type.NO_ARGS, Constants.INVOKEVIRTUAL));

            //0
            il.append(InstructionConstants.ICONST_0);

            // if ((BitSet)jdoDetachedState[3]).length() > 0)
            IF_ICMPGT ifIsGreater = new IF_ICMPGT(null);
            il.append(ifIsGreater);

            // return 0;
            il.append(InstructionConstants.ICONST_0);
            il.append(InstructionConstants.IRETURN);

            // return 1;
            ifIsGreater.setTarget(il.append(InstructionConstants.ICONST_1));
            il.append(InstructionConstants.IRETURN);

            //this is dead code
            //il.append(InstructionConstants.ICONST_0);
            //il.append(InstructionConstants.IRETURN);
        }
    }
}