/**********************************************************************
Copyright (c) 2004 Kikuchi Kousuke and others. All rights reserved.
Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
 

Contributors:
    ...
**********************************************************************/
package org.datanucleus.enhancer.bcel.method;

import org.apache.bcel.Constants;
import org.apache.bcel.generic.InstructionConstants;
import org.apache.bcel.generic.Type;
import org.datanucleus.enhancer.ClassEnhancer;
import org.datanucleus.enhancer.bcel.BCELClassEnhancer;
import org.datanucleus.enhancer.bcel.BCELClassMethod;
import org.datanucleus.enhancer.bcel.BCELUtils;

/**
 * The generated method returns the number of managed fields in this class plus the number
 * of inherited managed fields. This method is expected to be executed only during class
 * loading of the subclasses.
 * 
 * @version $Revision: 1.7 $
 * @since 1.0.0
 */
public class JdoGetManagedFieldCount extends BCELClassMethod
{
    /**
     * @param methodName
     * @param type
     * @param resultType
     * @param argType
     * @param argName
     * @param synthetic
     * @param gen
     */
    public JdoGetManagedFieldCount(String methodName, int type, Type resultType, Type[] argType,
        String[] argName, boolean synthetic, BCELClassEnhancer gen)
    {
        super(methodName, type, resultType, argType, argName, synthetic, gen);
    }

    public static JdoGetManagedFieldCount getInstance(BCELClassEnhancer gen)
    {
        return new JdoGetManagedFieldCount(
            ClassEnhancer.MN_JdoGetManagedFieldCount,
            Constants.ACC_PROTECTED | Constants.ACC_STATIC,
            Type.INT,
            Type.NO_ARGS,
            null,
            true,
            gen);
    }

    /**
     * Usually this method should generate bytecode as:
     * <code>
     * return jdoFieldNames.length + superClass.jdoGetManagedFieldCount();
     * </code>
     * but due to initializing issues [ENHANCER-58], we use constants instead, e.g.:
     * <code>
     * return <number of managed fields>+superClass.jdoGetManagedFieldCount();
     * </code>
     */
    public void execute()
    {
		String persistenceCapableSuperclass = cmd.getPersistenceCapableSuperclass();
        il.append(BCELUtils.getBIPUSH(cmd.getNoOfManagedMembers()));
		if ((persistenceCapableSuperclass != null) && (persistenceCapableSuperclass.length() > 0))
        {
		    il.append(factory.createInvoke(
					    persistenceCapableSuperclass,
						ClassEnhancer.MN_JdoGetManagedFieldCount,
						Type.INT,
						Type.NO_ARGS,
						Constants.INVOKESTATIC));
			il.append(InstructionConstants.IADD);		    
        }
        il.append(InstructionConstants.IRETURN);
    }
}