/**********************************************************************
Copyright (c) 2005 Erik Bengtson and others. All rights reserved. 
Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
 

Contributors:
2005 Andy Jefferson - changed to use "detachedState"
    ...
**********************************************************************/
package org.datanucleus.enhancer.bcel.method;

import org.apache.bcel.Constants;
import org.apache.bcel.generic.IFNULL;
import org.apache.bcel.generic.IF_ICMPEQ;
import org.apache.bcel.generic.InstructionConstants;
import org.apache.bcel.generic.Type;
import org.datanucleus.enhancer.ClassEnhancer;
import org.datanucleus.enhancer.bcel.BCELClassEnhancer;

/**
 * Creates the jdoGetVersion() method. The generated code looks like :-
 * <pre>
 * if (jdoStateManager != null)
 *     return jdoStateManager.getVersion(this);
 * if (this.jdoIsDetached() != true)
 *     return null;
 * return jdoDetachedState[1];
 * </pre>
 * 
 * @version $Revision: 1.6 $
 */
public class JdoGetVersion extends SimpleStateManagerCall
{
    public static JdoGetVersion getInstance(BCELClassEnhancer gen)
    {
        return new JdoGetVersion(ClassEnhancer.MN_JdoGetVersion, Constants.ACC_PUBLIC | Constants.ACC_FINAL,
            Type.OBJECT, Type.NO_ARGS, null, false, gen);
    }

    /**
     * @param methodName
     * @param type
     * @param resultType
     * @param argType
     * @param argName
     * @param synthetic
     * @param gen
     */
    public JdoGetVersion(String methodName, int type, Type resultType, Type[] argType, String[] argName,
        boolean synthetic, BCELClassEnhancer gen)
    {
        super(methodName, type, resultType, argType, argName, synthetic, gen, "getVersion");
    }

	/* (non-Javadoc)
	 * @see org.datanucleus.enhancer.gen.Callback#execute()
	 */
	public void execute()
    {
	    if (!enhancer.getClassMetaData().isDetachable())
        {
            super.execute();
        }
        else
        {
            // if (jdoStateManager == null)
            il.append(InstructionConstants.ALOAD_0);
            il.append(factory.createGetField(className, ClassEnhancer.FN_StateManager, BCELClassEnhancer.OT_StateManager));

            IFNULL ifnull = new IFNULL(null);
            il.append(ifnull);

            // jdoStateManager.getVersion(this)
            // jdoStateManager
            il.append(InstructionConstants.ALOAD_0);
            il.append(factory.createGetField(className, ClassEnhancer.FN_StateManager, BCELClassEnhancer.OT_StateManager));

            // getVersion(this)
            il.append(InstructionConstants.ALOAD_0);
            il.append(factory.createInvoke(ClassEnhancer.CN_StateManager, "getVersion", (Type)returnType, 
                new Type[]{BCELClassEnhancer.OT_PersistenceCapable}, Constants.INVOKEINTERFACE));
            il.append(InstructionConstants.ARETURN);

            // jdoIsDetached()
            ifnull.setTarget(il.append(InstructionConstants.ALOAD_0));
            il.append(factory.createInvoke(ClassEnhancer.CN_PersistenceCapable, ClassEnhancer.MN_JdoIsDetached, 
                Type.BOOLEAN, Type.NO_ARGS, Constants.INVOKEINTERFACE));

            // 0
            il.append(InstructionConstants.ICONST_1);
            // if (jdoIsDetached() == 1)
            IF_ICMPEQ ifIsDetached = new IF_ICMPEQ(null);
            il.append(ifIsDetached);
            // return null;
            il.append(InstructionConstants.ACONST_NULL);
            il.append(InstructionConstants.ARETURN);

            // return jdoDetachedState[1];
            ifIsDetached.setTarget(il.append(InstructionConstants.ALOAD_0));
            il.append(factory.createGetField(className, ClassEnhancer.FN_JdoDetachedState, BCELClassEnhancer.OT_ObjectArray));
            il.append(InstructionConstants.ICONST_1);
            il.append(InstructionConstants.AALOAD);

            il.append(InstructionConstants.ARETURN);
        }
    }
}