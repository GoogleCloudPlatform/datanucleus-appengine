/**********************************************************************
Copyright (c) 2006 Erik Bengtson and others. All rights reserved.
Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.

Contributors:
2007 Andy Jefferson - fixed keying of classes in Repository to use class name
    ...
**********************************************************************/
package org.datanucleus.enhancer.bcel;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.net.URL;
import java.util.HashMap;
import java.util.Map;

import org.apache.bcel.classfile.ClassFormatException;
import org.apache.bcel.classfile.ClassParser;
import org.apache.bcel.classfile.JavaClass;
import org.apache.bcel.util.ClassPath;
import org.apache.bcel.util.Repository;
import org.datanucleus.ClassLoaderResolver;
import org.datanucleus.util.StringUtils;

/**
 * Custom repository used by BCEL to search for classes.
 * The repository is customized to search classes using the {@link ClassLoaderResolver}.
 * 
 * @version $Revision: 1.4 $
 */
public class JPOXRepository implements Repository
{
    /** ClassLoaderResolver **/
    final ClassLoaderResolver clr;
    
    /** map of JavaClass keyed by the class name **/
    Map classes = new HashMap();

    /**
     * Constructor
     * @param clr the ClassLoaderResolver
     */
    public JPOXRepository(ClassLoaderResolver clr)
    {
        this.clr = clr;
    }
    
    /**
     * Clear all classes in cache
     */
    public void clear()
    {
        classes.clear();
    }

    /**
     * Find a class by searching in the classpath resources
     * @param className the fully qualified class name
     * @return the JavaClass of the className
     */
    public JavaClass findClass(String className)
    {
        JavaClass javaClass = (JavaClass)classes.get(className);
        if (javaClass == null)
        {
            String resource = StringUtils.replaceAll(className, ".", "/") + ".class";
            try
            {
                if (clr.getResource(resource,null) == null)
                {
                    return null;
                }
                ClassParser parser = new ClassParser(clr.getResource(resource, null).openStream(), null);
                javaClass = parser.parse();
                javaClass.setRepository(this);
            }
            catch (IOException e)
            {
                throw new RuntimeException(e);
            }
            catch (ClassFormatException e)
            {
                throw new RuntimeException(e);
            }

            classes.put(className, javaClass);
        }

        return javaClass;
    }

    /**
     * Define a class
     * @param className the fully qualified class name
     * @param bytes
     */
    public void defineClass(String className, byte[] bytes)
    {
        JavaClass javaClass;
        try
        {
            ClassParser parser = new ClassParser(new ByteArrayInputStream(bytes), null);
            javaClass = parser.parse();
            javaClass.setRepository(this);
        }
        catch (IOException e)
        {
            throw new RuntimeException(e);
        }
        catch (ClassFormatException e)
        {
            throw new RuntimeException(e);
        }

        classes.put(className, javaClass);
    }

    /**
     * Retrieve the URL of a class by searching in the classpath resources
     * @param className the fully qualified class name
     * @return the URL or null
     */
    public URL getURL(String className)
    {
        String resource = StringUtils.replaceAll(className, ".", "/")+".class";
        return clr.getResource(resource,null);
    }
    
    /**
     * Accessor to the ClassPath 
     * @return an empty classpath, since not used anywhere
     */
    public ClassPath getClassPath()
    {
        return ClassPath.SYSTEM_CLASS_PATH;
    }

    /**
     * Find a class by searching in the classpath resources
     * @param className the fully qualified class name
     * @return the JavaClass of the className
     */
    public JavaClass loadClass(String className) throws ClassNotFoundException
    {
        return findClass(className);
    }

    /**
     * Find a class by searching in the classpath resources
     * @param cls the class
     * @return the JavaClass of the class
     */
    public JavaClass loadClass(Class cls) throws ClassNotFoundException
    {
        return findClass(cls.getName());
    }

    /**
     * Remove the JavaClass from the cache
     * @param javaClass the class to be removed
     */
    public void removeClass(JavaClass javaClass)
    {
        classes.remove(javaClass.getClassName());
    }

    /**
     * Store the JavaClass in the cache. The cache is keyed by {@link JavaClass#getClassName()}
     * @param javaClass the class to be stored
     */
    public void storeClass(JavaClass javaClass)
    {
        classes.put(javaClass.getClassName(), javaClass);
    }
}