package org.datanucleus.enhancer.samples;

import java.io.Serializable;

/**
 * @version $Revision: 1.1 $
 */
public class SerializableClass implements Serializable
{
	/**
	 * 
	 */
	public SerializableClass()
    {
		super();
	}
}
