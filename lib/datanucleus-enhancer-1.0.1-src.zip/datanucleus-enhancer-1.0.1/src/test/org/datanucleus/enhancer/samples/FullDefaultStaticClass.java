package org.datanucleus.enhancer.samples;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.*;

/**
 * @version $Revision: 1.1 $
 */
public class FullDefaultStaticClass
{
	static boolean field00;
	static byte field01;
	static short field02;
	static char field03;
	static int field04;
	static float field05;
	static long field06;
	static double field07;

	static Boolean field08;
	static Byte field09;
	static Short field10;
	static Character field11;
	static Integer field12;
	static Float field13;
	static Long field14;
	static Double field15;

	static String field16;
	static Number field17;

	static BigDecimal field18;
	static BigInteger field19;

	static Date field20;
	static Locale field21;
	static ArrayList field22;
	static HashMap field23;
	static HashSet field24;
	static Hashtable field25;
	static LinkedList field26;
	static TreeMap field27;
	static TreeSet field28;
	static Vector field29;
	static Collection field30;
	static Set field31;
	static List field32;
	static Map field33;

	static FullDefaultStaticClass field34;

	static boolean field35[];
	static byte field36[];
	static short field37[];
	static char field38[];
	static int field39[];
	static float field40[];
	static long field41[];
	static double field42[];

	static Boolean field43[];
	static Byte field44[];
	static Short field45[];
	static Character field46[];
	static Integer field47[];
	static Float field48[];
	static Long field49[];
	static Double field50[];

	static String field51[];
	static Number field52[];

	static Date field53[];
	static Locale field54[];

	static java.io.File n01;
	static Void n02;
	static UserDefinedClass n03;
	/**
	 * 
	 */
	public FullDefaultStaticClass()
    {
        //default constructor
	}
}
