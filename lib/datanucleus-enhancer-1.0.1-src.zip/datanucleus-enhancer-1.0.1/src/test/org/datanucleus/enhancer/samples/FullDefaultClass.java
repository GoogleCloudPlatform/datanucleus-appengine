package org.datanucleus.enhancer.samples;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.*;

/**
 * @version $Revision: 1.1 $
 */
public class FullDefaultClass
{
	boolean field00;
	byte field01;
	short field02;
	char field03;
	int field04;
	float field05;
	long field06;
	double field07;

	Boolean field08;
	Byte field09;
	Short field10;
	Character field11;
	Integer field12;
	Float field13;
	Long field14;
	Double field15;

	String field16;
	Number field17;

	BigDecimal field18;
	BigInteger field19;

	Date field20;
	Locale field21;
	ArrayList field22;
	HashMap field23;
	HashSet field24;
	Hashtable field25;
	LinkedList field26;
	TreeMap field27;
	TreeSet field28;
	Vector field29;
	Collection field30;
	Set field31;
	List field32;
	Map field33;

	FullDefaultClass field34;

	boolean field35[];
	byte field36[];
	short field37[];
	char field38[];
	int field39[];
	float field40[];
	long field41[];
	double field42[];

	Boolean field43[];
	Byte field44[];
	Short field45[];
	Character field46[];
	Integer field47[];
	Float field48[];
	Long field49[];
	Double field50[];

	String field51[];
	Number field52[];

	Date field53[];
	Locale field54[];

	java.io.File n01;
	Void n02;
	UserDefinedClass n03;
	/**
	 * 
	 */
	public FullDefaultClass()
    {
        //default constructor
	}
}
