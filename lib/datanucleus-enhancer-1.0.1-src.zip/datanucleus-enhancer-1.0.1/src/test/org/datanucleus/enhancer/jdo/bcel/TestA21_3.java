/**********************************************************************
Copyright (c) 2007 Andy Jefferson and others. All rights reserved.
Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.

Contributors:
    ...
**********************************************************************/
package org.datanucleus.enhancer.jdo.bcel;

import org.datanucleus.JDOClassLoaderResolver;
import org.datanucleus.enhancer.ClassEnhancer;
import org.datanucleus.enhancer.bcel.BCELClassEnhancer;
import org.datanucleus.enhancer.bcel.metadata.BCELMetaDataFactory;
import org.datanucleus.metadata.ClassMetaData;
import org.datanucleus.metadata.MetaDataFactory;
import org.datanucleus.metadata.MetaDataManager;

/**
 * 
 * @version $Revision: 1.1 $
 */
public class TestA21_3 extends org.datanucleus.enhancer.jdo.TestA21_3
{
    /**
     * Accessor for a MetaDataFactory to use when enhancing.
     * @param mgr MetaDataManager
     * @return The MetaData factory
     */
    public MetaDataFactory getMetaDataFactory(MetaDataManager mgr)
    {
        return new BCELMetaDataFactory(mgr);
    }

    /**
     * Accessor for a ClassEnhancer to use in enhancing.
     * @param cmd ClassMetaData.
     * @return The ClassEnhancer for this class
     */
    public ClassEnhancer getClassEnhancer(ClassMetaData cmd)
    {
        return new BCELClassEnhancer(cmd, new JDOClassLoaderResolver());
    }
}