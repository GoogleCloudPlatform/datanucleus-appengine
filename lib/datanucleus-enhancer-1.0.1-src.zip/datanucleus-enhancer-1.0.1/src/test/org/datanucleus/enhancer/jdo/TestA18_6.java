package org.datanucleus.enhancer.jdo;

import org.datanucleus.exceptions.NucleusUserException;
import org.datanucleus.metadata.InvalidMetaDataException;
import org.datanucleus.util.JavaUtils;

/**
 * Tests for ClassMetaData.
 * @version $Revision: 1.3 $
 */
public abstract class TestA18_6 extends JDOTestBase
{
    public void testNameAttributeReqired()
    {
        try
        {
            getEnhancedClassesFromFile("org/datanucleus/enhancer/samples/A18_6_no_name.jdo");
        }
        catch (InvalidMetaDataException e)
        {
            assertEquals("MetaData.Class.NameNotSpecified.Error", e.getMessageKey());
        }
        catch (RuntimeException e)
        {
            if (JavaUtils.isJRE1_4OrAbove())
            {
                assertTrue(NucleusUserException.class.isAssignableFrom(e.getClass()));
            }
		}
        catch (Throwable e) 
        {
            e.printStackTrace();
            fail(e.getClass().getName() + ": " + e.getMessage());
        }

        try
        {
            getEnhancedClassesFromFile("org/datanucleus/enhancer/samples/A18_6_has_name.jdo");
        }
        catch (InvalidMetaDataException e)
        {
            fail(e.getMessageKey());
        }
        catch (Throwable e)
        {
            e.printStackTrace();
            fail(e.getClass().getName() + ": " + e.getMessage());
        }
    }
}