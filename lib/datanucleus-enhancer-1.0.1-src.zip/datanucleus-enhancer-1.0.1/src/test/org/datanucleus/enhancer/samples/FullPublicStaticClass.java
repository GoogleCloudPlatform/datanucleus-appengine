package org.datanucleus.enhancer.samples;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.*;

/**
 * @version $Revision: 1.1 $
 */
public class FullPublicStaticClass
{
	public static boolean field00;
	public static byte field01;
	public static short field02;
	public static char field03;
	public static int field04;
	public static float field05;
	public static long field06;
	public static double field07;

	public static Boolean field08;
	public static Byte field09;
	public static Short field10;
	public static Character field11;
	public static Integer field12;
	public static Float field13;
	public static Long field14;
	public static Double field15;

	public static String field16;
	public static Number field17;

	public static BigDecimal field18;
	public static BigInteger field19;

	public static Date field20;
	public static Locale field21;
	public static ArrayList field22;
	public static HashMap field23;
	public static HashSet field24;
	public static Hashtable field25;
	public static LinkedList field26;
	public static TreeMap field27;
	public static TreeSet field28;
	public static Vector field29;
	public static Collection field30;
	public static Set field31;
	public static List field32;
	public static Map field33;

	public static FullPublicStaticClass field34;

	public static boolean field35[];
	public static byte field36[];
	public static short field37[];
	public static char field38[];
	public static int field39[];
	public static float field40[];
	public static long field41[];
	public static double field42[];

	public static Boolean field43[];
	public static Byte field44[];
	public static Short field45[];
	public static Character field46[];
	public static Integer field47[];
	public static Float field48[];
	public static Long field49[];
	public static Double field50[];

	public static String field51[];
	public static Number field52[];

	public static Date field53[];
	public static Locale field54[];

	public static java.io.File n01;
	public static Void n02;
	public static UserDefinedClass n03;
	/**
	 * 
	 */
	public FullPublicStaticClass() 
    {
        //default constructor
	}
}
