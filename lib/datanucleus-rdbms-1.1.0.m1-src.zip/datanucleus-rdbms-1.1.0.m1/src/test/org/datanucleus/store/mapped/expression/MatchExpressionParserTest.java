/**********************************************************************
Copyright (c) 2004 Erik Bengtson and others. All rights reserved.
Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
 

Contributors:
    ...
**********************************************************************/
package org.datanucleus.store.mapped.expression;

import org.datanucleus.store.mapped.expression.MatchExpressionParser;

import junit.framework.TestCase;

/**
 * Series of tests for the String "matches" function.
 * @version $Revision: 1.4 $
 */
public class MatchExpressionParserTest extends TestCase
{
    public void testParsePattern()
    {
        //testZZteteAAyyy.dede\--
        String str = "test.*tete.yyy\\.dede\\\\--";
        MatchExpressionParser parser = new MatchExpressionParser(str,'Z','A','\\');
        String parsed = parser.parsePattern();
        String str_correct = "testZteteAyyy.dede\\\\\\\\--";
        assertTrue("Parsing mised expression gave erroneous string : " + parsed + " but should have been " + str_correct,parsed.equals(str_correct));

        // Empty string
        MatchExpressionParser parser2 = new MatchExpressionParser("",'Z','A','\\');
        assertEquals("",parser2.parsePattern());

        // Any character
        str = ".output.";
        MatchExpressionParser parser3 = new MatchExpressionParser(".putput.",'Z','A','\\');
        parsed = parser3.parsePattern();
        str_correct = "AputputA";
        assertEquals(str_correct, parsed);

        // "slash\city"
        str = "\"slash\\city\"";
        MatchExpressionParser parser4 = new MatchExpressionParser(str,'Z','A','\\');
        parsed = parser4.parsePattern();
        str_correct = "\"slash\\\\city\"";
        assertEquals(str_correct, parsed);
    }
}
