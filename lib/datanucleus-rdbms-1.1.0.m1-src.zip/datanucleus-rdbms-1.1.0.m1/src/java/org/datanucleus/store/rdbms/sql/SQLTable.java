/**********************************************************************
Copyright (c) 2008 Andy Jefferson and others. All rights reserved.
Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.

Contributors:
    ...
**********************************************************************/
package org.datanucleus.store.rdbms.sql;

import org.datanucleus.store.mapped.DatastoreContainerObject;
import org.datanucleus.store.mapped.DatastoreIdentifier;

/**
 * Representation of a table reference in an SQL statement.
 * Has a table, and an alias.
 */
public class SQLTable
{
    protected DatastoreContainerObject table;
    protected DatastoreIdentifier alias;

    public SQLTable(DatastoreContainerObject tbl, DatastoreIdentifier alias)
    {
        this.table = tbl;
        this.alias = alias;
    }

    public DatastoreContainerObject getTable()
    {
        return table;
    }

    public DatastoreIdentifier getAlias()
    {
        return alias;
    }

    /**
     * Stringifier method to return "MYTABLE T1" (when an alias is present) or simply "MYTABLE".
     * @return The string form
     */
    public String toString()
    {
        return table.toString() + (alias != null ? alias.toString() : "");
    }
}