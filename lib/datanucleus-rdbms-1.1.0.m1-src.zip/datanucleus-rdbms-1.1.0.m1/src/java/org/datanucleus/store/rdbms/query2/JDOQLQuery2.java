/**********************************************************************
Copyright (c) 2008 Andy Jefferson and others. All rights reserved.
Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.

Contributors:
    ...
**********************************************************************/
package org.datanucleus.store.rdbms.query2;

import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.Map;

import org.datanucleus.ClassLoaderResolver;
import org.datanucleus.ManagedConnection;
import org.datanucleus.ObjectManager;
import org.datanucleus.exceptions.NucleusException;
import org.datanucleus.query.compiler.QueryCompilation;
import org.datanucleus.query.evaluator.JDOQLEvaluator;
import org.datanucleus.query.evaluator.JavaQueryEvaluator;
import org.datanucleus.store.mapped.DatastoreClass;
import org.datanucleus.store.mapped.query.StatementText;
import org.datanucleus.store.query.AbstractJDOQLQuery;
import org.datanucleus.store.query.Query;
import org.datanucleus.store.rdbms.RDBMSManager;
import org.datanucleus.store.rdbms.SQLController;
import org.datanucleus.store.rdbms.query.QueryStatement;
import org.datanucleus.store.rdbms.query.RDBMSQueryUtils;
import org.datanucleus.util.NucleusLogger;

/**
 * RDBMS representation of a JDOQL query for use by DataNucleus.
 * The query can be specified via method calls, or via a single-string form.
 * This implementation uses the generic query compilation in "org.datanucleus.query"
 * and will ultimately replace the version in "JDOQLQuery".
 */
public class JDOQLQuery2 extends AbstractJDOQLQuery
{
    /**
     * Constructs a new query instance that uses the given object manager.
     * @param om The ObjectManager
     */
    public JDOQLQuery2(ObjectManager om)
    {
        this(om, (JDOQLQuery2) null);
    }

    /**
     * Constructs a new query instance having the same criteria as the given query.
     * @param om The ObjectManager
     * @param q The query from which to copy criteria.
     */
    public JDOQLQuery2(ObjectManager om, JDOQLQuery2 q)
    {
        super(om, q);
    }

    /**
     * Constructor for a JDOQL query where the query is specified using the "Single-String" format.
     * @param om The ObjectManager
     * @param query The single-string query form
     */
    public JDOQLQuery2(ObjectManager om, String query)
    {
        super(om, query);
    }

    protected Object performExecute(Map parameters)
    {
        ClassLoaderResolver clr = om.getClassLoaderResolver();

        if (candidateCollection != null && candidateCollection.isEmpty())
        {
            return Collections.EMPTY_LIST;
        }

        boolean inMemory = false;
        String queryInMemoryStr = (String)getExtension("datanucleus.query.evaluateInMemory");
        if (queryInMemoryStr != null && queryInMemoryStr.equalsIgnoreCase("true"))
        {
            inMemory = true;
        }

        ManagedConnection mconn = om.getStoreManager().getConnection(om);
        try
        {
            // Execute the query
            long startTime = System.currentTimeMillis();
            if (NucleusLogger.QUERY.isDebugEnabled())
            {
                NucleusLogger.QUERY.debug(LOCALISER.msg("021046", "JDOQL", getSingleStringQuery(), null));
            }
            List candidates = null;
            boolean filterInMemory = false;
            boolean orderingInMemory = false;

            if (candidateCollection == null)
            {
                if (inMemory)
                {
                    // TODO Retrieve all possible candidates
                    filterInMemory = true;
                    orderingInMemory = true;
                }
                else
                {
                    // Create the native query for this compiled query
                    QueryStatement qs = getNativeQueryForCompiledQuery(compilation, parameters);
                    boolean useUpdateLock = RDBMSQueryUtils.useUpdateLockForQuery(this);
                    StatementText stmtText = null;
                    if (type == Query.SELECT)
                    {
                        stmtText = qs.toStatementText(useUpdateLock);
                    }
                    else if (type == Query.BULK_UPDATE)
                    {
                        stmtText = qs.toUpdateStatementText();
                        throw new NucleusException("DataNucleus doesnt currently support bulk update statements");
                    }
                    else if (type == Query.BULK_DELETE)
                    {
                        // TODO Distinguish between update and delete
                        stmtText = qs.toDeleteStatementText();
                        throw new NucleusException("DataNucleus doesnt currently support bulk delete statements");
                    }
                    NucleusLogger.QUERY.debug(">> statement=" + stmtText);

                    try
                    {
                        SQLController sqlControl = ((RDBMSManager)getStoreManager()).getSQLController();
                        PreparedStatement ps = RDBMSQueryUtils.getPreparedStatementForQuery(mconn, stmtText, this);
                        try
                        {
                            // Apply timeouts, result set constraints etc to the PreparedStatement
                            RDBMSQueryUtils.prepareStatementForExecution(ps, this);

                            if (type == Query.SELECT)
                            {
                                // SELECT query
                                /*ResultSet rs = */sqlControl.executeStatementQuery(mconn, stmtText.toString(), ps);
                                // TODO Process this and return it. Make sure all objects have StateManagers
                            }
                        }
                        catch (SQLException sqle)
                        {
                            throw new NucleusException("Exception thrown in query", sqle);
                        }
                    }
                    catch (SQLException sqle)
                    {
                        throw new NucleusException("Exception thrown in query", sqle);
                    }
                }
            }
            else
            {
                candidates = new ArrayList(candidateCollection);
                filterInMemory = true;
                orderingInMemory = true;
            }

            // Apply any restrictions to the results (that we can't use in the native query)
            JavaQueryEvaluator resultMapper = new JDOQLEvaluator(this, candidates, compilation, clr);
            Collection results = resultMapper.execute(filterInMemory, orderingInMemory, true, true, true);

            if (NucleusLogger.QUERY.isDebugEnabled())
            {
                NucleusLogger.QUERY.debug(LOCALISER.msg("021074", "JDOQL", "" + (System.currentTimeMillis() - startTime)));
            }

            return results;
        }
        finally
        {
            mconn.release();
        }
    }

    /**
     * Method to return a (native) query statement for the compiled query.
     * @param compilation Compiled query
     * @param parameters Input parameters
     * @return The native (SQL) query statement for this RDBMS datastore
     * TODO Change this to not use QueryStatement
     */
    private QueryStatement getNativeQueryForCompiledQuery(QueryCompilation compilation, Map parameters)
    {
        QueryStatement qs = null;

        RDBMSManager storeMgr = (RDBMSManager)getStoreManager();
        ClassLoaderResolver clr = getObjectManager().getClassLoaderResolver();
        if (candidateCollection != null)
        {
            // TODO Create QueryStatement and restrict to just the candidate instances
        }
        else
        {
            // TODO Make use of Extent to create QueryStatement
            DatastoreClass candidateTable = storeMgr.getDatastoreClass(candidateClass.getName(), clr);
            qs = new QueryStatement(candidateTable, clr);

            if (result != null)
            {
                // Select result column(s)
            }
            else
            {
                // Select identity field(s) for candidate
            }
        }

        // TODO Process the filter, ordering, result, etc and apply to the QueryStatement

        return qs;
    }
}