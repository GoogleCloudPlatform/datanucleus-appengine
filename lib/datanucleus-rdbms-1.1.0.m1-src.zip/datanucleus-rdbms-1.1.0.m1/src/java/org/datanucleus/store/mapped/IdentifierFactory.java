/**********************************************************************
Copyright (c) 2005 Erik Bengtson and others. All rights reserved.
Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.

Contributors:
2006 Andy Jefferson - changed to interface
    ...
**********************************************************************/
package org.datanucleus.store.mapped;

import org.datanucleus.ClassLoaderResolver;
import org.datanucleus.metadata.AbstractClassMetaData;
import org.datanucleus.metadata.AbstractMemberMetaData;

/**
 * Factory that creates immutable instances of DatastoreIdentifier.
 * Identifiers are of a particular type. Each datastore could invent its own  particular types
 * as required, just that the ones here should be the principal types required.
 *
 * @version $Revision: 1.16 $
 */
public interface IdentifierFactory
{
    /** Representation of an identifier specified in UPPER CASE */
    public static final int IDENTIFIER_UPPER_CASE = 0;

    /** Representation of an identifier specified in "UPPER CASE" */
    public static final int IDENTIFIER_UPPER_CASE_QUOTED = 1;

    /** Representation of an identifier specified in lower case. */
    public static final int IDENTIFIER_LOWER_CASE = 2;

    /** Representation of an identifier specified in "lower case" */
    public static final int IDENTIFIER_LOWER_CASE_QUOTED = 3;

    /** Representation of an identifier specified in Mixed Case. */
    public static final int IDENTIFIER_MIXED_CASE = 4;

    /** Representation of an identifier specified in "Mixed Case". */
    public static final int IDENTIFIER_MIXED_CASE_QUOTED = 5;

    // TODO Not all of these statics are applicable to all datastores, so maybe trim them down and move some to RDBMS */
    /** identifier for table names **/
    public final static int TABLE = 0;

    /** column **/
    public final static int COLUMN = 1;

    /** foreign key **/
    public final static int FOREIGN_KEY = 2;

    /** index **/
    public final static int INDEX = 3;

    /** candidate key - unique index constraint **/
    public final static int CANDIDATE_KEY = 4;

    /** primary key **/
    public final static int PRIMARY_KEY = 5;

    /** identifier for datastore sequence. */
    public final static int SEQUENCE = 6;

    /**
     * Accessor for the datastore adapter that we are creating identifiers for.
     * @return The datastore adapter
     */
    DatastoreAdapter getDatastoreAdapter();

    /**
     * Accessor for the identifier case being used.
     * @return The identifier case
     */
    int getIdentifierCase();

    /**
     * Convenience method to return the name for the identifier case.
     * @return Identifier case name
     */
    String getNameOfIdentifierCase();

    /**
     * Accessor for an identifier for use in the datastore adapter
     * @param identifier The identifier name
     * @return Identifier name for use with the datastore adapter
     */
    String getIdentifierInAdapterCase(String identifier);

    /**
     * To be called when we want an identifier name creating based on the
     * identifier. Creates identifier for COLUMN, FOREIGN KEY, INDEX and TABLE
     * @param identifierType the type of identifier to be created
     * @param sqlIdentifier The SQL identifier name
     * @return The DatastoreIdentifier
     */
    DatastoreIdentifier newIdentifier(int identifierType, String sqlIdentifier);

    /**
     * Method to use to generate an identifier for a datastore field with the supplied name.
     * The passed name will not be changed (other than in its case) although it may
     * be truncated to fit the maximum length permitted for a datastore field identifier.
     * @param identifierName The identifier name
     * @return The DatastoreIdentifier for the table
     */
    DatastoreIdentifier newDatastoreContainerIdentifier(String identifierName);

    /**
     * Method to return a Table identifier for the specified class.
     * @param clr the ClassLoaderResolver
     * @param md Meta data for the class
     * @return The identifier for the table
     **/
    DatastoreIdentifier newDatastoreContainerIdentifier(ClassLoaderResolver clr, AbstractClassMetaData md);

    /**
     * Method to return a Table identifier for the specified field.
     * @param clr the ClassLoaderResolver
     * @param fmd Meta data for the field
     * @return The identifier for the table
     **/
    DatastoreIdentifier newDatastoreContainerIdentifier(ClassLoaderResolver clr, AbstractMemberMetaData fmd);

    /**
     * Method to use to generate an identifier for a datastore field with the supplied name.
     * The passed name will not be changed (other than in its case) although it may
     * be truncated to fit the maximum length permitted for a datastore field identifier.
     * @param identifierName The identifier name
     * @return The DatastoreIdentifier
     */
    DatastoreIdentifier newDatastoreFieldIdentifier(String identifierName);

    /**
     * Method to create an identifier for a datastore field where we want the
     * name based on the supplied java name, and the field has a particular
     * role (and so could have its naming set according to the role).
     * @param javaName The java field name
     * @param embedded Whether the identifier is for a field embedded
     * @param fieldRole The role to be performed by this column e.g FK, Index ?
     * @return The DatastoreIdentifier
     */
    DatastoreIdentifier newDatastoreFieldIdentifier(String javaName, boolean embedded, int fieldRole);

    /**
     * Method to generate an identifier name for reference field, based on the metadata for the
     * field, and the ClassMetaData for the implementation.
     * @param refMetaData the MetaData for the reference field
     * @param implMetaData the AbstractClassMetaData for this implementation
     * @param implIdentifier PK identifier for the implementation
     * @param embedded Whether the identifier is for a field embedded
     * @param fieldRole The role to be performed by this column e.g FK, collection element ?
     * @return The DatastoreIdentifier
     */
    DatastoreIdentifier newReferenceFieldIdentifier(AbstractMemberMetaData refMetaData, 
            AbstractClassMetaData implMetaData, DatastoreIdentifier implIdentifier, boolean embedded, int fieldRole);

    /**
     * Method to return an identifier for a discriminator datastore field.
     * @return The discriminator datastore field identifier
     */
    DatastoreIdentifier newDiscriminatorFieldIdentifier();

    /**
     * Method to return an identifier for a version datastore field.
     * @return The version datastore field identifier
     */
    DatastoreIdentifier newVersionFieldIdentifier();

    /**
     * Method to return a new Identifier based on the passed identifier, but adding on the passed suffix
     * @param identifier The current identifier
     * @param suffix The suffix
     * @return The new identifier
     */
    DatastoreIdentifier newIdentifier(DatastoreIdentifier identifier, String suffix);
}