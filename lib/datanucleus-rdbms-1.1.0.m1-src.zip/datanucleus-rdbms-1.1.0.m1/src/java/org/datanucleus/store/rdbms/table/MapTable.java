/**********************************************************************
Copyright (c) 2002 Kelly Grizzle and others. All rights reserved.
Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
 

Contributors:
2002 Mike Martin - unknown changes
2003 Andy Jefferson - added localiser
2003 Andy Jefferson - replaced TableMetadata with identifier
2004 Marco Schulze - added advance-check via TypeManager.isSupportedType(...)
2005 Andy Jefferson - only create ADPT column when necessary
2005 Andy Jefferson - enabled ability to have embedded keys/values
    ...
**********************************************************************/
package org.datanucleus.store.rdbms.table;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.datanucleus.ClassLoaderResolver;
import org.datanucleus.exceptions.NucleusUserException;
import org.datanucleus.metadata.AbstractMemberMetaData;
import org.datanucleus.metadata.ColumnMetaData;
import org.datanucleus.metadata.FieldRole;
import org.datanucleus.metadata.ForeignKeyMetaData;
import org.datanucleus.metadata.IdentityType;
import org.datanucleus.metadata.IndexMetaData;
import org.datanucleus.metadata.KeyMetaData;
import org.datanucleus.metadata.MapMetaData;
import org.datanucleus.metadata.PrimaryKeyMetaData;
import org.datanucleus.metadata.UniqueMetaData;
import org.datanucleus.metadata.ValueMetaData;
import org.datanucleus.store.exceptions.NoTableManagedException;
import org.datanucleus.store.mapped.DatastoreClass;
import org.datanucleus.store.mapped.DatastoreIdentifier;
import org.datanucleus.store.mapped.DatastoreMap;
import org.datanucleus.store.mapped.mapping.EmbeddedKeyPCMapping;
import org.datanucleus.store.mapped.mapping.EmbeddedValuePCMapping;
import org.datanucleus.store.mapped.mapping.JavaTypeMapping;
import org.datanucleus.store.mapped.mapping.PersistenceCapableMapping;
import org.datanucleus.store.mapped.mapping.ReferenceMapping;
import org.datanucleus.store.rdbms.RDBMSManager;
import org.datanucleus.store.rdbms.adapter.RDBMSAdapter;
import org.datanucleus.store.rdbms.key.CandidateKey;
import org.datanucleus.store.rdbms.key.ForeignKey;
import org.datanucleus.store.rdbms.key.Index;
import org.datanucleus.store.rdbms.sqlidentifier.RDBMSIdentifierFactory;
import org.datanucleus.util.ClassUtils;
import org.datanucleus.util.NucleusLogger;

/**
 * Representation of a join table for a Map. A Map covers a wide range of possibilities
 * in terms of whether it allows duplicates or not, whether it allows nulls or not, whether it supports
 * ordering via indexes etc. Consequently the join table can vary depending on the required capabilities.
 * <h3>JoinTable Mappings</h3>
 * <p>
 * The join table consists of the following mappings :-
 * <ul>
 * <li><B>ownerMapping</B> linking back to the owning class with the Collection.</li>
 * <li><B>keyMapping</B> either being an FK link to the key table or being an embedded/serialised key 
 * stored wholely in this table.</li>
 * <li><B>valueMapping</B> either being an FK link to the value table or being an embedded/serialised value 
 * stored wholely in this table.</li>
 * <li><B>orderMapping</B> which may be null, or otherwise stores an index for the keys.
 * This is either to provide uniqueness or ordering (and part of the PK).</li>
 * </ul>
 * </p>
 */
public class MapTable extends JoinTable implements SCOTable, DatastoreMap
{
    /** Mapping to the key object. */
    private JavaTypeMapping keyMapping;

    /** Mapping to the value object. */
    private JavaTypeMapping valueMapping;

    /**
     * Mapping to allow ordering (of keys) or to allow duplicates. Can be used when the key is not suitable
     * for use as part of the PK and a PK is required for this join table.
     */
    private JavaTypeMapping orderMapping;

    /** Map of field mappings when containing an embedded PC key. Keyed by the FieldMetaData of the field. */
    protected Map embeddedKeyMappingsMap;

    /** Map of field mappings when containing an embedded PC value. Keyed by the FieldMetaData of the field. */
    protected Map embeddedValueMappingsMap;

    /**
     * Constructor.
     * @param tableName Identifier name of the table
     * @param fmd MetaData for the field of the owner
     * @param storeMgr The Store Manager managing these tables.
     **/
    public MapTable(DatastoreIdentifier tableName, AbstractMemberMetaData fmd, RDBMSManager storeMgr)
    {
        super(tableName,fmd,storeMgr);
    }

    /**
     * Method to initialise the table definition.
     * @param clr The ClassLoaderResolver
     **/
    public void initialize(ClassLoaderResolver clr)
    {
        assertIsUninitialized();

        MapMetaData mmd = fmd.getMap();
        if (mmd == null)
        {
            throw new NucleusUserException(LOCALISER.msg("057017",fmd));
        }

        PrimaryKeyMetaData pkmd = (fmd.getJoinMetaData() != null ? fmd.getJoinMetaData().getPrimaryKeyMetaData() : null);
        boolean pkColsSpecified = (pkmd != null && pkmd.getColumnMetaData() != null);
        boolean pkRequired = requiresPrimaryKey();

        // Add owner mapping
        ColumnMetaData[] ownerColmd = null;
        if (fmd.getJoinMetaData() != null &&
            fmd.getJoinMetaData().getColumnMetaData() != null &&
            fmd.getJoinMetaData().getColumnMetaData().length > 0)
        {
            // Column mappings defined at this side (1-N, M-N)
            // When specified at this side they use the <join> tag
            ownerColmd = fmd.getJoinMetaData().getColumnMetaData();
        }
        ownerMapping = ColumnCreator.createColumnsForJoinTables(clr.classForName(ownerType), fmd, ownerColmd,
            storeMgr, this, pkRequired, false, false, false, FieldRole.ROLE_OWNER, clr);
        if (NucleusLogger.DATASTORE.isDebugEnabled())
        {
            debugMapping(ownerMapping);
        }

        // Add key mapping
        boolean keyPC = (fmd.hasMap() && fmd.getMap().getKeyClassMetaData() != null);
        if (isSerialisedKey() || isEmbeddedKeyPC() || (isEmbeddedKey() && !keyPC))
        {
            // Key = PC(embedded), PC(serialised), Non-PC(serialised), Non-PC(embedded)
            keyMapping = dba.getMappingManager().getMapping(this, fmd, dba, clr, JavaTypeMapping.MAPPING_MAP_KEY);
            if (NucleusLogger.DATASTORE.isDebugEnabled())
            {
                debugMapping(keyMapping);
            }
        }
        else
        {
            // Key = PC
            ColumnMetaData[] keyColmd = null;
            KeyMetaData keymd = fmd.getKeyMetaData();
            if (keymd != null && keymd.getColumnMetaData() != null && keymd.getColumnMetaData().length > 0)
            {
                // Column mappings defined at this side (1-N, M-N)
                keyColmd = keymd.getColumnMetaData();
            }
            keyMapping = ColumnCreator.createColumnsForJoinTables(clr.classForName(mmd.getKeyType()), fmd,
                keyColmd, storeMgr, this,  false, false, fmd.getMap().isSerializedKey(), false,
                FieldRole.ROLE_MAP_KEY, clr);
            if (NucleusLogger.DATASTORE.isDebugEnabled())
            {
                debugMapping(keyMapping);
            }
        }

        // Add value mapping
        boolean valuePC = (fmd.hasMap() && fmd.getMap().getValueClassMetaData() != null);
        if (isSerialisedValue() || isEmbeddedValuePC() || (isEmbeddedValue() && !valuePC))
        {
            // Value = PC(embedded), PC(serialised), Non-PC(serialised), Non-PC(embedded)
            // Add field(s) for value
            valueMapping = dba.getMappingManager().getMapping(this, fmd, dba, clr, JavaTypeMapping.MAPPING_MAP_VALUE);
            if (NucleusLogger.DATASTORE.isDebugEnabled())
            {
                debugMapping(valueMapping);
            }
        }
        else
        {
            // Value = PC
            ColumnMetaData[] valueColmd = null;
            ValueMetaData valuemd = fmd.getValueMetaData();
            if (valuemd != null && valuemd.getColumnMetaData() != null && valuemd.getColumnMetaData().length > 0)
            {
                // Column mappings defined at this side (1-N, M-N)
                valueColmd = valuemd.getColumnMetaData();
            }
            valueMapping = ColumnCreator.createColumnsForJoinTables(clr.classForName(mmd.getValueType()), fmd,
                valueColmd, storeMgr, this, false, true, fmd.getMap().isSerializedValue(), false,
                FieldRole.ROLE_MAP_VALUE, clr);
            if (NucleusLogger.DATASTORE.isDebugEnabled())
            {
                debugMapping(valueMapping);
            }
        }

        // Add order mapping if required
        boolean orderRequired = false;
        if (fmd.getOrderMetaData() != null)
        {
            // User requested order column so add one
            orderRequired = true;
        }
        else if (requiresPrimaryKey() && !pkColsSpecified)
        {
            // PK is required so maybe need to add an index to form the PK
            if (isEmbeddedKeyPC())
            {
                if (fmd.getMap().getKeyClassMetaData().getIdentityType() != IdentityType.APPLICATION)
                {
                    // Embedded key PC with datastore id so we need an index to form the PK
                    orderRequired = true;
                }
            }
            else if (isSerialisedKey())
            {
                // Serialised key, so need an index to form the PK
                orderRequired = true;
            }
            else if (keyMapping instanceof ReferenceMapping)
            {
                // ReferenceMapping, so have order if more than 1 implementation
                ReferenceMapping refMapping = (ReferenceMapping)keyMapping;
                if (refMapping.getJavaTypeMapping().length > 1)
                {
                    orderRequired = true;
                }
            }
            else if (!(keyMapping instanceof PersistenceCapableMapping))
            {
                // Non-PC, so depends if the key column can be used as part of a PK
                // TODO This assumes the keyMapping has a single column but what if it is Color with 4 cols?
                Column elementCol = (Column)keyMapping.getDataStoreMapping(0).getDatastoreField();
                if (!((RDBMSAdapter)storeMgr.getDatastoreAdapter()).isValidPrimaryKeyType(elementCol.getJdbcType()))
                {
                    // Not possible to use this Non-PC type as part of the PK
                    orderRequired = true;
                }
            }
        }
        if (orderRequired)
        {
            // Order/Adapter (index) column is required (integer based)
            ColumnMetaData orderColmd = null;
            if (fmd.getOrderMetaData() != null &&
                fmd.getOrderMetaData().getColumnMetaData() != null &&
                fmd.getOrderMetaData().getColumnMetaData().length > 0)
            {
                // Specified "order" column info
                orderColmd = fmd.getOrderMetaData().getColumnMetaData()[0];
            }
            else if (fmd.hasExtension("adapter-column-name"))
            {
                // Specified JPOX "extension" column name
                // TODO Why do we have this ? the user can just specify <order column="...">
                orderColmd = new ColumnMetaData(fmd, fmd.getValueForExtension("adapter-column-name"));
            }
            else
            {
                // No column name so use default
                DatastoreIdentifier id =
                    ((RDBMSIdentifierFactory)storeMgr.getIdentifierFactory()).newIndexFieldIdentifier();
                orderColmd = new ColumnMetaData(fmd, id.getIdentifier());
            }
            orderMapping = dba.getMapping(int.class, storeMgr); // JDO2 spec [18.5] order column is assumed to be "int"
            ColumnCreator.createIndexColumn(orderMapping, storeMgr, clr, this, orderColmd, pkRequired && !pkColsSpecified);
            if (NucleusLogger.DATASTORE.isDebugEnabled())
            {
                debugMapping(orderMapping);
            }
        }

        // Define primary key of the join table (if any)
        if (pkRequired)
        {
            if (pkColsSpecified)
            {
                // Apply the users PK specification
                applyUserPrimaryKeySpecification(pkmd);
            }
            else
            {
                // Define PK using JPOX rules
                if (orderRequired)
                {
                    // Order column specified so owner+order are the PK
                    orderMapping.getDataStoreMapping(0).getDatastoreField().setAsPrimaryKey();
                }
                else
                {
                    // No order column specified so owner+key are the PK
                    for (int i=0;i<keyMapping.getNumberOfDatastoreFields();i++)
                    {
                        keyMapping.getDataStoreMapping(i).getDatastoreField().setAsPrimaryKey();
                    }
                }
            }
        }

        state = TABLE_STATE_INITIALIZED;
    }

    /**
     * Convenience method to apply the user specification of <primary-key> columns
     * @param pkmd MetaData for the primary key
     */
    protected void applyUserPrimaryKeySpecification(PrimaryKeyMetaData pkmd)
    {
        ColumnMetaData[] pkCols = pkmd.getColumnMetaData();
        for (int i=0;i<pkCols.length;i++)
        {
            String colName = pkCols[i].getName();
            boolean found = false;
            for (int j=0;j<ownerMapping.getNumberOfDatastoreFields();j++)
            {
                if (ownerMapping.getDataStoreMapping(j).getDatastoreField().getIdentifier().getIdentifier().equals(colName))
                {
                    ownerMapping.getDataStoreMapping(j).getDatastoreField().setAsPrimaryKey();
                    found = true;
                }
            }
            
            if (!found)
            {
                for (int j=0;j<keyMapping.getNumberOfDatastoreFields();j++)
                {
                    if (keyMapping.getDataStoreMapping(j).getDatastoreField().getIdentifier().getIdentifier().equals(colName))
                    {
                        keyMapping.getDataStoreMapping(j).getDatastoreField().setAsPrimaryKey();
                        found = true;
                    }
                }
            }
            
            if (!found)
            {
                for (int j=0;j<valueMapping.getNumberOfDatastoreFields();j++)
                {
                    if (valueMapping.getDataStoreMapping(j).getDatastoreField().getIdentifier().getIdentifier().equals(colName))
                    {
                        valueMapping.getDataStoreMapping(j).getDatastoreField().setAsPrimaryKey();
                        found = true;
                    }
                }
            }
            
            if (!found)
            {
                throw new NucleusUserException(LOCALISER.msg("057040", toString(), colName));
            }
        }
    }

    /**
     * Accessor for whether the key is embedded into this table.
     * This can be an embedded PersistenceCapable, or an embedded simple type.
     * @return Whether the key is embedded.
     */
    public boolean isEmbeddedKey()
    {
        if (fmd.getMap() != null && fmd.getMap().isSerializedKey())
        {
            // Serialized takes precedence over embedded
            return false;
        }
        else if (fmd.getMap() != null && fmd.getMap().isEmbeddedKey())
        {
            return true;
        }
        return false;
    }

    /**
     * Accessor for whether the key is serialised into this table.
     * This can be an serialised PersistenceCapable, or a serialised simple type.
     * @return Whether the key is serialised.
     */
    public boolean isSerialisedKey()
    {
        if (fmd.getMap() != null && fmd.getMap().isSerializedKey())
        {
            return true;
        }
        return false;
    }

    /**
     * Accessor for whether the key is a PersistenceCapable(serialised)
     * @return Whether the key is PC and is serialised
     */
    public boolean isSerialisedKeyPC()
    {
        if (fmd.getMap() != null && fmd.getMap().isSerializedKey() && fmd.getMap().getKeyClassMetaData() != null)
        {
            return true;
        }
        return false;
    }

    /**
     * Accessor for whether the key is a PersistenceCapable(embedded)
     * @return Whether the key is PC and is embedded
     */
    public boolean isEmbeddedKeyPC()
    {
        if (fmd.getMap() != null && fmd.getMap().isSerializedKey())
        {
            // Serialized takes precedence over embedded
            return false;
        }
        if (fmd.getKeyMetaData() != null && fmd.getKeyMetaData().getEmbeddedMetaData() != null)
        {
            return true;
        }
        return false;
    }

    /**
     * Accessor for whether the value is embedded into this table.
     * This can be an embedded PersistenceCapable, or an embedded simple type.
     * @return Whether the value is embedded.
     */
    public boolean isEmbeddedValue()
    {
        if (fmd.getMap() != null && fmd.getMap().isSerializedValue())
        {
            // Serialized takes precedence over embedded
            return false;
        }
        else if (fmd.getMap() != null && fmd.getMap().isEmbeddedValue())
        {
            return true;
        }
        return false;
    }

    /**
     * Accessor for whether the value is serialised into this table.
     * This can be an serialised PersistenceCapable, or a serialised simple type.
     * @return Whether the value is serialised.
     */
    public boolean isSerialisedValue()
    {
        if (fmd.getMap() != null && fmd.getMap().isSerializedValue())
        {
            return true;
        }
        return false;
    }

    /**
     * Accessor for whether the value is a PersistenceCapable(serialised)
     * @return Whether the value is PC and is serialised
     */
    public boolean isSerialisedValuePC()
    {
        if (fmd.getMap() != null && fmd.getMap().isSerializedValue() && fmd.getMap().getValueClassMetaData() != null)
        {
            return true;
        }
        return false;
    }

    /**
     * Accessor for whether the value is a PersistenceCapable(embedded)
     * @return Whether the value is PC and is embedded
     */
    public boolean isEmbeddedValuePC()
    {
        if (fmd.getMap() != null && fmd.getMap().isSerializedValue())
        {
            // Serialized takes precedence over embedded
            return false;
        }
        if (fmd.getValueMetaData() != null && fmd.getValueMetaData().getEmbeddedMetaData() != null)
        {
            return true;
        }
        return false;
    }

    /**
     * Accessor for the "key" mapping end of the relationship.
     * @return The column mapping for the element.
     **/
    public JavaTypeMapping getKeyMapping()
    {
        assertIsInitialized();

        return keyMapping;
    }

    /**
     * Accessor for the "value" mapping end of the relationship.
     * @return The column mapping for the element.
     **/
    public JavaTypeMapping getValueMapping()
    {
        assertIsInitialized();

        return valueMapping;
    }

    /**
     * Accessor for the key type for this Map.
     * @return Name of key type.
     */
    public String getKeyType()
    {
        return fmd.getMap().getKeyType();
    }

    /**
     * Accessor for the value type for this Map.
     * @return Name of value type.
     */
    public String getValueType()
    {
        return fmd.getMap().getValueType();
    }

    /**
     * Accessor for order mapping.
     * The columns in this mapping are part of the primary key.
     * @return The column mapping for objects without identity or not supported as part of the primary keys
     **/
    public JavaTypeMapping getOrderMapping()
    {
        assertIsInitialized();
        return orderMapping;
    }

    /**
     * Accessor for the expected foreign keys for this table.
     * @param clr The ClassLoaderResolver
     * @return The expected foreign keys.
     */
    protected List getExpectedForeignKeys(ClassLoaderResolver clr)
    {
        assertIsInitialized();

        boolean autoMode = false;
        if (storeMgr.getOMFContext().getPersistenceConfiguration().getStringProperty("datanucleus.rdbms.constraintCreateMode").equals("DataNucleus"))
        {
            autoMode = true;
        }

        ArrayList foreignKeys = new ArrayList();
        try
        {
            // FK from join table to owner table
            DatastoreClass referencedTable = storeMgr.getDatastoreClass(ownerType, clr);
            if (referencedTable != null)
            {
                // Take <foreign-key> from <join>
                ForeignKeyMetaData fkmd = null;
                if (fmd.getJoinMetaData() != null)
                {
                    fkmd = fmd.getJoinMetaData().getForeignKeyMetaData();
                }
                if (fkmd != null || autoMode)
                {
                    ForeignKey fk = new ForeignKey(ownerMapping,dba,referencedTable, true);
                    fk.setForMetaData(fkmd);
                    foreignKeys.add(fk);
                }
            }

            if (!isSerialisedValuePC())
            {
                if (isEmbeddedValuePC())
                {
                    // Add any FKs for the fields of the (embedded) value
                    EmbeddedValuePCMapping embMapping = (EmbeddedValuePCMapping)valueMapping;
                    for (int i=0;i<embMapping.getNumberOfJavaTypeMappings();i++)
                    {
                        JavaTypeMapping embFieldMapping = embMapping.getJavaTypeMapping(i);
                        AbstractMemberMetaData embFmd = embFieldMapping.getFieldMetaData();
                        if (ClassUtils.isReferenceType(embFmd.getType()) &&
                            embFieldMapping instanceof ReferenceMapping)
                        {
                            // Field is a reference type, so add a FK to the table of the PC for each PC implementation
                            Collection fks = TableUtils.getForeignKeysForReferenceField(embFieldMapping, embFmd, 
                                autoMode, storeMgr, clr);
                            foreignKeys.addAll(fks);
                        }
                        else if (storeMgr.getOMFContext().getMetaDataManager().getMetaDataForClass(embFmd.getType(), clr) != null &&
                                embFieldMapping.getNumberOfDatastoreFields() > 0 &&
                                embFieldMapping instanceof PersistenceCapableMapping)
                        {
                            // Field is for a PC class with the FK at this side, so add a FK to the table of this PC
                            ForeignKey fk = TableUtils.getForeignKeyForPCField(embFieldMapping, embFmd, 
                                autoMode, storeMgr, clr);
                            if (fk != null)
                            {
                                foreignKeys.add(fk);
                            }
                        }
                    }
                }
                else if (fmd.getMap().getValueClassMetaData() != null)
                {
                    // FK from join table to value table
                    referencedTable = storeMgr.getDatastoreClass(fmd.getMap().getValueType(), clr);
                    if (referencedTable != null)
                    {
                        // Take <foreign-key> from <value>
                        ForeignKeyMetaData fkmd = null;
                        if (fmd.getValueMetaData() != null)
                        {
                            fkmd = fmd.getValueMetaData().getForeignKeyMetaData();
                        }
                        if (fkmd != null || autoMode)
                        {
                            ForeignKey fk = new ForeignKey(valueMapping, dba, referencedTable, true);
                            fk.setForMetaData(fkmd);
                            foreignKeys.add(fk);
                        }
                    }
                }
            }

            if (!isSerialisedKeyPC())
            {
                if (isEmbeddedKeyPC())
                {
                    // Add any FKs for the fields of the (embedded) key
                    EmbeddedKeyPCMapping embMapping = (EmbeddedKeyPCMapping)keyMapping;
                    for (int i=0;i<embMapping.getNumberOfJavaTypeMappings();i++)
                    {
                        JavaTypeMapping embFieldMapping = embMapping.getJavaTypeMapping(i);
                        AbstractMemberMetaData embFmd = embFieldMapping.getFieldMetaData();
                        if (ClassUtils.isReferenceType(embFmd.getType()) && 
                            embFieldMapping instanceof ReferenceMapping)
                        {
                            // Field is a reference type, so add a FK to the table of the PC for each PC implementation
                            Collection fks = TableUtils.getForeignKeysForReferenceField(embFieldMapping, embFmd, 
                                autoMode, storeMgr, clr);
                            foreignKeys.addAll(fks);
                        }
                        else if (storeMgr.getOMFContext().getMetaDataManager().getMetaDataForClass(embFmd.getType(), clr) != null &&
                                embFieldMapping.getNumberOfDatastoreFields() > 0 &&
                                embFieldMapping instanceof PersistenceCapableMapping)
                        {
                            // Field is for a PC class with the FK at this side, so add a FK to the table of this PC
                            ForeignKey fk = TableUtils.getForeignKeyForPCField(embFieldMapping, embFmd, 
                                autoMode, storeMgr, clr);
                            if (fk != null)
                            {
                                foreignKeys.add(fk);
                            }
                        }
                    }
                }
                else if (fmd.getMap().getKeyClassMetaData() != null)
                {
                    // FK from join table to key table
                    referencedTable = storeMgr.getDatastoreClass(fmd.getMap().getKeyType(), clr);
                    if (referencedTable != null)
                    {
                        // Take <foreign-key> from <key>
                        ForeignKeyMetaData fkmd = null;
                        if (fmd.getKeyMetaData() != null)
                        {
                            fkmd = fmd.getKeyMetaData().getForeignKeyMetaData();
                        }
                        if (fkmd != null || autoMode)
                        {
                            ForeignKey fk = new ForeignKey(keyMapping, dba, referencedTable, true);
                            fk.setForMetaData(fkmd);
                            foreignKeys.add(fk);
                        }
                    }
                }
            }
        }
        catch (NoTableManagedException e)
        {
            // expected when no table exists
        }
        return foreignKeys;
    }

    /**
     * Accessor for the indices for this table. 
     * This includes both the user-defined indices (via MetaData), and the ones required by 
     * foreign keys (required by relationships).
     * @param clr The ClassLoaderResolver
     * @return The indices
     */
    protected Set getExpectedIndices(ClassLoaderResolver clr)
    {
        // The indices required by foreign keys (BaseTable)
        Set indices = super.getExpectedIndices(clr);

        if (keyMapping instanceof EmbeddedKeyPCMapping)
        {
            // Add all indices required by fields of the embedded key
            EmbeddedKeyPCMapping embMapping = (EmbeddedKeyPCMapping)keyMapping;
            for (int i=0;i<embMapping.getNumberOfJavaTypeMappings();i++)
            {
                JavaTypeMapping embFieldMapping = embMapping.getJavaTypeMapping(i);
                IndexMetaData imd = embFieldMapping.getFieldMetaData().getIndexMetaData();
                if (imd != null)
                {
                    Index index = TableUtils.getIndexForField(this, imd, embFieldMapping);
                    if (index != null)
                    {
                        indices.add(index);
                    }
                }
            }
        }

        if (valueMapping instanceof EmbeddedValuePCMapping)
        {
            // Add all indices required by fields of the embedded value
            EmbeddedValuePCMapping embMapping = (EmbeddedValuePCMapping)valueMapping;
            for (int i=0;i<embMapping.getNumberOfJavaTypeMappings();i++)
            {
                JavaTypeMapping embFieldMapping = embMapping.getJavaTypeMapping(i);
                IndexMetaData imd = embFieldMapping.getFieldMetaData().getIndexMetaData();
                if (imd != null)
                {
                    Index index = TableUtils.getIndexForField(this, imd, embFieldMapping);
                    if (index != null)
                    {
                        indices.add(index);
                    }
                }
            }
        }

        return indices;
    }

    /**
     * Accessor for the candidate keys for this table.
     * @return The indices
     */
    protected List getExpectedCandidateKeys()
    {
        // The indices required by foreign keys (BaseTable)
        List candidateKeys = super.getExpectedCandidateKeys();

        if (keyMapping instanceof EmbeddedKeyPCMapping)
        {
            // Add all candidate keys required by fields of the embedded key
            EmbeddedKeyPCMapping embMapping = (EmbeddedKeyPCMapping)keyMapping;
            for (int i=0;i<embMapping.getNumberOfJavaTypeMappings();i++)
            {
                JavaTypeMapping embFieldMapping = embMapping.getJavaTypeMapping(i);
                UniqueMetaData umd = embFieldMapping.getFieldMetaData().getUniqueMetaData();
                if (umd != null)
                {
                    CandidateKey ck = TableUtils.getCandidateKeyForField(this, umd, embFieldMapping);
                    if (ck != null)
                    {
                        candidateKeys.add(ck);
                    }
                }
            }
        }

        if (valueMapping instanceof EmbeddedValuePCMapping)
        {
            // Add all candidate keys required by fields of the embedded value
            EmbeddedValuePCMapping embMapping = (EmbeddedValuePCMapping)valueMapping;
            for (int i=0;i<embMapping.getNumberOfJavaTypeMappings();i++)
            {
                JavaTypeMapping embFieldMapping = embMapping.getJavaTypeMapping(i);
                UniqueMetaData umd = embFieldMapping.getFieldMetaData().getUniqueMetaData();
                if (umd != null)
                {
                    CandidateKey ck = TableUtils.getCandidateKeyForField(this, umd, embFieldMapping);
                    if (ck != null)
                    {
                        candidateKeys.add(ck);
                    }
                }
            }
        }

        return candidateKeys;
    }

    /**
     * Accessor the for the mapping for a field stored in this table
     * @param fmd MetaData for the field whose mapping we want
     * @return The mapping
     */
    public JavaTypeMapping getFieldMapping(AbstractMemberMetaData fmd)
    {
        return null;
    }
}