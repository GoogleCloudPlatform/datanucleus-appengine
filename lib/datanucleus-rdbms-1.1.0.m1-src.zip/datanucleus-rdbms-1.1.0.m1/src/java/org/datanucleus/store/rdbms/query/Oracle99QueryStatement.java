/**********************************************************************
Copyright (c) 2004 Erik Bengtson and others. All rights reserved.
Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
 

Contributors:
    ...
**********************************************************************/
package org.datanucleus.store.rdbms.query;

import org.datanucleus.ClassLoaderResolver;
import org.datanucleus.store.mapped.DatastoreContainerObject;
import org.datanucleus.store.mapped.DatastoreIdentifier;
import org.datanucleus.store.mapped.expression.CharacterExpression;
import org.datanucleus.store.mapped.expression.ScalarExpression;
import org.datanucleus.store.mapped.query.StatementText;
import org.datanucleus.store.rdbms.adapter.RDBMSAdapter;

/**
 * Representation of a Query Statement in Oracle 9 or upper.
 * Oracle has an NLSSortOrder control for order clauses.
 */
public class Oracle99QueryStatement extends QueryStatement
{
    /**
     * The system property that selects the "linguistic definition" to be used for native language sorting
     * of String fields. The default value is "LATIN". A value of "BINARY" disables native language sorting.
     */
    private String nlsSortOrder = "LATIN";

    /**
     * QueryStatement constructor.
     * @param initialTable The main table for this statement.
     * @param clr ClassLoader resolver
     */
    public Oracle99QueryStatement(DatastoreContainerObject initialTable, ClassLoaderResolver clr)
    {
        this(initialTable, null, clr);
    }

    /**
     * QueryStatement constructor.
     * @param initialTable The main table for this statement.
     * @param alias The alias for the main table
     * @param clr ClassLoader resolver
     */
    public Oracle99QueryStatement(DatastoreContainerObject initialTable, DatastoreIdentifier alias, ClassLoaderResolver clr)
    {
        super(initialTable, alias, clr);
        String sortOrder = storeMgr.getOMFContext().getPersistenceConfiguration().getStringProperty("datanucleus.rdbms.oracleNlsSortOrder");
        if (sortOrder != null)
        {
            nlsSortOrder = sortOrder.toUpperCase();
        }
    }

    /**
     * Convenience method to generate the ordering statement to add to the overall query statement.
     * @return The ordering statement
     */
    protected StatementText generateOrderingStatement()
    {
        StatementText orderByStmt = null;
        if (orderingExpressions != null && orderingExpressions.length > 0)
        {
            RDBMSAdapter dba = (RDBMSAdapter)storeMgr.getDatastoreAdapter();
            orderByStmt = new StatementText();
            boolean needsSelect = dba.supportsOption(RDBMSAdapter.INCLUDE_ORDERBY_COLS_IN_SELECT);
            for (int i=0; i<orderingExpressions.length; ++i)
            {
                String orderExpr = "JPOXORDER" + i;
                if (i > 0)
                {
                    orderByStmt.append(',');
                }

                if (needsSelect && !hasAggregateExpression)
                {
                    // Order by the "JPOXORDER?" if we need them to be selected and it isn't an aggregate
                    if (orderingExpressions[i] instanceof CharacterExpression && !nlsSortOrder.equals("BINARY"))
                    {
                        orderByStmt.append("NLSSORT(").append(orderExpr).append(", 'NLS_SORT = ").append(nlsSortOrder).append("')");
                    }
                    else
                    {
                        orderByStmt.append(orderExpr);
                    }

                }
                else
                {
                    // Order by the "THIS.COLUMN" otherwise
                    if (orderingExpressions[i] instanceof CharacterExpression && !nlsSortOrder.equals("BINARY"))
                    {
                        orderByStmt.append("NLSSORT(").append(
                            orderingExpressions[i].toStatementText(ScalarExpression.PROJECTION).toStatementString(
                                ScalarExpression.PROJECTION)).append(", 'NLS_SORT = ").append(nlsSortOrder).append("')");
                    }
                    else
                    {
                        orderByStmt.append(orderingExpressions[i].toStatementText(ScalarExpression.PROJECTION).toStatementString(ScalarExpression.PROJECTION));
                    }
                }

                if (orderingDirections[i])
                {
                    orderByStmt.append(" DESC");
                }
            }
        }
        return orderByStmt;
    }
}