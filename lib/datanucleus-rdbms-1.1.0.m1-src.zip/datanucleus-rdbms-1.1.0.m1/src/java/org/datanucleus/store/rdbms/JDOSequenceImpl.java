/**********************************************************************
Copyright (c) 2005 Andy Jefferson and others. All rights reserved.
Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.


Contributors:
    ...
**********************************************************************/
package org.datanucleus.store.rdbms;

import java.sql.SQLException;
import java.util.Properties;

import org.datanucleus.ManagedConnection;
import org.datanucleus.ObjectManager;
import org.datanucleus.PersistenceConfiguration;
import org.datanucleus.exceptions.NucleusDataStoreException;
import org.datanucleus.exceptions.NucleusException;
import org.datanucleus.metadata.ExtensionMetaData;
import org.datanucleus.metadata.SequenceMetaData;
import org.datanucleus.plugin.ConfigurationElement;
import org.datanucleus.store.NucleusSequence;
import org.datanucleus.store.mapped.DatastoreAdapter;
import org.datanucleus.store.mapped.MappedStoreManager;
import org.datanucleus.store.poid.PoidConnectionProvider;
import org.datanucleus.store.poid.PoidGenerator;
import org.datanucleus.store.poid.PoidManager;
import org.datanucleus.transaction.TransactionUtils;
import org.datanucleus.util.NucleusLogger;
import org.datanucleus.util.Localiser;

/**
 * Basic implementation of a JDO2-style datastore sequence for RDBMS.
 * Utilises the <B>org.datanucleus.store.poid</B> classes to generate sequence values.
 */
public class JDOSequenceImpl implements NucleusSequence
{
    /** Localisation of messages */
    protected static final Localiser LOCALISER = Localiser.getInstance("org.datanucleus.Localisation",
        ObjectManager.class.getClassLoader());

    /** Store Manager where we obtain our sequence. */
    protected final MappedStoreManager storeManager;

    /** Name of the sequence. */
    protected final SequenceMetaData seqMetaData;

    /** The generator for the sequence. */
    protected final PoidGenerator generator;

    /** The controlling Object Manager. */
    protected final ObjectManager om;

    /**
     * Constructor.
     * @param objectMgr The Object Manager managing the sequence
     * @param storeMgr Manager of the store where we obtain the sequence
     * @param seqmd MetaData defining the sequence
     */
    public JDOSequenceImpl(ObjectManager objectMgr, MappedStoreManager storeMgr, SequenceMetaData seqmd)
    {
        this.om = objectMgr;
        this.storeManager = storeMgr;
        this.seqMetaData = seqmd;

        // Allocate the PoidManager for this sequence
        String poidGeneratorName = null;
        if (storeMgr.getDatastoreAdapter().supportsOption(DatastoreAdapter.SEQUENCES))
        {
            poidGeneratorName = "sequence";
        }
        else
        {
            poidGeneratorName = "table-sequence";
        }

        // Create the controlling properties for this sequence
        Properties props = new Properties();
        ExtensionMetaData[] seqExtensions = seqmd.getExtensions();
        if (seqExtensions != null && seqExtensions.length > 0)
        {
            // Add all MetaData extension properties provided
            for (int i=0;i<seqExtensions.length;i++)
            {
                props.put(seqExtensions[i].getKey(), seqExtensions[i].getValue());
            }
        }
        if (poidGeneratorName.equals("sequence"))
        {
            // Use the provided name as the sequence name (what if it is null ?)
            props.put("sequence-name", seqMetaData.getDatastoreSequence());
        }
        else if (poidGeneratorName.equals("table-sequence"))
        {
            // Use the provided name as the table name (what if it is null ?)
            props.put("sequence-name", seqMetaData.getDatastoreSequence());
        }

        // Get a PoidManager to create the generator
        PoidManager mgr = storeMgr.getPoidManager();

        PoidConnectionProvider connProvider = new PoidConnectionProvider()
            {
                ManagedConnection mconn;

                public ManagedConnection retrieveConnection()
                {
                    try
                    {
                        // Obtain a new connection
                        // Note : it may be worthwhile to use the PM's connection here however where a Sequence doesnt yet
                        // exist the connection would then be effectively dead until the end of the tx
                        // The way around this would be to find a way of checking for existence of the sequence
                        PersistenceConfiguration conf = om.getOMFContext().getPersistenceConfiguration();
                        int isolationLevel = TransactionUtils.getTransactionIsolationLevelForName(conf.getStringProperty("datanucleus.poid.transactionIsolation"));
                        this.mconn = ((RDBMSManager)storeManager).getConnection(isolationLevel);
                    }
                    catch (SQLException e)
                    {
                        String msg = LOCALISER.msg("017006", e);
                        NucleusLogger.JDO.error(msg);
                        throw new NucleusDataStoreException(msg,e);
                    }
                    return mconn;
                }

                public void releaseConnection()
                {
                    try
                    {
                        // Release the connection
                        mconn.close();
                    }
                    catch (NucleusException e)
                    {
                        NucleusLogger.JDO.error(LOCALISER.msg("017007", e));
                        throw e;
                    }
                }
            };
        Class cls = null;
        ConfigurationElement elem =
            objectMgr.getOMFContext().getPluginManager().getConfigurationElementForExtension("org.datanucleus.store_valuegenerator", 
                new String[]{"name", "datastore"}, new String[] {poidGeneratorName, storeManager.getStoreManagerKey()});
        if (elem != null)
        {
            cls = objectMgr.getOMFContext().getPluginManager().loadClass(elem.getExtension().getPlugin().getSymbolicName(), elem.getAttribute("class-name"));
        }
        if( cls == null )
        {
            throw new NucleusException("Cannot create Poid Generator for strategy "+poidGeneratorName);
        }
        generator = mgr.createPoidGenerator(seqMetaData.getName(), cls, props, storeManager, connProvider);

        if (NucleusLogger.JDO.isDebugEnabled())
        {
            NucleusLogger.JDO.debug(LOCALISER.msg("017003", seqMetaData.getName(), poidGeneratorName));
        }
    }

    /**
     * Accessor for the sequence name.
     * @return The sequence name
     */
    public String getName()
    {
        return seqMetaData.getName();
    }

    /**
     * Method to allocate a set of elements.
     * @param additional The number of additional elements to allocate
     */
    public void allocate(int additional)
    {
        try
        {
            generator.allocate(additional);
        }
        catch (NucleusException de)
        {
        }
    }

    /**
     * Accessor for the next element in the sequence.
     * @return The next element
     */
    public Object next()
    {
        return generator.next();
    }

    /**
     * Accessor for the next element in the sequence as a long.
     * @return The next element
     * @throws NucleusDataStoreException Thrown if not numeric
     */
    public long nextValue()
    {
        return generator.nextValue();
    }

    /**
     * Accessor for the current element.
     * @return The current element.
     */
    public Object current()
    {
        return generator.current();
    }

    /**
     * Accessor for the current element in the sequence as a long.
     * @return The current element
     * @throws NucleusDataStoreException Thrown if not numeric
     */
    public long currentValue()
    {
        return generator.currentValue();
    }
}