/**********************************************************************
Copyright (c) 2008 Andy Jefferson and others. All rights reserved.
Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.

Contributors:
    ...
**********************************************************************/
package org.datanucleus.store.rdbms.sql.expression;

import java.util.List;

import org.datanucleus.store.mapped.mapping.JavaTypeMapping;
import org.datanucleus.store.rdbms.sql.SQLStatement;
import org.datanucleus.store.rdbms.sql.SQLText;
import org.datanucleus.util.StringUtils;

/**
 * Representation of a string literal.
 */
public class StringLiteral extends StringExpression implements Literal
{
    private final String value;

    /** Raw value that this literal represents. */
    Object rawValue;

    private SQLText stUsingParameter = new SQLText();

    /**
     * Creates a String literal.
     * @param stmt the SQL statement
     * @param mapping the mapping
     * @param value the value
     */
    public StringLiteral(SQLStatement stmt, JavaTypeMapping mapping, char value)
    {
        this(stmt, mapping, String.valueOf(value));
    }

    /**
     * Creates a String literal.
     * @param stmt the SQL statement
     * @param mapping the mapping
     * @param value the value
     */
    public StringLiteral(SQLStatement stmt, JavaTypeMapping mapping, String value)
    {
        super(stmt, null, mapping);

        this.value = value;
        // Escape any single-quotes
        st.append('\'').append(StringUtils.replaceAll(value, "'", "''")).append('\'');

        if (mapping == null)
        {
            stUsingParameter.appendParameter(mapping, value);
        }
        else
        {
            stUsingParameter.appendParameter(mapping,value);
        }
    }

    /**
     * Convenience method to generate the statement without any quotes.
     * This is called when we create a literal using a mapping, and dont want quotes
     * because the string is an SQL keyword.
     */
    public void generateStatementWithoutQuotes()
    {
        st.clearStatement();
        st.append(StringUtils.replaceAll(value, "'", "''"));
    }

    public Object getValue()
    {
        return value;
    }

    public BooleanExpression eq(SQLExpression expr)
    {
//        assertValidTypeForParameterComparison(expr, StringExpression.class);

        if (expr instanceof StringLiteral)
        {
            return new BooleanLiteral(stmt, mapping, value.equals(((StringLiteral)expr).value));
        }
        else
        {
            return super.eq(expr);
        }
    }

    public BooleanExpression noteq(SQLExpression expr)
    {
//        assertValidTypeForParameterComparison(expr, StringExpression.class);

        if (expr instanceof StringLiteral)
        {
            return new BooleanLiteral(stmt, mapping, !value.equals(((StringLiteral)expr).value));
        }
        else
        {
            return super.noteq(expr);
        }
    }

    public BooleanExpression lt(SQLExpression expr)
    {
        if (expr instanceof StringLiteral)
        {
            return new BooleanLiteral(stmt, mapping, value.compareTo(((StringLiteral)expr).value) < 0);
        }
        else
        {
            return super.lt(expr);
        }
    }

    public BooleanExpression le(SQLExpression expr)
    {
        if (expr instanceof StringLiteral)
        {
            return new BooleanLiteral(stmt, mapping, value.compareTo(((StringLiteral)expr).value) <= 0);
        }
        else
        {
            return super.le(expr);
        }
    }

    public BooleanExpression gt(SQLExpression expr)
    {
        if (expr instanceof StringLiteral)
        {
            return new BooleanLiteral(stmt, mapping, value.compareTo(((StringLiteral)expr).value) > 0);
        }
        else
        {
            return super.gt(expr);
        }
    }

    public BooleanExpression ge(SQLExpression expr)
    {
        if (expr instanceof StringLiteral)
        {
            return new BooleanLiteral(stmt, mapping, value.compareTo(((StringLiteral)expr).value) >= 0);
        }
        else
        {
            return super.ge(expr);
        }
    }

    public SQLExpression add(SQLExpression expr)
    {
        if (expr instanceof StringLiteral)
        {
            return new StringLiteral(stmt, mapping, value.concat(((StringLiteral)expr).value));
        }
        else if (expr instanceof CharacterLiteral)
        {
            return new StringLiteral(stmt, mapping, value.concat(((Literal)expr).getValue().toString()));
        }
        else if (expr instanceof IntegerLiteral || expr instanceof FloatingPointLiteral || expr instanceof BooleanLiteral )
        {
            return new StringLiteral(stmt, mapping, value.concat(((Literal)expr).getValue().toString()));
        }        
        else
        {
            return super.add(expr);
        }
    }

    public SQLExpression invoke(String methodName, List args)
    {
        // TODO Implement methods
        return null;
    }

    public SQLText toSQL()
    {
        return stUsingParameter;
    }

    /**
     * Method to save a "raw" value that this literal represents.
     * This value differs from the literal value since that is of the same type as this literal.
     * @param val The raw value
     */
    public void setRawValue(Object val)
    {
        this.rawValue = val;
    }

    /**
     * Accessor for the "raw" value that this literal represents.
     * This value differs from the literal value since that is of the same type as this literal.
     * @return The raw value
     */
    public Object getRawValue()
    {
        return rawValue;
    }
}