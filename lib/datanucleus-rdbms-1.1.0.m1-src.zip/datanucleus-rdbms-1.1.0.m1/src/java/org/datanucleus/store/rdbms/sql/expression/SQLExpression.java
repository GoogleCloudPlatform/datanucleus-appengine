/**********************************************************************
Copyright (c) 2008 Andy Jefferson and others. All rights reserved.
Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.

Contributors:
    ...
**********************************************************************/
package org.datanucleus.store.rdbms.sql.expression;

import java.util.List;
import java.util.ListIterator;

import org.datanucleus.query.expression.Expression;
import org.datanucleus.query.expression.Expression.Operator;
import org.datanucleus.store.mapped.mapping.JavaTypeMapping;
import org.datanucleus.store.rdbms.sql.SQLStatement;
import org.datanucleus.store.rdbms.sql.SQLTable;
import org.datanucleus.store.rdbms.sql.SQLText;

/**
 * Base expression for SQL.
 * The principal here is that any expression (be it a field, literal, parameter, variable etc)
 * has a type and so needs a JavaTypeMapping to control reading/writing of that type.
 * The type will typically have an SQLTable (in the overall statement) that it refers to (obviously
 * Literals/parameters won't).
 * The SQL for the expression is embodied in the SQLText field.
 */
public abstract class SQLExpression
{
    /** The SQL statement that this is part of. */
    protected SQLStatement stmt;

    /** Table in the SQL statement that this mapping applies to. */
    protected SQLTable table;

    /** Mapping for this expression, defining how it is get/set. */
    protected JavaTypeMapping mapping;

    /** The Statement Text representing the SQL. */
    protected final SQLText st = new SQLText();

    // TODO Add javadoc for this - operator precedence ??
    protected Operator lowestOperator = null;

    /**
     * Constructor for an SQL expression for a (field) mapping in a specified table.
     * @param stmt The statement
     * @param table The table in the statement
     * @param mapping The mapping for the field
     */
    protected SQLExpression(SQLStatement stmt, SQLTable table, JavaTypeMapping mapping)
    {
        this.stmt = stmt;
        this.table = table;
        this.mapping = mapping;
    }

    /**
     * Perform an operation <pre>op</pre> on expression <pre>expr1</pre>.
     * @param op operator
     * @param expr1 operand
     */
    protected SQLExpression(Expression.MonadicOperator op, SQLExpression expr1)
    {
        st.append(op.toString());

        if (op.isHigherThan(expr1.lowestOperator))
        {
            st.append('(').append(expr1).append(')');
        }
        else
        {
            st.append(expr1);
        }

        stmt = expr1.stmt;
        mapping = expr1.mapping;
        lowestOperator = op;
    }

    /**
     * Perform an operation <pre>op</pre> between <pre>expr1</pre> and <pre>expr2</pre>.
     * @param expr1 the first expression
     * @param op the operator between operands
     * @param expr2 the second expression
     */
    protected SQLExpression(SQLExpression expr1, Expression.DyadicOperator op, SQLExpression expr2)
    {
        stmt = expr1.stmt;
        mapping = (expr1.mapping != null ? expr1.mapping : expr2.mapping);

        lowestOperator = op;
        if (op.isHigherThanLeftSide(expr1.lowestOperator))
        {
            st.append('(').append(expr1).append(')');
        }
        else
        {
            st.append(expr1);
        }

        st.append(op.toString());

        if (op.isHigherThanRightSide(expr2.lowestOperator))
        {
            st.append('(').append(expr2).append(')');
        }
        else
        {
            st.append(expr2);
        }
    }

    /**
     * Generates statement as "FUNCTION_NAME(arg[,argN])".
     * @param functionName Name of the function
     * @param args ScalarExpression list
     */
    protected SQLExpression(String functionName, List args)
    {
        st.append(functionName).append('(');
        SQLExpression arg = null;
        ListIterator i = args.listIterator();
        Object expr = i.next();
        if (expr instanceof String)
        {
            st.append(expr.toString());
        }
        else
        {
            arg = (SQLExpression)expr;
            st.append(arg);
        }

        while (i.hasNext())
        {
            expr = i.next();
            if (expr instanceof String)
            {
                st.append(',').append(expr.toString());
            }
            else
            {
                arg = (SQLExpression)expr;
                st.append(',').append(arg);
            }
        }
        stmt = arg.stmt;

        st.append(')');
    }

    /**
     * Generates statement as "FUNCTION_NAME(arg AS type[,argN as typeN])".
     * @param functionName Name of function
     * @param args ScalarExpression list
     * @param types String or ScalarExpression list
     */
    protected SQLExpression(String functionName, List args, List types)
    {
        st.append(functionName).append('(');

        ListIterator i = args.listIterator();
        ListIterator iTypes = types.listIterator();
        SQLExpression arg = (SQLExpression)i.next();
        st.append(arg);
        st.append(" AS ");
        Object type = iTypes.next();
        if (type instanceof SQLExpression)
        {
            st.append((SQLExpression)type);
        }
        else
        {
            st.append(type.toString());
        }
        this.stmt = arg.stmt;

        while (i.hasNext())
        {
            arg = (SQLExpression)i.next();
            st.append(',').append(arg);
            st.append(" AS ");
            type = iTypes.next(); 
            if (type instanceof SQLExpression)
            {
                st.append((SQLExpression)type);
            }
            else
            {
                st.append(type.toString());
            }
        }

        st.append(')');
    }

    /**
     * Method to return the SQL form of this expression.
     * @return The SQL
     */
    public SQLText toSQL()
    {
        return st;
    }

    /**
     * Accessor for the SQL statement.
     * @return The statement
     */
    public SQLStatement getSQLStatement()
    {
        return stmt;
    }

    /**
     * Conditional And. Evaluates its right-hand operand only if the value of its left-hand operand is true.
     * @param expr the right-hand operand
     * @return the result value is true if both operand values are true; otherwise, the result is false.
     */
    public BooleanExpression and(SQLExpression expr)
    {
        throw new IllegalExpressionOperationException(this, "&&", expr);
    }

    /**
     * Exclusive OR
     * @param expr the right-hand operand
     * @return the result value is the bitwise exclusive OR of the operand values.
     */
    public BooleanExpression eor(SQLExpression expr)
    {
        throw new IllegalExpressionOperationException(this, "^", expr);
    }

    /**
     * Conditional OR. Evaluates its right-hand operand only if the value of its left-hand operand is false. 
     * @param expr the right-hand operand
     * @return the result value is false if both operand values are false; otherwise, the result is true.
     */
    public BooleanExpression ior(SQLExpression expr)
    {
        throw new IllegalExpressionOperationException(this, "||", expr);
    }

    /**
     * Logical complement 
     * @return the result value is false if operand is true; otherwise, the result is true.
     */    
    public BooleanExpression not()
    {
        throw new IllegalExpressionOperationException("!", this);
    }
    
    /**
     * Equality operator (equals to)
     * @param expr the right-hand operand
     * @return The type of an equality expression is a boolean
     */
    public BooleanExpression eq(SQLExpression expr)
    {
        throw new IllegalExpressionOperationException(this, "==", expr);
    }

    /**
     * Equality operator (not equals to)
     * @param expr the right-hand operand
     * @return The type of an equality expression is a boolean
     */
    public BooleanExpression noteq(SQLExpression expr)
    {
        throw new IllegalExpressionOperationException(this, "!=", expr);
    }

    /**
     * Relational operator (lower than)
     * @param expr the right-hand operand
     * @return true if the value of the left-hand operand is less than the value of the right-hand operand, 
     *     and otherwise is false.
     */    
    public BooleanExpression lt(SQLExpression expr)
    {
        throw new IllegalExpressionOperationException(this, "<", expr);
    }

    /**
     * Relational operator (lower than or equals)
     * @param expr the right-hand operand
     * @return true if the value of the left-hand operand is less than or equal to the value of the 
     *     right-hand operand, and otherwise is false.
     */    
    public BooleanExpression le(SQLExpression expr)
    {
        throw new IllegalExpressionOperationException(this, "<=", expr);
    }

    /**
     * Relational operator (greater than)
     * @param expr the right-hand operand
     * @return true if the value of the left-hand operand is greater than the value of the right-hand 
     *     operand, and otherwise is false.
     */    
    public BooleanExpression gt(SQLExpression expr)
    {
        throw new IllegalExpressionOperationException(this, ">", expr);
    }

    /**
     * Relational operator (greater than or equals)
     * @param expr the right-hand operand
     * @return true if the value of the left-hand operand is greater than or equal the value of the 
     *     right-hand operand, and otherwise is false.
     */    
    public BooleanExpression ge(SQLExpression expr)
    {
        throw new IllegalExpressionOperationException(this, ">=", expr);
    }

    /**
     * Type Comparison Operator instanceof
     * @param expr the right-hand ReferenceType expression
     * @return true if the value of the RelationalExpression is not null and the reference could be cast to
     *     the ReferenceType without raising a ClassCastException. Otherwise the result is false.
     */
    public BooleanExpression instanceOf(SQLExpression expr)
    {
        throw new IllegalExpressionOperationException(this, "instanceof", expr);
    }

    /**
     * In expression. Return true if this is contained by <code>expr</code>
     * @param expr the right-hand expression
     * @return true if the left-hand expression is contained by the right-hand expression. 
     *     Otherwise the result is false.
     */    
    public BooleanExpression in(SQLExpression expr)
    {
        throw new IllegalExpressionOperationException(this, "in", expr);
    }

    /**
     * Additive Operator. The binary + operator performs addition when applied to two operands 
     * of numeric type, producing the sum of the operands. If the type of either operand of a + operator is 
     * String, then the operation is string concatenation.
     * @param expr the right-hand operand
     * @return If one of the operands is String, the returned value is the string concatenation; 
     *     The sum of two operands of numeric type. The left-hand operand is the minuend and the right-hand 
     *     operand is the subtrahend;
     */
    public SQLExpression add(SQLExpression expr)
    {
        throw new IllegalExpressionOperationException(this, "+", expr);
    }

    /**
     * Additive Operator. The binary - operator subtracts right-hand operand from left-hand operand.
     * @param expr the right-hand operand
     * @return The binary - operator performs subtraction when applied to two operands of numeric type 
     *     producing the difference of its operands; the left-hand operand is the minuend and the right-hand 
     *     operand is the subtrahend.
     */
    public SQLExpression sub(SQLExpression expr)
    {
        throw new IllegalExpressionOperationException(this, "-", expr);
    }

    /**
     * Multiplication Operator 
     * @param expr the right-hand operator
     * @return The binary * operator performs multiplication, producing the product of its operands. 
     */
    public SQLExpression mul(SQLExpression expr)
    {
        throw new IllegalExpressionOperationException(this, "*", expr);
    }

    /**
     * Division Operator. The left-hand operand is the dividend and the right-hand operand is the divisor.
     * @param expr the right-hand operator
     * @return The binary / operator performs division, producing the quotient of its operands
     */
    public SQLExpression div(SQLExpression expr)
    {
        throw new IllegalExpressionOperationException(this, "/", expr);
    }

    /**
     * Remainder Operator. The left-hand operand is the dividend and the right-hand operand is the divisor.
     * @param expr the right-hand operator
     * @return The binary % operator is said to yield the remainder of its operands from an implied division
     */
    public SQLExpression mod(SQLExpression expr)
    {
        throw new IllegalExpressionOperationException(this, "%", expr);
    }

    /**
     * Unary Minus Operator
     * @return the type of the unary minus expression is the promoted type of the operand.
     */
    public SQLExpression neg()
    {
        throw new IllegalExpressionOperationException("-", this);
    }

    /**
     * Bitwise Complement Operator
     * @return the type of the unary bitwise complement expression is the promoted type of the operand.
     */
    public SQLExpression com()
    {
        throw new IllegalExpressionOperationException("~", this);
    }

    /**
     * A cast expression converts, at run time, a value of one type to a similar value of another type;
     * or confirms, at compile time, that the type of an expression is boolean; or checks, at run time, 
     * that a reference value refers to an object whose class is compatible with a specified reference type.
     * The type of the operand expression must be converted to the type explicitly named by the cast operator.
     * @param type the type named by the cast operator
     * @return the converted value
     */
    public SQLExpression cast(Class type)
    {
        throw new IllegalExpressionOperationException("cast to " + type.getName(), this);
    }

    /**
     * Access a field of this object (if it is an object with fields).
     * @param fieldName Name of the field
     * @return Expression for this field
     */
    public SQLExpression accessField(String fieldName)
    {
        throw new IllegalExpressionOperationException("access of field " + fieldName, this);
    }

    /**
     * Invocation of a method on this expression.
     * @param type the type named by the cast operator
     * @return the converted value
     */
    public SQLExpression invoke(String methodName, List args)
    {
        throw new IllegalExpressionOperationException("." + methodName, this);
    }
}