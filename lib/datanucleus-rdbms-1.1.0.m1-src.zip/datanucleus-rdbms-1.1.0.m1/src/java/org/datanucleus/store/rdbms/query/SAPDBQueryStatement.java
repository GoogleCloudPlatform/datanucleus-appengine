/**********************************************************************
Copyright (c) 2004 Ralf Ullrich and others. All rights reserved.
Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
 

Contributors:
    ...
**********************************************************************/
package org.datanucleus.store.rdbms.query;

import java.util.Iterator;

import org.datanucleus.ClassLoaderResolver;
import org.datanucleus.store.mapped.DatastoreContainerObject;
import org.datanucleus.store.mapped.DatastoreIdentifier;
import org.datanucleus.store.mapped.expression.ScalarExpression;
import org.datanucleus.store.mapped.query.StatementText;

/**
 * Representation of a Query Statement in SAPDB.
 *
 * @version $Revision: 1.12 $
 **/
public class SAPDBQueryStatement extends QueryStatement
{
    /**
     * QueryStatement constructor 
     * @param initialTable The main table for this statement.
     * @param clr ClassLoader resolver
     */
    public SAPDBQueryStatement(DatastoreContainerObject initialTable, ClassLoaderResolver clr)
    {
        super(initialTable, clr);
    }

    /**
     * QueryStatement constructor 
     * @param initialTable The main table for this statement.
     * @param alias The alias for the main table
     * @param clr ClassLoader resolver
     */
    public SAPDBQueryStatement(DatastoreContainerObject initialTable, DatastoreIdentifier alias, ClassLoaderResolver clr)
    {
        super(initialTable, alias, clr);
    }

    /**
     * Convenience method to generate the ordering statement to add to the overall
     * query statement.
     * @return The ordering statement
     */
    protected StatementText generateOrderingStatement()
    {
        StatementText orderByStmt = null;
        if (orderingExpressions != null && orderingExpressions.length > 0)
        {
            orderByStmt = new StatementText();
            for (int i=0; i<orderingExpressions.length; ++i)
            {
                if (i > 0)
                {
                    orderByStmt.append(',');
                }

                orderByStmt.append(Integer.toString(orderingColumnIndexes[i]));
                if (orderingDirections[i])
                {
                    orderByStmt.append(" DESC");
                }
            }
        }

        return orderByStmt;
    }

    /** Positions of the ordering columns in the select list. */
    private int[] orderingColumnIndexes;

    /**
     * Convenience method to add any necessary columns to the SELECT that are needed
     * by the ordering constraint.
     */
    protected void addOrderingColumnsToSelect()
    {
        if (orderingExpressions != null)
        {
            orderingColumnIndexes = new int[orderingExpressions.length];

            // Add the ordering columns to the selected list, saving the positions
            for (int i=0; i<orderingExpressions.length; ++i)
            {
                selected.add(orderingExpressions[i].toStatementText(ScalarExpression.PROJECTION));
                orderingColumnIndexes[i] = selected.size();

                Iterator iterator = union.iterator();
                while (iterator.hasNext())
                {
                    QueryStatement qs = ((QueryStatement)iterator.next());
                    qs.selectScalarExpression(orderingExpressions[i]);
                }
            }
        }
    }
}