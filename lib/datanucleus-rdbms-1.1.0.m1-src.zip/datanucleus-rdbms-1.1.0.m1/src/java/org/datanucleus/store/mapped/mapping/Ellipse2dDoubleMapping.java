/**********************************************************************
Copyright (c) 2007 Thomas Marti and others. All rights reserved.
Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.

Contributors:
    ...
**********************************************************************/
package org.datanucleus.store.mapped.mapping;

import java.awt.geom.Ellipse2D;

import org.datanucleus.ClassLoaderResolver;
import org.datanucleus.ClassNameConstants;
import org.datanucleus.ObjectManager;
import org.datanucleus.metadata.AbstractMemberMetaData;
import org.datanucleus.store.mapped.DatastoreAdapter;
import org.datanucleus.store.mapped.DatastoreContainerObject;
import org.datanucleus.store.mapped.expression.LogicSetExpression;
import org.datanucleus.store.mapped.expression.QueryExpression;
import org.datanucleus.store.mapped.expression.ScalarExpression;

/**
 * Mapping for java.awt.geom.Ellipse2D.Double, maps the x, y, width and height values to double-precision datastore fields.
 *
 * @version $Revision: 1.20 $
 */
public class Ellipse2dDoubleMapping extends SingleFieldMultiMapping
{

    private static final Ellipse2D.Double sampleValue = new Ellipse2D.Double(0, 0, 1, 1);

	/* (non-Javadoc)
     * @see org.datanucleus.store.mapping.JavaTypeMapping#initialize()
     */
    public void initialize(DatastoreAdapter dba, AbstractMemberMetaData fmd, DatastoreContainerObject container, ClassLoaderResolver clr)
    {
		super.initialize(dba, fmd, container, clr);

        addDatastoreField(ClassNameConstants.DOUBLE); // X
        addDatastoreField(ClassNameConstants.DOUBLE); // Y
        addDatastoreField(ClassNameConstants.DOUBLE); // Width
        addDatastoreField(ClassNameConstants.DOUBLE); // Height
    }

    /* (non-Javadoc)
     * @see org.datanucleus.store.mapping.JavaTypeMapping#getJavaType()
     */
    public Class getJavaType()
    {
        return Ellipse2D.Double.class;
    }

    /* (non-Javadoc)
     * @see org.datanucleus.store.mapping.JavaTypeMapping#getSampleValue()
     */
    public Object getSampleValue(ClassLoaderResolver clr)
    {
        return sampleValue;
    }
    
    /* (non-Javadoc)
     * @see org.datanucleus.store.mapping.JavaTypeMapping#setObject(org.datanucleus.ObjectManager, java.lang.Object, int[], java.lang.Object)
     */
    public void setObject(ObjectManager om, Object preparedStatement, int[] exprIndex, Object value)
    {
    	Ellipse2D ellipse = (Ellipse2D)value;
        if (ellipse == null)
        {
    		for (int i = 0; i < exprIndex.length; i++) 
    		{
    			getDataStoreMapping(i).setObject(preparedStatement, exprIndex[i], null);					
			}
        }
        else
        {
            getDataStoreMapping(0).setDouble(preparedStatement,exprIndex[0],ellipse.getX());
            getDataStoreMapping(1).setDouble(preparedStatement,exprIndex[1],ellipse.getY());
            getDataStoreMapping(2).setDouble(preparedStatement,exprIndex[2],ellipse.getWidth());
            getDataStoreMapping(3).setDouble(preparedStatement,exprIndex[3],ellipse.getHeight());
        }
    }
    
    /* (non-Javadoc)
     * @see org.datanucleus.store.mapping.JavaTypeMapping#getObject(org.datanucleus.ObjectManager, java.lang.Object, int[])
     */
    public Object getObject(ObjectManager om, Object resultSet, int[] exprIndex)
    {
        // Check for null entries
        if (getDataStoreMapping(0).getObject(resultSet, exprIndex[0]) == null)
        {
            return null;
        }

        double x = getDataStoreMapping(0).getDouble(resultSet,exprIndex[0]); 
        double y = getDataStoreMapping(1).getDouble(resultSet,exprIndex[1]); 
        double width  = getDataStoreMapping(2).getDouble(resultSet,exprIndex[2]); 
        double height = getDataStoreMapping(3).getDouble(resultSet,exprIndex[3]);
        return new Ellipse2D.Double(x, y, width, height);
    }

    // --------------------------------- JDOQL Query Methods -------------------------------------------

    /* (non-Javadoc)
     * @see org.datanucleus.store.mapping.JavaTypeMapping#newLiteral(org.datanucleus.store.query.QueryStatement, java.lang.Object)
     */
    public ScalarExpression newLiteral(QueryExpression qs, Object value)
    {
        return null;
    }

    /* (non-Javadoc)
     * @see org.datanucleus.store.mapping.JavaTypeMapping#newScalarExpression(org.datanucleus.store.query.QueryStatement, org.datanucleus.store.expression.TableExpression)
     */
    public ScalarExpression newScalarExpression(QueryExpression qs, LogicSetExpression te)
    {
        return null;
    }
}