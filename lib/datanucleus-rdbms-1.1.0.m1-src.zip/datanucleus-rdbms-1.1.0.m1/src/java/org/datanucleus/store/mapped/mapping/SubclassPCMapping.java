/**********************************************************************
Copyright (c) 2006 Andy Jefferson and others. All rights reserved.
Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.


Contributors:
    ...
***********************************************************************/
package org.datanucleus.store.mapped.mapping;

import org.datanucleus.ClassLoaderResolver;
import org.datanucleus.metadata.AbstractMemberMetaData;
import org.datanucleus.store.mapped.DatastoreAdapter;
import org.datanucleus.store.mapped.DatastoreContainerObject;
import org.datanucleus.store.mapped.expression.LogicSetExpression;
import org.datanucleus.store.mapped.expression.ObjectExpression;
import org.datanucleus.store.mapped.expression.ObjectLiteral;
import org.datanucleus.store.mapped.expression.QueryExpression;
import org.datanucleus.store.mapped.expression.ScalarExpression;
import org.datanucleus.store.rdbms.table.ColumnCreator;

/**
 * Mapping for a field that stores a PC object that uses "subclass-table" inheritance
 * and where this is mapped in the datastore as a separate FK for each subclass.
 *
 * @version $Revision: 1.9 $ 
 */
public class SubclassPCMapping extends MultiMapping
{
    /**
     * Initialize this JavaTypeMapping with the given DatastoreAdapter for
     * the given FieldMetaData.
     *  
     * @param dba The Datastore Adapter that this Mapping should use.
     * @param fmd FieldMetaData for the field to be mapped (if any)
     * @param container The datastore container storing this mapping (if any)
     * @param clr the ClassLoaderResolver
     */
    public void initialize(DatastoreAdapter dba, AbstractMemberMetaData fmd, DatastoreContainerObject container, 
            ClassLoaderResolver clr)
    {
		super.initialize(dba, fmd, container, clr);
        createColumns(datastoreContainer, fmd, clr);
    }

    /**
     * Convenience method to create a column for each implementation type of this reference.
     * @param datastoreContainer Table to use
     * @param fmd MetaData for the field
     * @param clr The ClassLoaderResolver
     */
    protected void createColumns(DatastoreContainerObject datastoreContainer, AbstractMemberMetaData fmd, 
            ClassLoaderResolver clr)
    {
        // Create columns for each possible implementation type of the reference field
        ColumnCreator.createColumnsForFieldUsingSubclassTable(this, datastoreContainer, fmd, clr);
    }

    /* (non-Javadoc)
     * @see org.datanucleus.store.mapping.JavaTypeMapping#getJavaType()
     */
    public Class getJavaType()
    {
        return null;
    }

    /* (non-Javadoc)
     * @see org.datanucleus.store.mapping.Mapping#getSampleValue()
     */
    public Object getSampleValue(ClassLoaderResolver clr)
    {
        throw new UnsupportedOperationException("Not yet implemented");
    }

    // ---------------------------------- JDOQL Query Methods -------------------------------------

    /* (non-Javadoc)
     * @see org.datanucleus.store.mapping.Mapping#newLiteral(org.datanucleus.store.QueryStatement, java.lang.Object)
     */
    public ScalarExpression newLiteral(QueryExpression qs, Object value)
    {
        ScalarExpression expr = new ObjectLiteral(qs, this, value, value.getClass().getName());
        return expr;
    }

    public ScalarExpression newScalarExpression(QueryExpression qs, LogicSetExpression te)
    {
        ScalarExpression expr = new ObjectExpression(qs, this, te);
        return expr;
    }
}