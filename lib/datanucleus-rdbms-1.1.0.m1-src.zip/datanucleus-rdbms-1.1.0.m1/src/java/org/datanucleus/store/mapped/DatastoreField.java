/**********************************************************************
Copyright (c) 2004 Andy Jefferson and others. All rights reserved. 
Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License. 
 

Contributors:
    ...
**********************************************************************/
package org.datanucleus.store.mapped;

import org.datanucleus.metadata.AbstractMemberMetaData;
import org.datanucleus.metadata.MetaData;
import org.datanucleus.store.mapped.mapping.DatastoreMapping;
import org.datanucleus.store.mapped.mapping.JavaTypeMapping;

/**
 * Representation of a Java field in a datastore.
 * In the case of RDBMS this will be a column.
 * In the case of a file-based structure this may be a file.
 * In the case of an XML-based structure this may be an node. 
 *
 * @version $Revision: 1.12 $
 **/ 
public interface DatastoreField extends DatastoreObject
{
    /**
     * Accessor for the type of data stored in this field.
     * @return The type of data in the field.
     */
    String getStoredJavaType();

    /**
     * Mutator to make the field the primary key.
     */
    void setAsPrimaryKey();

    /**
     * Accessor for whether the field is the primary key in the datastore.
     * @return whether the field is (part of) the primary key
     */
    boolean isPrimaryKey();

    /**
     * Accessor for whether the field is nullable in the datastore.
     * @return whether the field is nullable
     */
    boolean isNullable();

    /**
     * Accessor for the datastore mapping that this datastore field relates to.
     * @return The datastore mapping
     */
    DatastoreMapping getDatastoreMapping();

    /**
     * Method to associate this datastore field with its mapping.
     * @param mapping The mapping for this datastore field
     */
    void setDatastoreMapping(DatastoreMapping mapping);

    /**
     * Accessor for the Mapping for this field.
     * TODO Change this to DatastoreMapping since a DatastoreField maps via that and not JavaTypeMapping.
     * @return The Mapping
     */
    JavaTypeMapping getMapping();
    
    /**
     * Accessor for the DatastoreContainerObject container of this field
     * @return The DatastoreContainerObject
     */
    DatastoreContainerObject getDatastoreContainerObject();
    
    /**
     * Wraps the column name with a FUNCTION.
     * <PRE>example: SQRT(?) generates: SQRT(columnName)</PRE>
     * @param replacementValue the replacement to ?. Probably it's a column name, that may be fully qualified name or not
     * @return a String with function taking as parameter the replacementValue
     */
    String applySelectFunction(String replacementValue);

    /**
     * Copy the configuration of this field to another field
     * @param col the datastore field
     */
	void copyConfigurationTo(DatastoreField col);
	
    /**
     * Mutator for the nullability of the datastore field.
     * @return The datastore field with the updated info
     */
    DatastoreField setNullable();
    
    /**
     * Mutator for the defaultability of the datastore field.
     * @return The datastore field with the updated info
     */
    DatastoreField setDefaultable(); 

    /**
     * Mutator for the identifier of the column.
     * @param identifier The identifier
     */
    void setIdentifier(DatastoreIdentifier identifier);

    /**
     * Access the metadata definition defining this DatastoreField.
     * @return the MetaData
     */
    MetaData getMetaData();

    /**
     * Method to set the MetaData for this datastore field.
     * Should only be called before completion of initialisation.
     * @param md The MetaData
     */
    void setMetaData(MetaData md);

    /**
     * Accessor for the MetaData of the field that this is the datastore field for.
     * @return MetaData of the field (if representing a field of a class).
     */
    AbstractMemberMetaData getFieldMetaData();
}