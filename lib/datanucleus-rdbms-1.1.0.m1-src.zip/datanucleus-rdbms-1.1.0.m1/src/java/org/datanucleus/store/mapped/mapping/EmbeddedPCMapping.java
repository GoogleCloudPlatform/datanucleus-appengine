/**********************************************************************
Copyright (c) 2005 Andy Jefferson and others. All rights reserved. 
Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License. 
 

Contributors:
    ...
**********************************************************************/
package org.datanucleus.store.mapped.mapping;

import org.datanucleus.ClassLoaderResolver;
import org.datanucleus.StateManager;
import org.datanucleus.metadata.AbstractMemberMetaData;
import org.datanucleus.state.StateManagerFactory;
import org.datanucleus.store.mapped.DatastoreAdapter;
import org.datanucleus.store.mapped.DatastoreContainerObject;

/**
 * Mapping for a PC object embedded within another PC object (1-1 relation).
 * Provides mapping for a single Java type (the PC type) to multiple datastore columns.
 * Allows for nested embedded fields.
 * Implements MappingCallbacks since if we are embedding a MappingCallbacks field (e.g a BLOB on Oracle)
 * then we need in turn to call the underlying MappingCallbacks methods.
 *
 * @version $Revision: 1.35 $
 **/
public class EmbeddedPCMapping extends EmbeddedMapping implements MappingCallbacks
{
    /**
     * Initialize this JavaTypeMapping with the given DatastoreAdapter for
     * the given FieldMetaData.
     *  
     * @param dba The Datastore Adapter that this Mapping should use.
     * @param fmd FieldMetaData for the field to be mapped (if any)
     * @param container The datastore container storing this mapping (if any)
     * @param clr the ClassLoaderResolver
     */
    public void initialize(DatastoreAdapter dba, AbstractMemberMetaData fmd, DatastoreContainerObject container, ClassLoaderResolver clr)
    {
        initialize(dba, fmd, container, clr, fmd.getEmbeddedMetaData(), fmd.getTypeName(),
        		StateManager.EMBEDDED_PC);
    }

    /**
     * MappingCallback called when the owning object is being fetched.
     * @param sm StateManager of the owning object
     */
    public void postFetch(StateManager sm)
    {
        if (fmd.getAbsoluteFieldNumber() < 0)
        {
            return;
        }

        // Find the SM for the embedded PC object
        StateManager thisSM = getStateManagerForEmbeddedObject(sm);
        if (thisSM == null)
        {
            return;
        }

        for (int i=0;i<getNumberOfJavaTypeMappings();i++)
        {
            JavaTypeMapping m = getJavaTypeMapping(i);
            if (m instanceof MappingCallbacks)
            {
                ((MappingCallbacks)m).postFetch(thisSM);
            }
        }
    }

    /**
     * MappingCallback called when the owning object has just being inserted.
     * @param sm StateManager of the owning object
     */
    public void postInsert(StateManager sm)
    {
        if (fmd.getAbsoluteFieldNumber() < 0)
        {
            return;
        }

        // Find the SM for the embedded PC object
        StateManager thisSM = getStateManagerForEmbeddedObject(sm);
        if (thisSM == null)
        {
            return;
        }

        // Call postInsert on any MappingCallbacks components
        for (int i=0;i<getNumberOfJavaTypeMappings();i++)
        {
            JavaTypeMapping m = getJavaTypeMapping(i);
            if (m instanceof MappingCallbacks)
            {
                ((MappingCallbacks)m).postInsert(thisSM);
            }
        }
    }

    /**
     * MappingCallback called when the owning object has just being udpated.
     * @param sm StateManager of the owning object
     */
    public void postUpdate(StateManager sm)
    {
        if (fmd.getAbsoluteFieldNumber() < 0)
        {
            return;
        }

        // Find the SM for the embedded PC object
        StateManager thisSM = getStateManagerForEmbeddedObject(sm);
        if (thisSM == null)
        {
            return;
        }

        // Call postUpdate on any MappingCallbacks components
        for (int i=0;i<getNumberOfJavaTypeMappings();i++)
        {
            JavaTypeMapping m = getJavaTypeMapping(i);
            if (m instanceof MappingCallbacks)
            {
                ((MappingCallbacks)m).postUpdate(thisSM);
            }
        }
    }

    /**
     * MappingCallback called when the owning object is about to be deleted.
     * @param sm StateManager of the owning object
     */
    public void preDelete(StateManager sm)
    {
        if (fmd.getAbsoluteFieldNumber() < 0)
        {
            return;
        }

        // Find the SM for the embedded PC object
        StateManager thisSM = getStateManagerForEmbeddedObject(sm);
        if (thisSM == null)
        {
            return;
        }

        // Call preDelete on any MappingCallbacks components
        for (int i=0;i<getNumberOfJavaTypeMappings();i++)
        {
            JavaTypeMapping m = getJavaTypeMapping(i);
            if (m instanceof MappingCallbacks)
            {
                ((MappingCallbacks)m).preDelete(thisSM);
            }
        }
    }

    /**
     * Accessor for the StateManager of the embedded PC object when provided with the owner object.
     * @param ownerSM StateManager of the owner
     * @return StateManager of the embedded object
     */
    private StateManager getStateManagerForEmbeddedObject(StateManager ownerSM)
    {
        Object value = ownerSM.provideField(fmd.getAbsoluteFieldNumber()); // Owner (non-embedded) PC
        if (value == null)
        {
            return null;
        }

        StateManager thisSM = ownerSM.getObjectManager().findStateManager(value);
        if (thisSM == null)
        {
            // Assign a StateManager to manage our embedded object
            thisSM = StateManagerFactory.newStateManagerForEmbedded(ownerSM.getObjectManager(), value, false);
            thisSM.addEmbeddedOwner(ownerSM, fmd.getAbsoluteFieldNumber());
            thisSM.setPcObjectType(objectType);
        }

        return thisSM;
    }
}