/**********************************************************************
Copyright (c) 2008 Andy Jefferson and others. All rights reserved.
Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.

Contributors:
    ...
**********************************************************************/
package org.datanucleus.store.rdbms.sql.expression;

import org.datanucleus.query.expression.Expression;
import org.datanucleus.store.mapped.mapping.JavaTypeMapping;
import org.datanucleus.store.mapped.mapping.NullMapping;
import org.datanucleus.store.rdbms.sql.SQLStatement;

/**
 * Representation of a Null literal in a Query.
 */
public class NullLiteral extends SQLExpression implements Literal
{
    /**
     * Creates an integer literal.
     * @param stmt the SQL statement
     * @param mapping the mapping
     */
    public NullLiteral(SQLStatement stmt, JavaTypeMapping mapping)
    {
        super(stmt, null, new NullMapping(stmt.getDatabaseAdapter()));
        st.append("NULL");
    }

    public Object getValue()
    {
        return null;
    }

    public SQLExpression add(SQLExpression expr)
    {
        return this;
    }

    public BooleanExpression eq(SQLExpression expr)
    {
        if (expr instanceof NullLiteral)
        {
            return new BooleanLiteral(stmt, mapping, true);
        }
        /*if (expr instanceof ObjectExpression)
        {
            return expr.eq(this);
        }*/
        return new BooleanExpression(expr, Expression.OP_IS, this);
    }

    public BooleanExpression noteq(SQLExpression expr)
    {
        if (expr instanceof NullLiteral)
        {
            return new BooleanLiteral(stmt, mapping, false);
        }
        /*if (expr instanceof ObjectExpression)
        {
            return expr.noteq(this);
        }*/
        return new BooleanExpression(expr, Expression.OP_ISNOT, this);
    }

    /**
     * Method to save a "raw" value that this literal represents.
     * This value differs from the literal value since that is of the same type as this literal.
     * @param val The raw value
     */
    public void setRawValue(Object val)
    {
    }

    /**
     * Accessor for the "raw" value that this literal represents.
     * This value differs from the literal value since that is of the same type as this literal.
     * @return The raw value
     */
    public Object getRawValue()
    {
        return null;
    }
}