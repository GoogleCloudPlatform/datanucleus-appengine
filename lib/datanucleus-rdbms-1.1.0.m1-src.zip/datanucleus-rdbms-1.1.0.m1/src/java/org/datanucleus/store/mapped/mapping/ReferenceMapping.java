/**********************************************************************
Copyright (c) 2005 Andy Jefferson and others. All rights reserved.
Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.

Contributors:
2007 Andy Jefferson - implement RelationMappingCallbacks
    ...
***********************************************************************/
package org.datanucleus.store.mapped.mapping;

import org.datanucleus.ClassLoaderResolver;
import org.datanucleus.StateManager;
import org.datanucleus.metadata.AbstractClassMetaData;
import org.datanucleus.metadata.AbstractMemberMetaData;
import org.datanucleus.metadata.FieldRole;
import org.datanucleus.metadata.InheritanceStrategy;
import org.datanucleus.metadata.MetaDataUtils;
import org.datanucleus.store.mapped.DatastoreAdapter;
import org.datanucleus.store.mapped.DatastoreContainerObject;
import org.datanucleus.store.mapped.MappedStoreManager;
import org.datanucleus.store.mapped.expression.LogicSetExpression;
import org.datanucleus.store.mapped.expression.ObjectLiteral;
import org.datanucleus.store.mapped.expression.QueryExpression;
import org.datanucleus.store.mapped.expression.ReferenceExpression;
import org.datanucleus.store.mapped.expression.ScalarExpression;
import org.datanucleus.store.rdbms.table.ColumnCreator;
import org.datanucleus.util.NucleusLogger;

/**
 * Mapping for a reference type.
 * This can be used for things like interfaces, or Object which are simply a reference to
 * some specific (PersistenceCapable) class. All fields of this type have a list of
 * possible "implementations" of the reference type. A column is created for each possible 
 * implementation of the reference as a FK to the implementation table.
 */
public abstract class ReferenceMapping extends MultiMapping implements MappingCallbacks
{
    /**
     * Initialize this JavaTypeMapping with the given DatastoreAdapter for the given AbstractMemberMetaData.
     *  
     * @param dba The Datastore Adapter that this Mapping should use.
     * @param mmd AbstractMemberMetaData for the field to be mapped (if any)
     * @param container The datastore container storing this mapping (if any)
     * @param clr the ClassLoaderResolver
     */
    public void initialize(DatastoreAdapter dba, AbstractMemberMetaData mmd, 
            DatastoreContainerObject container, ClassLoaderResolver clr)
    {
        numberOfDatastoreFields = 0; // Reset indicator for datastore fields
		super.initialize(dba, mmd, container, clr);
        createColumns(datastoreContainer, mmd, clr);
    }

    /**
     * Convenience method to create a column for each implementation type of this reference.
     * @param datastoreContainer Table to use
     * @param fmd MetaData for the field
     * @param clr The ClassLoaderResolver
     */
    protected void createColumns(DatastoreContainerObject datastoreContainer, AbstractMemberMetaData fmd, 
            ClassLoaderResolver clr)
    {
        // Create columns for each possible implementation type of the reference field
        MappedStoreManager storeMgr = datastoreContainer.getStoreManager();
        if (fmd.getMappedBy() == null)
        {
            ColumnCreator.createColumnsForFieldUsingReference(this, datastoreContainer, fmd, clr, 
                fmd.isEmbedded() || fmd.getElementMetaData() != null);
        }
        else
        {
            // Either one end of a 1-1 relation, or the N end of a N-1
            AbstractClassMetaData refCmd = storeMgr.getOMFContext().getMetaDataManager().getMetaDataForInterface(fmd.getType(), clr);
            JavaTypeMapping referenceMapping = null;
            if (refCmd != null && refCmd.getInheritanceMetaData().getStrategyValue() == InheritanceStrategy.SUBCLASS_TABLE)
            {
                // TODO Is this block actually reachable ? Would we specify "inheritance" under "interface" elements?
                // Find the actual tables storing the other end (can be multiple subclasses)
                AbstractClassMetaData[] cmds = storeMgr.getClassesManagingTableForClass(refCmd, clr);
                if (cmds != null && cmds.length > 0)
                {
                    if (cmds.length > 1)
                    {
                        NucleusLogger.PERSISTENCE.warn("Field " + fmd.getFullFieldName() + 
                            " represents either a 1-1 relation, or a N-1 relation where the other end uses" +
                            " \"subclass-table\" inheritance strategy and more than 1 subclasses with a table. " +
                            "This is not fully supported currently");
                    }
                }
                else
                {
                    // No subclasses of the class using "subclasses-table" so no mapping!
                    // TODO Throw an exception ?
                    return;
                }
                // TODO We need a mapping for each of the possible subclass tables
                referenceMapping = storeMgr.getDatastoreClass(cmds[0].getFullClassName(), clr).getIDMapping();
            }
            else
            {
                String[] implTypes = MetaDataUtils.getInstance().getImplementationNamesForReferenceField(fmd, 
                    FieldRole.ROLE_FIELD, clr);
                for (int j=0; j<implTypes.length; j++)
                {
                    referenceMapping = storeMgr.getDatastoreClass(implTypes[j], clr).getIDMapping();
                    JavaTypeMapping mapping = dba.getMapping(clr.classForName(implTypes[j]), storeMgr);
                    mapping.setReferenceMapping(referenceMapping);
                    this.addJavaTypeMapping(mapping);
                }
            }
        }
    }

    /* (non-Javadoc)
     * @see org.datanucleus.store.mapping.JavaTypeMapping#getJavaType()
     */
    public Class getJavaType()
    {
        return null;
    }

    /* (non-Javadoc)
     * @see org.datanucleus.store.mapping.Mapping#getSampleValue()
     */
    public Object getSampleValue(ClassLoaderResolver clr)
    {
        throw new UnsupportedOperationException("Not yet implemented");
    }

    // ---------------------------------- JDOQL Query Methods -------------------------------------

    /* (non-Javadoc)
     * @see org.datanucleus.store.mapping.Mapping#newLiteral(org.datanucleus.store.QueryStatement, java.lang.Object)
     */
    public ScalarExpression newLiteral(QueryExpression qs, Object value)
    {
        ScalarExpression expr = new ObjectLiteral(qs, this, value, value.getClass().getName());
        return expr;
    }

    public ScalarExpression newScalarExpression(QueryExpression qs, LogicSetExpression te)
    {
        ScalarExpression expr = new ReferenceExpression(qs, this, te);
        return expr;
    }

    // -------------------------- MappingCallbacks methods ----------------------------

    /**
     * Method executed just after a fetch of the owning object, allowing any necessary action
     * to this field and the object stored in it.
     * @param sm StateManager for the owner.
     */
    public void postFetch(StateManager sm)
    {
    }

    /**
     * Method executed just after the insert of the owning object, allowing any necessary action
     * to this field and the object stored in it.
     * @param sm StateManager for the owner
     */
    public void postInsert(StateManager sm)
    {
    }

    /**
     * Method executed just afer any update of the owning object, allowing any necessary action
     * to this field and the object stored in it.
     * @param sm StateManager for the owner
     */
    public void postUpdate(StateManager sm)
    {
    }

    /**
     * Method executed just before the owning object is deleted, allowing tidying up of any
     * relation information.
     * @param sm StateManager for the owner
     */
    public void preDelete(StateManager sm)
    {
        boolean isDependentElement = fmd.isDependent();
        if (!isDependentElement)
        {
            // Not dependent so do nothing, or should we null here ?
            return;
        }

        // Loop through all implementations
        for (int i=0;i<javaTypeMappings.length;i++)
        {
            final JavaTypeMapping mapping = javaTypeMappings[i];
            if (mapping instanceof PersistenceCapableMapping)
            {
                // makes sure field is loaded
                int fieldNumber = getFieldMetaData().getAbsoluteFieldNumber();
                sm.getObjectManager().getApiAdapter().isLoaded(sm, fieldNumber);
                Object pc = sm.provideField(fieldNumber);
                if (pc != null)
                {
                    // Null out the FK in the datastore using a direct update (since we are deleting)
                    sm.replaceField(fieldNumber, null, true);
                    sm.getStoreManager().getPersistenceHandler().updateObject(sm, new int[]{fieldNumber});

                    // delete object
                    sm.getObjectManager().deleteObjectInternal(pc);
                }
            }
        }
    }
}