/**********************************************************************
Copyright (c) 2008 Andy Jefferson and others. All rights reserved.
Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.

Contributors:
    ...
**********************************************************************/
package org.datanucleus.store.rdbms.sql.expression;

import java.util.ArrayList;

import org.datanucleus.store.rdbms.adapter.DatabaseAdapter;

/**
 * Utility methods for working with SQL expressions.
 */
public class ExpressionUtils
{
    /**
     * Method to return a numeric expression for the supplied SQL expression.
     * Makes use of the RDBMS function to convert to a numeric.
     * @param expr The expression
     * @return
     */
    public static NumericExpression getNumericExpression(SQLExpression expr)
    {
        DatabaseAdapter dba = expr.getSQLStatement().getDatabaseAdapter();
        /*if (expr instanceof CharacterLiteral)
        {
            char c = ((Character)((CharacterLiteral)expr).getValue()).charValue();
            BigInteger value = new BigInteger("" + (int)c);
            return (NumericExpression) dba.getMapping(value.getClass(), expr).newLiteral(expr.getSQLStatement(), value);
        }        
        else if (expr instanceof Literal)
        {
            BigInteger value = new BigInteger((String)((Literal)expr).getValue());
            return (NumericExpression) dba.getMapping(value.getClass(), expr).newLiteral(expr.getSQLStatement(), value);
        }*/

        ArrayList args = new ArrayList();
        args.add(expr);
        return new NumericExpression(dba.getNumericConversionFunction(), args);
    }
}