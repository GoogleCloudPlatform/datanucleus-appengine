/**********************************************************************
Copyright (c) 2008 Andy Jefferson and others. All rights reserved.
Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.

Contributors:
    ...
**********************************************************************/
package org.datanucleus.store.rdbms.sql;

import org.datanucleus.exceptions.NucleusException;

/**
 * Representation of a join in an SQL statement.
 * The join is of a type (see ANSI SQL), and with inner/left outer/right outer is accompanied by
 * join conditions, joining from the source table to the target table via columns. Additionally
 * other conditions can be applied to restrict the join (such as discriminator).
 */
public class SQLJoin
{
    /** INNER JOIN **/
    public static final int INNER_JOIN = 1;

    /** LEFT OUTER JOIN **/
    public static final int LEFT_OUTER_JOIN = 2;

    /** RIGHT OUTER JOIN **/
    public static final int RIGHT_OUTER_JOIN = 3;

    /** CROSS JOIN **/
    public static final int CROSS_JOIN = 4;

    /** Type of join to perform. */
    private final int type;

    /** Table we are joining to. This is always set irrespective the type of join. */
    private SQLTable table;

    /** Column references joining from (on the source table). */
    private SQLColumn[] sourceColumns;

    /** Column references joining to (on the target table). */
    private SQLColumn[] targetColumns;

    /** Optional condition(s) to apply on the join. e.g discriminator values */
    // TODO Allow this

    /**
     * Constructor for a join.
     * @param type Type of join (one of the defined types in this class).
     * @param tbl Table to join to (required)
     * @param sourceCols "source" referenced columns (not for CROSS JOIN)
     * @param targetCols "target" referenced columns (not for CROSS JOIN)
     */
    public SQLJoin(int type, SQLTable tbl, SQLColumn[] sourceCols, SQLColumn[] targetCols)
    {
        if (type != INNER_JOIN && type != LEFT_OUTER_JOIN && type != RIGHT_OUTER_JOIN && type != CROSS_JOIN)
        {
            throw new NucleusException("Unsupported join type specified : " + type);
        }
        else if (tbl == null)
        {
            throw new NucleusException("Specification of join must supply the table reference");
        }
        else if (sourceCols != null && targetCols == null)
        {
            throw new NucleusException("Inconsistent from/to column references for join.");
        }
        else if (targetCols != null && sourceCols == null)
        {
            throw new NucleusException("Inconsistent from/to column references for join.");
        }
        else if (targetCols != null && sourceCols != null && sourceCols.length != targetCols.length)
        {
            throw new NucleusException("Inconsistent from/to column references for join.");
        }

        this.type = type;
        this.table = tbl;
        this.sourceColumns = sourceCols;
        this.targetColumns = targetCols;
    }

    /**
     * @return the type of join
     */
    public int getType()
    {
        return type;
    }

    /**
     * @return the table to join to
     */
    public SQLTable getTable()
    {
        return table;
    }

    /**
     * @return the "source" referenced columns
     */
    public SQLColumn[] getSourceColumns()
    {
        return sourceColumns;
    }

    /**
     * @return the "target" referenced columns
     */
    public SQLColumn[] getTargetColumns()
    {
        return targetColumns;
    }
}