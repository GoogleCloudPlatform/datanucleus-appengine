/**********************************************************************
Copyright (c) 2005 Andy Jefferson and others. All rights reserved.
Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License. 


Contributors:
    ...
**********************************************************************/
package org.datanucleus.store.rdbms.table;

import org.datanucleus.ClassLoaderResolver;
import org.datanucleus.metadata.AbstractMemberMetaData;
import org.datanucleus.metadata.ColumnMetaData;
import org.datanucleus.metadata.ElementMetaData;
import org.datanucleus.metadata.FieldRole;
import org.datanucleus.metadata.PrimaryKeyMetaData;
import org.datanucleus.store.mapped.DatastoreArray;
import org.datanucleus.store.mapped.DatastoreIdentifier;
import org.datanucleus.store.mapped.mapping.JavaTypeMapping;
import org.datanucleus.store.rdbms.RDBMSManager;
import org.datanucleus.store.rdbms.sqlidentifier.RDBMSIdentifierFactory;
import org.datanucleus.util.NucleusLogger;

/**
 * Representation of a join table for an array. An array requires ordering of elements so that they can be stored
 * and retrieved in the same order.
 * <h3>JoinTable Mappings</h3>
 * <p>
 * The join table consists of the following mappings :-
 * <ul>
 * <li><B>ownerMapping</B> linking back to the owning class with the Collection.</li>
 * <li><B>elementMapping</B> either being an FK link to the element table or being an 
 * embedded/serialised element stored wholely in this table.</li>
 * <li><B>orderMapping</B> providing the ordering of the elements.</li>
 * </ul>
 * The primary-key is formed from the ownerMapping and the orderMapping (unless overridden by the user).
 * </p>
 */
public class ArrayTable extends ElementContainerTable implements DatastoreArray
{
    /**
     * Constructor.
     * @param tableName Identifier name of the table
     * @param fmd MetaData for the field of the owner
     * @param storeMgr The Store Manager managing these tables.
     */
    public ArrayTable(DatastoreIdentifier tableName,
                      AbstractMemberMetaData fmd,
                      RDBMSManager storeMgr)
    {
        super(tableName, fmd, storeMgr);
    }

    /**
     * Method to initialise the table definition.
     * @param clr The ClassLoaderResolver
     */
    public void initialize(ClassLoaderResolver clr)
    {
        super.initialize(clr);

        PrimaryKeyMetaData pkmd = (fmd.getJoinMetaData() != null ? fmd.getJoinMetaData().getPrimaryKeyMetaData() : null);
        boolean pkColsSpecified = (pkmd != null ? pkmd.getColumnMetaData() != null : false);
        boolean pkRequired = requiresPrimaryKey();

        // Add field(s) for element
        boolean elementPC = (fmd.hasArray() && fmd.getArray().getElementClassMetaData() != null);
        if (isSerialisedElementPC() || isEmbeddedElementPC() || (isEmbeddedElement() && !elementPC))
        {
            // Element = PC(embedded), PC(serialised), Non-PC(embedded)
            elementMapping = dba.getMappingManager().getMapping(this, fmd, dba, clr, 
                JavaTypeMapping.MAPPING_ARRAY_ELEMENT);
            if (NucleusLogger.DATASTORE.isDebugEnabled())
            {
                debugMapping(elementMapping);
            }
        }
        else
        {
            // Element = PC
            ColumnMetaData[] elemColmd = null;
            ElementMetaData elemmd = fmd.getElementMetaData();
            if (elemmd != null &&
                elemmd.getColumnMetaData() != null &&
                elemmd.getColumnMetaData().length > 0)
            {
                // Column mappings defined at this side (1-N, M-N)
                elemColmd = elemmd.getColumnMetaData();
            }
            elementMapping = ColumnCreator.createColumnsForJoinTables(fmd.getType().getComponentType(), fmd,
                elemColmd, storeMgr, this, false, true, fmd.getArray().isSerializedElement(), false, 
                FieldRole.ROLE_ARRAY_ELEMENT, clr);
            if (NucleusLogger.DATASTORE.isDebugEnabled())
            {
                debugMapping(elementMapping);
            }
        }

        // Add order mapping
        ColumnMetaData colmd = null;
        if (fmd.getOrderMetaData() != null && fmd.getOrderMetaData().getColumnMetaData() != null &&
            fmd.getOrderMetaData().getColumnMetaData().length > 0)
        {
            // Specified "order" column info
            colmd = fmd.getOrderMetaData().getColumnMetaData()[0];
        }
        else
        {
            // No column name so use default
            DatastoreIdentifier id =
                ((RDBMSIdentifierFactory)storeMgr.getIdentifierFactory()).newIndexFieldIdentifier();
            colmd = new ColumnMetaData(fmd, id.getIdentifier());
        }
        orderMapping = dba.getMapping(int.class, storeMgr); // JDO2 spec [18.5] order column is assumed to be "int"
        ColumnCreator.createIndexColumn(orderMapping, storeMgr, clr, this, colmd, pkRequired && !pkColsSpecified);
        if (NucleusLogger.DATASTORE.isDebugEnabled())
        {
            debugMapping(orderMapping);
        }

        // Define primary key of the join table (if any)
        if (pkRequired && pkColsSpecified)
        {
            // Apply the users PK specification
            applyUserPrimaryKeySpecification(pkmd);
        }

        state = TABLE_STATE_INITIALIZED;
    }

    /**
     * Accessor for the element type stored in this array.
     * @return Name of element type.
     */
    public String getElementType()
    {
        return fmd.getType().getComponentType().getName();
    }

    /**
     * Accessor for whether the element is serialised into this table.
     * This can be a serialised PersistenceCapable, or a serialised simple type
     * @return Whether the element is serialised.
     */
    public boolean isSerialisedElement()
    {
        if (fmd.getArray() != null && fmd.getArray().isSerializedElement())
        {
            return true;
        }
        return false;
    }

    /**
     * Accessor for whether the element is embedded into this table.
     * This can be an embedded PersistenceCapable, or an embedded simple type
     * @return Whether the element is embedded.
     */
    public boolean isEmbeddedElement()
    {
        if (fmd.getArray() != null && fmd.getArray().isSerializedElement())
        {
            // Serialised takes precedence
            return false;
        }
        else if (fmd.getArray() != null && fmd.getArray().isEmbeddedElement())
        {
            return true;
        }
        return false;
    }

    /**
     * Accessor for whether the element is a PersistenceCapable(serialised)
     * @return Whether the element is PC and is serialised
     */
    public boolean isSerialisedElementPC()
    {
        if (fmd.getArray() != null && fmd.getArray().isSerializedElement())
        {
            return true;
        }
        return false;
    }

    /**
     * Accessor for whether the element is a PersistenceCapable(embedded)
     * @return Whether the element is PC and is embedded
     */
    public boolean isEmbeddedElementPC()
    {
        if (fmd.getArray() != null && fmd.getArray().isSerializedElement())
        {
            // Serialisation takes precedence over embedding
            return false;
        }
        if (fmd.getElementMetaData() != null && fmd.getElementMetaData().getEmbeddedMetaData() != null)
        {
            return true;
        }
        return false;
    }
}