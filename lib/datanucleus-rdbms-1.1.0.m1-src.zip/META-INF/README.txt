RDBMS Plugin
============
This project provides support for persistence to RDBMS datastores.

This project is licensed by the Apache 2 license which you should have received with this.
