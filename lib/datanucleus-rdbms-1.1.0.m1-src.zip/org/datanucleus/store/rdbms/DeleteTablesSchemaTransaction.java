/**********************************************************************
Copyright (c) 2008 Andy Jefferson and others. All rights reserved.
Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.

Contributors:
    ...
**********************************************************************/
package org.datanucleus.store.rdbms;

import java.sql.SQLException;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import org.datanucleus.ClassLoaderResolver;
import org.datanucleus.exceptions.NucleusException;
import org.datanucleus.exceptions.NucleusUserException;
import org.datanucleus.store.StoreDataManager;
import org.datanucleus.store.rdbms.table.TableImpl;
import org.datanucleus.store.rdbms.table.ViewImpl;
import org.datanucleus.util.Localiser;
import org.datanucleus.util.NucleusLogger;

/**
 * Schema transaction for deleting all known tables.
 */
public class DeleteTablesSchemaTransaction extends AbstractSchemaTransaction
{
    /** Localiser for messages. */
    protected static final Localiser LOCALISER = Localiser.getInstance(
        "org.datanucleus.store.rdbms.Localisation", RDBMSManager.class.getClassLoader());

    StoreDataManager storeDataMgr = null;

    /**
     * @param rdbmsMgr
     * @param isolationLevel
     */
    public DeleteTablesSchemaTransaction(RDBMSManager rdbmsMgr, int isolationLevel, StoreDataManager dataMgr)
    {
        super(rdbmsMgr, isolationLevel);
        this.storeDataMgr = dataMgr; // StoreDataManager used by the RDBMSManager
    }

    /* (non-Javadoc)
     * @see org.datanucleus.store.rdbms.AbstractSchemaTransaction#run(org.datanucleus.ClassLoaderResolver)
     */
    protected void run(ClassLoaderResolver clr)
    throws SQLException
    {
        synchronized (rdbmsMgr)
        {
            boolean success = true;
            try
            {
                NucleusLogger.DATASTORE_SCHEMA.info(LOCALISER.msg("050045", 
                    rdbmsMgr.getCatalogName(), rdbmsMgr.getSchemaName()));

                Map baseTablesByName = new HashMap();
                Map viewsByName = new HashMap();
                for (Iterator i = storeDataMgr.getManagedStoreData().iterator(); i.hasNext();)
                {
                    RDBMSStoreData data = (RDBMSStoreData) i.next();
                    if (NucleusLogger.DATASTORE_SCHEMA.isInfoEnabled())
                    {
                        NucleusLogger.DATASTORE_SCHEMA.info(LOCALISER.msg("050046",data.getName()));
                    }
                    
                    // If the class has a table/view to remove, add it to the list
                    if (data.hasTable())
                    {
                        if (data.mapsToView())
                        {
                            viewsByName.put(data.getDatastoreIdentifier(), 
                                data.getDatastoreContainerObject());
                        }
                        else
                        {
                            baseTablesByName.put(data.getDatastoreIdentifier(),
                                data.getDatastoreContainerObject());
                        }
                    }
                }
                
                // Remove tables, table constraints and views in
                // reverse order from which they were created
                Iterator viewsIter = viewsByName.values().iterator();
                while (viewsIter.hasNext())
                {
                    ((ViewImpl) viewsIter.next()).drop(getCurrentConnection());
                }

                Iterator tablesIter = baseTablesByName.values().iterator();
                while (tablesIter.hasNext())
                {
                    ((TableImpl) tablesIter.next()).dropConstraints(getCurrentConnection());
                }
                tablesIter = baseTablesByName.values().iterator();
                while (tablesIter.hasNext())
                {
                    ((TableImpl) tablesIter.next()).drop(getCurrentConnection());
                }
            }
            catch (Exception e)
            {
                success = false;
                String errorMsg = LOCALISER.msg("050047", e);
                NucleusLogger.DATASTORE_SCHEMA.error(errorMsg);
                throw new NucleusUserException(errorMsg, e);
            }
            if (!success)
            {
                throw new NucleusException("DeleteTables operation failed");
            }
        }
    }

    /* (non-Javadoc)
     * @see org.datanucleus.store.rdbms.AbstractSchemaTransaction#toString()
     */
    public String toString()
    {
        return LOCALISER.msg("050045", rdbmsMgr.getCatalogName(), rdbmsMgr.getSchemaName());
    }
}