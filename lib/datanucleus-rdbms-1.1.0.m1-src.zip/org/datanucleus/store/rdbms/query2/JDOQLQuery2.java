/**********************************************************************
Copyright (c) 2008 Andy Jefferson and others. All rights reserved.
Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.

Contributors:
    ...
**********************************************************************/
package org.datanucleus.store.rdbms.query2;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.datanucleus.ClassLoaderResolver;
import org.datanucleus.ManagedConnection;
import org.datanucleus.ManagedConnectionResourceListener;
import org.datanucleus.ObjectManager;
import org.datanucleus.exceptions.NucleusException;
import org.datanucleus.metadata.AbstractClassMetaData;
import org.datanucleus.query.compiler.QueryCompilation;
import org.datanucleus.query.evaluator.JDOQLEvaluator;
import org.datanucleus.query.evaluator.JavaQueryEvaluator;
import org.datanucleus.store.mapped.DatastoreClass;
import org.datanucleus.store.mapped.StatementMappingForClass;
import org.datanucleus.store.query.AbstractJDOQLQuery;
import org.datanucleus.store.query.Query;
import org.datanucleus.store.query.QueryResult;
import org.datanucleus.store.query.ResultObjectFactory;
import org.datanucleus.store.rdbms.RDBMSManager;
import org.datanucleus.store.rdbms.SQLController;
import org.datanucleus.store.rdbms.query.AbstractRDBMSQueryResult;
import org.datanucleus.store.rdbms.query.ForwardQueryResult;
import org.datanucleus.store.rdbms.query.RDBMSQueryUtils;
import org.datanucleus.store.rdbms.query.ScrollableQueryResult;
import org.datanucleus.store.rdbms.sql.DiscriminatorStatementGenerator;
import org.datanucleus.store.rdbms.sql.SQLStatement;
import org.datanucleus.store.rdbms.sql.SQLStatementHelper;
import org.datanucleus.store.rdbms.sql.SQLText;
import org.datanucleus.store.rdbms.sql.StatementGenerator;
import org.datanucleus.store.rdbms.sql.UnionStatementGenerator;
import org.datanucleus.util.NucleusLogger;

/**
 * RDBMS representation of a JDOQL query for use by DataNucleus.
 * The query can be specified via method calls, or via a single-string form.
 * This implementation uses the generic query compilation in "org.datanucleus.query"
 * and will ultimately replace the version in "JDOQLQuery".
 */
public class JDOQLQuery2 extends AbstractJDOQLQuery
{
    /**
     * Constructs a new query instance that uses the given object manager.
     * @param om The ObjectManager
     */
    public JDOQLQuery2(ObjectManager om)
    {
        this(om, (JDOQLQuery2) null);
    }

    /**
     * Constructs a new query instance having the same criteria as the given query.
     * @param om The ObjectManager
     * @param q The query from which to copy criteria.
     */
    public JDOQLQuery2(ObjectManager om, JDOQLQuery2 q)
    {
        super(om, q);
    }

    /**
     * Constructor for a JDOQL query where the query is specified using the "Single-String" format.
     * @param om The ObjectManager
     * @param query The single-string query form
     */
    public JDOQLQuery2(ObjectManager om, String query)
    {
        super(om, query);
    }

    protected Object performExecute(Map parameters)
    {
        ClassLoaderResolver clr = om.getClassLoaderResolver();

        if (candidateCollection != null && candidateCollection.isEmpty())
        {
            return Collections.EMPTY_LIST;
        }

        Object results = null;

        boolean inMemory = evaluateInMemory();
        ManagedConnection mconn = om.getStoreManager().getConnection(om);
        try
        {
            // Execute the query
            long startTime = System.currentTimeMillis();
            if (NucleusLogger.QUERY.isDebugEnabled())
            {
                NucleusLogger.QUERY.debug(LOCALISER.msg("021046", "JDOQL", getSingleStringQuery(), null));
            }

            RDBMSManager storeMgr = (RDBMSManager)getStoreManager();
            DatastoreClass candidateTable = storeMgr.getDatastoreClass(candidateClass.getName(), clr);
            AbstractClassMetaData acmd = getObjectManager().getMetaDataManager().getMetaDataForClass(candidateClass, clr);
            if (candidateCollection != null)
            {
                List candidates = new ArrayList(candidateCollection);
                JavaQueryEvaluator resultMapper = new JDOQLEvaluator(this, candidates, compilation, clr);
                results = resultMapper.execute(inMemory, inMemory, inMemory, inMemory, inMemory);
            }
            else if (candidateExtent != null)
            {
                // TODO Allow lazy resolution of the candidates rather than direct copying
                List candidates = new ArrayList();
                Iterator iter = candidateExtent.iterator();
                while (iter.hasNext())
                {
                    candidates.add(iter.next());
                }
                JavaQueryEvaluator resultMapper = new JDOQLEvaluator(this, candidates, compilation, clr);
                results = resultMapper.execute(inMemory, inMemory, inMemory, inMemory, inMemory);
            }
            else
            {
                StatementMappingForClass mappingDefinition = new StatementMappingForClass(null);
                SQLStatement stmt = getNativeQueryForCompiledQuery(compilation, parameters,
                    mappingDefinition, candidateTable, acmd);
                boolean useUpdateLock = RDBMSQueryUtils.useUpdateLockForQuery(this);
                stmt.addExtension("lock-for-update", new Boolean(useUpdateLock));
                SQLText sqlText = null;
                if (type == Query.SELECT)
                {
                    sqlText = stmt.getSelectStatement();
                }
                else if (type == Query.BULK_UPDATE)
                {
                    throw new NucleusException("DataNucleus doesnt currently support bulk update statements");
                }
                else if (type == Query.BULK_DELETE)
                {
                    // TODO Distinguish between update and delete
                    throw new NucleusException("DataNucleus doesnt currently support bulk delete statements");
                }

                try
                {
                    // TODO Use a queryResult rather than an ArrayList so we load when required
                    SQLController sqlControl = storeMgr.getSQLController();
                    String stmtText = sqlText.toSQL(0);
                    PreparedStatement ps =
                        RDBMSQueryUtils.getPreparedStatementForQuery(mconn, stmtText, this);
                    try
                    {
                        // Apply timeouts, result set constraints etc to the PreparedStatement
                        RDBMSQueryUtils.prepareStatementForExecution(ps, this);

                        if (type == Query.SELECT)
                        {
                            // SELECT query
                            ResultSet rs =
                                sqlControl.executeStatementQuery(mconn, sqlText.toString(), ps);
                            QueryResult qr = null;
                            try
                            {
                                ResultObjectFactory rof =
                                    storeMgr.newResultObjectFactory(candidateTable, acmd, mappingDefinition, 
                                        useUpdateLock, false, false, getFetchPlan(), candidateClass);

                                if (evaluateInMemory())
                                {
                                    // Just instantiate the candidates for later in-memory processing
                                    List candidates = new ArrayList();
                                    while (rs.next())
                                    {
                                        candidates.add(rof.getObject(om, rs));
                                    }

                                    // Perform in-memory filter/result/order etc
                                    JavaQueryEvaluator resultMapper = 
                                        new JDOQLEvaluator(this, candidates, compilation, clr);
                                    results = resultMapper.execute(true, true, true, true, true);
                                }
                                else
                                {
                                    // Check the type of result set needed
                                    String resultSetType = RDBMSQueryUtils.getResultSetTypeForQuery(this);
                                    if (resultSetType.equals("scroll-insensitive") ||
                                        resultSetType.equals("scroll-sensitive"))
                                    {
                                        qr = new ScrollableQueryResult(this, rof, rs, 
                                            getResultDistinct() ? null : candidateCollection);
                                    }
                                    else
                                    {
                                        qr = new ForwardQueryResult(this, rof, rs, 
                                            getResultDistinct() ? null : candidateCollection);
                                    }

                                    final QueryResult qr1 = qr;
                                    final ManagedConnection mconn1 = mconn;
                                    ManagedConnectionResourceListener listener = new ManagedConnectionResourceListener()
                                    {
                                        public void managedConnectionPreClose(){}
                                        public void managedConnectionPostClose(){}
                                        public void managedConnectionFlushed()
                                        {
                                            // Disconnect the query from this ManagedConnection (read in unread rows etc)
                                            qr1.disconnect();
                                        }
                                        public void resourcePostClose()
                                        {
                                            mconn1.removeListener(this);
                                        }
                                    };
                                    mconn.addListener(listener);
                                    ((AbstractRDBMSQueryResult)qr).addConnectionListener(listener);
                                }
                            }
                            finally
                            {
                                if (qr == null)
                                {
                                    rs.close();
                                }
                            }
                        }
                    }
                    catch (SQLException sqle)
                    {
                        throw new NucleusException("Exception thrown in query", sqle);
                    }
                }
                catch (SQLException sqle)
                {
                    throw new NucleusException("Exception thrown in query", sqle);
                }
            }

            if (NucleusLogger.QUERY.isDebugEnabled())
            {
                NucleusLogger.QUERY.debug(LOCALISER.msg("021074", "JDOQL", 
                    "" + (System.currentTimeMillis() - startTime)));
            }

            return results;
        }
        finally
        {
            mconn.release();
        }
    }

    /**
     * Method to return a (native) query statement for the compiled query.
     * @param compilation Compiled query
     * @param parameters Input parameters
     * @param mappingDefinition Mappings for the processing the results (populated during this call)
     * @return The native (SQL) query statement for this RDBMS datastore
     */
    private SQLStatement getNativeQueryForCompiledQuery(QueryCompilation compilation, Map parameters,
            StatementMappingForClass mappingDefinition, DatastoreClass candidateTable,
            AbstractClassMetaData candidateCmd)
    {
        SQLStatement stmt = null;
        RDBMSManager storeMgr = (RDBMSManager)getStoreManager();
        if (candidateCollection != null)
        {
            // TODO Create SQLStatement and restrict to just the candidate instances
        }
        else
        {
            // TODO Make use of Extent to create QueryStatement
            StatementGenerator stmtGen = null;
            if (candidateTable.getDiscriminatorMapping(false) != null)
            {
                stmtGen = new DiscriminatorStatementGenerator(storeMgr, candidateClass, subclasses, null);
            }
            else
            {
                stmtGen = new UnionStatementGenerator(storeMgr, candidateClass, subclasses, null);
            }
            stmt = stmtGen.getStatement();
        }

        // Select any fields required
        boolean inMemory = evaluateInMemory();
        if (inMemory)
        {
            // Select fetch-plan fields of candidate class
            SQLStatementHelper.selectFetchPlanOfCandidateInStatement(stmt, mappingDefinition, getFetchPlan(), 
                candidateCmd);
            NucleusLogger.JDO.debug(">> MappingDefinition=" + mappingDefinition);
        }
        else
        {
            // Update the SQLStatement with filter, ordering, result, range etc
            QueryToSQLMapper sqlMapper = new QueryToSQLMapper(stmt, compilation, parameters);
            sqlMapper.compile();
            // TODO Do any select of fields - depends on result
        }

        return stmt;
    }
}