/**********************************************************************
Copyright (c) 2006 Erik Bengtson and others. All rights reserved.
Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.

Contributors:
2006 Andy Jefferson - migrated from Java5 plugin to Core
2008 Andy Jefferson - refactored compiler to be stand-alone. Major changes
    ...
**********************************************************************/
package org.datanucleus.store.rdbms.query;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import org.datanucleus.ObjectManager;
import org.datanucleus.exceptions.NucleusException;
import org.datanucleus.exceptions.NucleusUserException;
import org.datanucleus.query.JPQLSingleStringParser;
import org.datanucleus.store.Extent;
import org.datanucleus.store.mapped.expression.QueryExpression;
import org.datanucleus.store.mapped.expression.Queryable;
import org.datanucleus.store.query.AbstractJPQLQuery;
import org.datanucleus.store.query.NoQueryResultsException;
import org.datanucleus.store.query.Query;
import org.datanucleus.store.query.QueryCompiler;
import org.datanucleus.store.query.QueryNotUniqueException;
import org.datanucleus.store.query.QueryResult;
import org.datanucleus.store.query.ResultObjectFactory;
import org.datanucleus.util.NucleusLogger;

/**
 * RDBMS representation of a JPQL query for use by DataNucleus.
 * The query can be specified via method calls, or via a single-string form.
 * @see Query
 */
public class JPQLQuery extends AbstractJPQLQuery
{
    /** The Query Statement. */
    protected transient QueryExpression queryStmt = null;

    /** Candidates for this query. */
    protected transient Queryable candidates = null;

    protected transient String candidateAlias = "this";

    /** Factory for obtaining the results from the query result set. */
    protected transient ResultObjectFactory rof = null;

    /** State variable for the compilation state */
    protected transient boolean isCompiled = false;

    /** Result metadata (extension, allowing access to more info about results). **/
    protected transient QueryResultsMetaData resultMetaData;

    /**
     * Constructs a new query instance that uses the given persistence manager.
     * @param om the associated ObjectManager for this query.
     */
    public JPQLQuery(ObjectManager om)
    {
        this(om, (JPQLQuery)null);
    }

    /**
     * Constructs a new query instance having the same criteria as the given query.
     * @param om The ObjectManager
     * @param q The query from which to copy criteria.
     */
    public JPQLQuery(ObjectManager om, JPQLQuery q)
    {
        super(om, q);
    }

    /**
     * Constructor for a JPQL query where the query is specified using the "Single-String" format.
     * @param om The ObjectManager
     * @param query The query string
     */
    public JPQLQuery(ObjectManager om, String query)
    {
        super(om);

        new JPQLSingleStringParser(this, query).parse();
    }

    /**
     * Accessor for the candidates for the query.
     * This is only valid after compiling the query.
     * @return Candidates for the query
     */
    public Queryable getCandidates()
    {
        return candidates;
    }

    /**
     * Equality operator for JPQL.
     * @see java.lang.Object#equals(java.lang.Object)
     */
    public boolean equals(Object obj)
    {
        if (obj == this)
        {
            return true;
        }
    
        if (!(obj instanceof JPQLQuery) || !super.equals(obj))
        {
            return false;
        }
    
        return true;
    }

    /**
     * Method to discard our current compiled query due to changes.
     * @see org.datanucleus.store.query.Query#discardCompiled()
     */
    protected void discardCompiled()
    {
        isCompiled = false;
        rof = null;
        queryStmt = null;
        super.discardCompiled();
    }

    /**
     * Method to return if the query is compiled.
     * @return Whether it is compiled
     */
    protected boolean isCompiled()
    {
        return isCompiled;
    }

    /**
     * Verify the elements of the query and provide a hint to the query to prepare and optimize an execution plan.
     */
    protected void compileInternal(boolean forExecute, Map parameterValues)
    {
        if (isCompiled)
        {
            return;
        }

        try
        {
            if (forExecute)
            {
                // Compile for execution
                if (NucleusLogger.QUERY.isDebugEnabled())
                {
                    NucleusLogger.QUERY.debug(LOCALISER.msg("021044", "JPQL", getSingleStringQuery(), "execution"));
                }
                JPQLQueryCompiler c = new JPQLQueryCompiler(this, getParsedImports(), parameterValues);
                queryStmt = (QueryExpression)c.compile(QueryCompiler.COMPILE_EXECUTION);
                if (resultDistinct)
                {
                    queryStmt.setDistinctResults(true);
                }
                resultMetaData = c.getResultMetaData();
                candidateClass = c.getCandidateClass();
                candidateAlias = c.getCandidateAlias();
                candidates = c.getCandidates();
                resultClass = c.getResultClass();
                fromInclNo = c.getRangeFromIncl();
                toExclNo = c.getRangeToExcl();
                c.close();
                c = null;
            }
            else
            {
                // Use the compiler to perform a "pre-compile" check to validate the expressions
                if (NucleusLogger.QUERY.isDebugEnabled())
                {
                    NucleusLogger.QUERY.debug(LOCALISER.msg("021044", "JPQL", getSingleStringQuery(), "precompile"));
                }
                JPQLQueryCompiler c = new JPQLQueryCompiler(this, getParsedImports(), parameterValues);
                c.compile(QueryCompiler.COMPILE_SYNTAX);
                resultMetaData = c.getResultMetaData();
                candidateClass = c.getCandidateClass();
                candidateAlias = c.getCandidateAlias();
                candidates = c.getCandidates();
                resultClass = c.getResultClass();
                fromInclNo = c.getRangeFromIncl();
                toExclNo = c.getRangeToExcl();
                c.close();
                c = null;
            }

            isCompiled = true;
        }
        catch (NucleusException jpe)
        {
            // Compile failed
            discardCompiled();
            isCompiled = false;
            throw jpe;
        }
    }

    /**
     * Retrieve the metadata for the results.
     * @return the ResultSetMetaData
     */
    public QueryResultsMetaData getResultSetMetaData()
    {
        if (resultMetaData == null)
        {
            throw new NucleusUserException("You must compile the query before calling this method.");
        }
        return resultMetaData;
    }

    /**
     * Method to execute the actual query.
     * Discards any existing compilation forcing a recompile, and calls the superclass variant with the
     * passed explicit parameters plus any defined implicit parameters.
     * @param parameters Map of parameter values keyed by parameter name
     * @return Result
     * @throws NoQueryResultsException Thrown if no results were returned from the query.
     * @throws QueryNotUniqueException Thrown if multiple results, yet expected one
     */
    protected Object executeQuery(Map parameters)
    {
        discardCompiled();

        // Generate Map of previously defined implicit parameter plus any just input at execute()
        Map params = new HashMap();
        if (implicitParameters != null)
        {
            params.putAll(implicitParameters);
        }
        if (parameters != null)
        {
            params.putAll(parameters);
        }

        return super.executeQuery(params);
    }

    /**
     * Execute the query and return the filtered QueryResult.
     * @param executeParameters Map containing all of the parameters.
     * @return the results of the query - a QueryResult (if SELECT) or a Long (if BULK_UPDATE/BULK_DELETE)
     */
    protected Object performExecute(Map executeParameters)
    {
        if (candidates.isEmpty())
        {
            // if the candidates are empty, we don't have to go to the database
            // to find out that we have no elements to return
            return new ArrayList();
        }

        // Apply the Query FetchPlan to the query
        // Note : we could have added getFetchPlan() to Queryable, but this would affect *many* classes
        // so leaving like this for now
        if (candidates instanceof CollectionCandidates)
        {
            ((CollectionCandidates)candidates).getFetchPlan().setGroups(getFetchPlan().getGroups());
        }
        else if (candidates instanceof Extent)
        {
            ((Extent)candidates).getFetchPlan().setGroups(getFetchPlan().getGroups());
        }

        Boolean useFPVal = getBooleanExtensionProperty("datanucleus.query.useFetchPlan");
        boolean useFetchPlan = (useFPVal != null ? useFPVal.booleanValue() : true);
        if (type == BULK_UPDATE || type == BULK_DELETE)
        {
            // Don't want anything selecting apart from the PK fields
            useFetchPlan = false;
        }

        // Create a processor for extracting the objects from the ResultSet
        rof = candidates.newResultObjectFactory(queryStmt, getIgnoreCache(), resultClass, useFetchPlan);
        if (rof instanceof PersistentIDROF)
        {
            // Allow for the user specifying an Extent of a base class but restricting this query to a subclass
            ((PersistentIDROF)rof).setPersistentClass(candidateClass);
        }

        // Make sure the datastore is prepared for the query
        prepareDatastore();

        // Execute the query
        if (NucleusLogger.QUERY.isDebugEnabled())
        {
            NucleusLogger.QUERY.debug(LOCALISER.msg("021046", "JPQL", getSingleStringQuery()));
        }
        SQLEvaluator eval = new SQLEvaluator(this, rof, candidateCollection);
        // TODO Cater for BULK_UPDATE, BULK_DELETE where return is Long
        QueryResult qr = (QueryResult)eval.evaluate(queryStmt);
        queryResults.add(qr);

        return qr;
    }

    /**
     * Execute the query to delete persistent objects.
     * @param parameters the Map containing all of the parameters.
     * @return the number of deleted objects.
     */
    protected long performDeletePersistentAll(Map parameters)
    {
        // Discard compilation before deleting - will be recompiled in the superclass implementation
        discardCompiled();
        return super.performDeletePersistentAll(parameters);
    }
}