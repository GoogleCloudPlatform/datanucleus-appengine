/**********************************************************************
Copyright (c) 2005 Erik Bengtson and others. All rights reserved.
Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.

Contributors:
2005 Andy Jefferson - added support for bidirectional iterator
2008 Andy Jefferson - added resultCacheType. Removed optimistic restriction
2008 Marco Schulze - implemented toArray() and toArray(Object[])
    ...
**********************************************************************/
package org.datanucleus.store.rdbms.query;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.ListIterator;
import java.util.Map;
import java.util.NoSuchElementException;

import javax.jdo.JDODataStoreException;

import org.datanucleus.FetchPlan;
import org.datanucleus.exceptions.NucleusDataStoreException;
import org.datanucleus.exceptions.NucleusException;
import org.datanucleus.exceptions.NucleusUserException;
import org.datanucleus.store.mapped.expression.QueryExpression;
import org.datanucleus.store.query.AbstractQueryResultIterator;
import org.datanucleus.store.query.Query;
import org.datanucleus.store.query.QueryResult;
import org.datanucleus.store.query.ResultObjectFactory;
import org.datanucleus.store.rdbms.SQLWarnings;
import org.datanucleus.util.NucleusLogger;
import org.datanucleus.util.SoftValueMap;
import org.datanucleus.util.StringUtils;
import org.datanucleus.util.WeakValueMap;

/**
 * Lazy collection results from a Query with the ResultSet scrollable.
 * Supports the following query extensions :-
 * <ul>
 * <li><b>datanucleus.query.resultSizeMethod</b> The method used to find the size of the result set.</li>
 * <li><b>datanucleus.query.loadResultsAtCommit</b> Whether to load all results when the connection is closing.
 * Has no effect if caching is not used.</li>
 * <li><b>datanucleus.query.resultCacheType</b> Type of caching of result objects. 
 * Supports hard, weak, soft, none</li>
 * </ul>
 * If there is no transaction present, or if the FetchPlan is in "greedy" mode, and where caching is being used
 * will load all results at startup. Otherwise results are only loaded when accessed.
 *
 * @version $Revision: 1.10 $
 */
public final class ScrollableQueryResult extends AbstractRDBMSQueryResult
    implements QueryResult, java.io.Serializable
{
    /** Size of the ResultSet. */
    private int size = -1;

    /** Map of ResultSet object values, keyed by the list index ("0", "1", etc). */
    private Map resultsObjsByIndex = null;

    /** Whether to load any unread results at commit (when connection is closed). */
    private boolean loadResultsAtCommit = true; // Default to load

    /** Method for getting the size of the results. */
    private String resultSizeMethod = "last"; // Default to moving to last row

    /**
     * Constructor of the result from a Query. 
     * @param qs The Query Statement
     * @param query The Query
     * @param rof The factory to retrieve results from
     * @param rs The ResultSet from the Query Statement
     * @param candidates the Candidates collection. Pass this argument only when distinct = false
     */
    public ScrollableQueryResult(QueryExpression qs, 
                                  Query query,
                                  ResultObjectFactory rof,
                                  ResultSet rs,
                                  Collection candidates)
    {
        super(qs, query, rof, rs);

        if (candidates != null)
        {
            //TODO support this feature
            throw new NucleusException("Unsupported Feature: Candidate Collection is only allowed using ForwardQueryResults").setFatal();
        }

        // Process any supported extensions
        String ext = (String)query.getExtension("datanucleus.query.resultSizeMethod");
        if (ext != null)
        {
            resultSizeMethod = ext;
        }
        ext = (String)query.getExtension("datanucleus.query.loadResultsAtCommit");
        if (ext != null)
        {
            loadResultsAtCommit = new Boolean(ext).booleanValue();
        }

        ext = (String)query.getExtension("datanucleus.query.resultCacheType");
        if (ext != null)
        {
            if (ext.equalsIgnoreCase("soft"))
            {
                resultsObjsByIndex = new SoftValueMap();
            }
            else if (ext.equalsIgnoreCase("weak"))
            {
                resultsObjsByIndex = new WeakValueMap();
            }
            else if (ext.equalsIgnoreCase("hard"))
            {
                resultsObjsByIndex = new HashMap();
            }
            else if (ext.equalsIgnoreCase("none"))
            {
                resultsObjsByIndex = null;
            }
            else
            {
                resultsObjsByIndex = new WeakValueMap();
            }
        }
        else
        {
            resultsObjsByIndex = new WeakValueMap();
        }

        if (resultsObjsByIndex != null)
        {
            // Caching results so load up any result objects needed right now
            int fetchSize = query.getFetchPlan().getFetchSize();
            if (!query.getObjectManager().getTransaction().isActive() || fetchSize == FetchPlan.FETCH_SIZE_GREEDY)
            {
                // No transaction or in "greedy" mode so load all results now
                boolean hasMoreResults = true;
                int index = 0;
                while (hasMoreResults)
                {
                    try
                    {
                        boolean rowExists = rs.absolute(index+1);
                        if (!rowExists)
                        {
                            hasMoreResults = false;
                            size = index; // We know the size now so store for later use
                        }
                        else
                        {
                            getObjectForIndex(index);
                            index++;
                        }
                    }
                    catch (SQLException sqle)
                    {

                    }
                }
            }
            else if (fetchSize > 0)
            {
                // Load up the first "fetchSize" objects now
                for (int i=0;i<fetchSize;i++)
                {
                    getObjectForIndex(i);
                }
            }
        }
    }

    /**
     * Accessor for the result object at an index.
     * If the object has already been processed will return that object,
     * otherwise will retrieve the object using the factory.
     * @param index The list index position
     * @return The result object
     */
    protected Object getObjectForIndex(int index)
    {
        if (resultsObjsByIndex != null)
        {
            // Caching objects, so check the cache for this index
            Object obj = resultsObjsByIndex.get("" + index);
            if (obj != null)
            {
                // Already retrieved so return it
                return obj;
            }
        }

        try
        {
            // ResultSet is numbered 1, 2, ... N
            // List is indexed 0, 1, 2, ... N-1
            rs.absolute(index+1);
            Object obj = rof.getObject(query.getObjectManager(), rs);
            SQLWarnings.log(rs);

            if (resultsObjsByIndex != null)
            {
                // Put it in our cache, keyed by the list index
                resultsObjsByIndex.put("" + index, obj);
            }

            return obj;
        }
        catch (SQLException sqe)
        {
            if (query.getObjectManager().getOMFContext().getApi().equalsIgnoreCase("JDO"))
            {
                throw new JDODataStoreException(LOCALISER.msg("052601", sqe));
            }
            else
            {
                throw new NucleusDataStoreException(LOCALISER.msg("052601", sqe));
            }
        }
    }

    /**
     * Method to close the results, making the results unusable thereafter.
     */
    public synchronized void close()
    {
        if (resultsObjsByIndex != null)
        {
            resultsObjsByIndex.clear();
        }

        super.close();
    }

    /**
     * Inform the query result that the connection is being closed so perform
     * any operations now, or rest in peace.
     */
    protected void closingConnection()
    {
        // Make sure all rows are loaded.
        if (loadResultsAtCommit && isOpen())
        {
            // Query connection closing message
            NucleusLogger.QUERY.info(LOCALISER.msg("052606", query.toString()));

            for (int i=0;i<size();i++)
            {
                getObjectForIndex(i);
            }
        }
    }

    // ------------------------- Implementation of List methods ----------------------

    /**
     * Accessor for an iterator for the results.
     * @return The iterator
     */
    public Iterator iterator()
    {
        return new QueryResultIterator();
    }

    /**
     * Accessor for an iterator for the results.
     * @return The iterator
     */
    public ListIterator listIterator()
    {
        return new QueryResultIterator();
    }

    /**
     * An Iterator results of a pm.query.execute().iterator()
     */
    private class QueryResultIterator extends AbstractQueryResultIterator
    {
        private int iterRowNum = 0; // The index of the next object

        public boolean hasNext()
        {
            synchronized (ScrollableQueryResult.this)
            {
                if (!isOpen())
                {
                    // Spec 14.6.7 Calling hasNext() on closed Query will return false
                    return false;
                }

                // When we aren't at size()-1 we have at least one more element
                return (iterRowNum <= (size() - 1));
            }
        }

        public boolean hasPrevious()
        {
            synchronized (ScrollableQueryResult.this)
            {
                if (!isOpen())
                {
                    // Spec 14.6.7 Calling hasPrevious() on closed Query will return false
                    return false;
                }

                // A List has indices starting at 0 so when we have > 0 we have a previous
                return (iterRowNum > 0);
            }
        }

        public Object next()
        {
            synchronized (ScrollableQueryResult.this)
            {
                if (!isOpen())
                {
                    // Spec 14.6.7 Calling next() on closed Query will throw NoSuchElementException
                    throw new NoSuchElementException(LOCALISER.msg("052600"));
                }

                if (!hasNext())
                {
                    throw new NoSuchElementException("No next element");
                }
                Object obj = getObjectForIndex(iterRowNum);
                iterRowNum++;

                return obj;
            }
        }

        public int nextIndex()
        {
            if (hasNext())
            {
                return iterRowNum;
            }
            return size();
        }

        public Object previous()
        {
            synchronized (ScrollableQueryResult.this)
            {
                if (!isOpen())
                {
                    // Spec 14.6.7 Calling previous() on closed Query will throw NoSuchElementException
                    throw new NoSuchElementException(LOCALISER.msg("052600"));
                }

                if (!hasPrevious())
                {
                    throw new NoSuchElementException("No previous element");
                }

                iterRowNum--;
                return getObjectForIndex(iterRowNum);
            }
        }

        public int previousIndex()
        {
            if (iterRowNum == 0)
            {
                return -1;
            }
            return iterRowNum-1;
        }
    }

    /**
     * Equality operator for QueryResults.
     * Overrides the AbstractList implementation since that uses 
     * size() and iterator() and that would cause problems when closed.
     * @param o The object to compare against
     * @return Whether they are equal
     */
    public boolean equals(Object o)
    {
        if (o == null || !(o instanceof ScrollableQueryResult))
        {
            return false;
        }

        ScrollableQueryResult other = (ScrollableQueryResult)o;
        if (qs != null)
        {
            return other.qs == qs;
        }
        else if (query != null)
        {
            return other.query == query;
        }
        return StringUtils.toJVMIDString(other).equals(StringUtils.toJVMIDString(this));
    }

    /**
     * Method to retrieve a particular element from the list.
     * @param index The index of the element
     * @return The element at index
     */
    public synchronized Object get(int index)
    {
        assertIsOpen();
        return getObjectForIndex(index);
    }

    /**
     * Method to return the size of the result set.
     * @return The size of the result set.
     */
    public synchronized int size()
    {
        assertIsOpen();
        if (size < 0)
        {
            if (resultSizeMethod.equalsIgnoreCase("LAST"))
            {
                try
                {
                    boolean hasLast = rs.last();
                    if (!hasLast)
                    {
                        // No results in ResultSet
                        size = 0;
                    }
                    else
                    {
                        // ResultSet has results so return the row number as the list size
                        size = rs.getRow();
                    }
                }
                catch (SQLException sqle)
                {
                    throw new JDODataStoreException(LOCALISER.msg("052601", sqle));
                }
            }
            else if (resultSizeMethod.equalsIgnoreCase("COUNT"))
            {
                if (query instanceof JDOQLQuery)
                {
                    // Do count(this) query
                    Query countQuery = new JDOQLQuery(query.getObjectManager(), (JDOQLQuery)query);
                    countQuery.setResult("count(this)");
                    Map queryParams = query.getInputParameters();
                    long count;
                    if (queryParams != null)
                    {
                        count = ((Long)countQuery.executeWithMap(queryParams)).longValue();
                    }
                    else
                    {
                        count = ((Long)countQuery.execute()).longValue();
                    }
                    countQuery.closeAll();
                    size = (int)count;
                }
                else if (query instanceof JPQLQuery)
                {
                    // Do count() query
                    Query countQuery = new JPQLQuery(query.getObjectManager(), (JPQLQuery)query);
                    countQuery.setResult("count(" + ((JPQLQuery)query).candidateAlias + ")");
                    Map queryParams = query.getInputParameters();
                    long count;
                    if (queryParams != null)
                    {
                        count = ((Long)countQuery.executeWithMap(queryParams)).longValue();
                    }
                    else
                    {
                        count = ((Long)countQuery.execute()).longValue();
                    }
                    countQuery.closeAll();
                    size = (int)count;
                }
                else
                {
                    throw new NucleusUserException("datanucleus.query.resultSizeMethod is only valid" +
                            " for use with JDOQL or JPQL currently");
                }
            }
            else
            {
                // Support other ways of determining the size of the result set ?
                throw new NucleusUserException("DataNucleus doesnt currently support any method \"" + 
                    resultSizeMethod + "\" for determining the size of the query results");
            }
        }
        return size;
    }

    public Object[] toArray()
    {
        return toArrayInternal(null);
    }

    public Object[] toArray(Object[] a)
    {
        if (a == null) // ArrayList.toArray(Object[]) does not allow null arguments, so we don't do this either (according to javadoc, a NPE is thrown).
            throw new NullPointerException("null argument is illegal!");

        return toArrayInternal(a);
    }

    private Object[] toArrayInternal(Object[] a)
    {
        Object[] result = a;
        ArrayList resultList = null;

        int size = -1;
        try
        {
            size = size();
        }
        catch (Exception x)
        {
            // silently (except for debugging) ignore and work with unknown size
            size = -1;
            if (NucleusLogger.QUERY.isDebugEnabled())
            {
                NucleusLogger.QUERY.debug("toArray: Could not determine size.", x);
            }
        }

        if (size >= 0)
        {
            if (result == null || result.length < size)
            {
                // if the size is known and exceeds the array length, we use a list
                // instead of populating the array directly
                result = null;
                resultList = new ArrayList(size);
            }
        }

        Iterator iterator = null;

        // trying to use the existing result array before creating sth. new
        if (result != null)
        {
            iterator = this.iterator();
            int idx = -1;
            while (iterator.hasNext())
            {
                ++idx;
                if (idx < result.length)
                {
                    result[idx] = iterator.next();
                }
                else
                { // exceeding array size => switch to resultList
                    int capacity = (result.length * 3) / 2 + 1;

                    if (capacity < result.length) // this could only happen, if the above calculation exceeds the integer range - but safer is better
                        capacity = result.length;

                    resultList = new ArrayList(capacity);
                    for (int i = 0; i < result.length; i++)
                    {
                        resultList.add(result[i]);
                    }
                    result = null;
                    break;
                }
            }
            ++idx;
            if (result != null && idx < result.length)
            { // it's a convention that the first element in the array after the real data is null (ArrayList.toArray(Object[]) does the same)
                result[idx] = null;
            }
        }

        // if the result is null, it means that using the existing array was not possible or there was none passed.
        if (result == null)
        {
            if (resultList == null)
                resultList = new ArrayList();

            if (iterator == null) // the iterator might already exist (if we tried to use the result array and saw that it is not long enough)
                iterator = this.iterator();

            while (iterator.hasNext())
            {
                resultList.add(iterator.next());
            }

            if (a == null)
                result = resultList.toArray();
            else
                result = resultList.toArray(a);
        }

        return result;
    }
}