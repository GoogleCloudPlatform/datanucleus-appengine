/**********************************************************************
Copyright (c) 2007 Andy Jefferson and others. All rights reserved.
Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.

Contributors:
    ...
**********************************************************************/
package org.datanucleus.store.rdbms.query;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Iterator;

import org.datanucleus.ManagedConnection;
import org.datanucleus.OMFContext;
import org.datanucleus.ObjectManager;
import org.datanucleus.PersistenceConfiguration;
import org.datanucleus.Transaction;
import org.datanucleus.exceptions.NucleusUserException;
import org.datanucleus.metadata.AbstractClassMetaData;
import org.datanucleus.metadata.DiscriminatorMetaData;
import org.datanucleus.metadata.DiscriminatorStrategy;
import org.datanucleus.query.QueryUtils;
import org.datanucleus.store.mapped.DatastoreClass;
import org.datanucleus.store.mapped.MappedStoreManager;
import org.datanucleus.store.mapped.expression.MetaDataStringLiteral;
import org.datanucleus.store.mapped.expression.StatementText;
import org.datanucleus.store.mapped.mapping.JavaTypeMapping;
import org.datanucleus.store.query.Query;
import org.datanucleus.store.rdbms.RDBMSManager;
import org.datanucleus.store.rdbms.SQLController;
import org.datanucleus.util.TypeConversionHelper;

/**
 * Utilities for use in queries specific to RDBMS.
 */
public class RDBMSQueryUtils extends QueryUtils
{
    /**
     * Convenience method that takes a result set that contains a discriminator column and returns
     * the class name that it represents.
     * @param table Primary table of the select (so we can identify the primary class and discriminator range)
     * @param rs The result set
     * @param om Object Manager
     * @return The class name for the object represented in the current row
     */
    public static String getClassNameFromDiscriminatorResultSetRow(DatastoreClass table, ResultSet rs, ObjectManager om)
    {
        String rowClassName = null;

        JavaTypeMapping discriminatorMapping = table.getDiscriminatorMapping(true);
        DiscriminatorMetaData dismd = table.getDiscriminatorMetaData();
        if (discriminatorMapping != null && dismd.getStrategy() != DiscriminatorStrategy.NONE)
        {
            try
            {
                String discriminatorColName = discriminatorMapping.getDataStoreMapping(0).getDatastoreField().getIdentifier().getIdentifier();
                //TODO use discriminatorMapping.getObject()
                String discriminatorValue = rs.getString(discriminatorColName);
                if (dismd.getStrategy() == DiscriminatorStrategy.CLASS_NAME)
                {
                    rowClassName = discriminatorValue;
                }
                else if (dismd.getStrategy() == DiscriminatorStrategy.VALUE_MAP)
                {
                    // Check the main class type for the table
                    String className = table.getType();
                    if (dismd.getValue().equals(discriminatorValue))
                    {
                        rowClassName = className;
                    }
                    else
                    {
                        // Go through all possible subclasses to find one with this value
                        Iterator iterator = om.getStoreManager().getSubClassesForClass(table.getType(), true, om.getClassLoaderResolver()).iterator();
                        while (iterator.hasNext())
                        {
                            className = (String)iterator.next();
                            AbstractClassMetaData classCmd = om.getMetaDataManager().getMetaDataForClass(className, om.getClassLoaderResolver());
                            if (discriminatorValue.equals(classCmd.getInheritanceMetaData().getDiscriminatorMetaData().getValue()))
                            {
                                rowClassName = className;
                                break;
                            }
                        }
                    }
                }
            }
            catch (Exception e)
            {
                // Do nothing
            }
        }
        return rowClassName;
    }

    /**
     * Convenience method taking a result set that contains a NUCMETADATA column and returns the class name.
     * @param rs The result set
     * @return The class name for the object represented in the current row
     */
    public static String getClassNameFromMetaDataResultSetRow(ResultSet rs)
    {
        try
        {
            return rs.getString(MetaDataStringLiteral.QUERY_META_DATA).trim();
        }
        catch (SQLException sqle)
        {
            return null;
        }
    }

    /**
     * Accessor for the result set type for the specified query.
     * Uses the persistence property "datanucleus.rdbms.query.resultSetType" and allows it to be
     * overridden by the query extension of the same name.
     * Checks both the PMF, and also the query extensions.
     * @param query The query
     * @return The result set type string
     */
    public static String getResultSetTypeForQuery(Query query)
    {
        String propName = "datanucleus.rdbms.query.resultSetType";
        String rsTypeString = 
            query.getObjectManager().getOMFContext().getPersistenceConfiguration().getStringProperty(propName);
        Object rsTypeExt = query.getExtension(propName);
        if (rsTypeExt != null)
        {
            rsTypeString = (String)rsTypeExt;
        }
        return rsTypeString;
    }

    /**
     * Accessor for the result set concurrency for the specified query.
     * Uses the persistence property "datanucleus.rdbms.query.resultSetConcurrency" and allows it to be
     * overridden by the query extension of the same name.
     * Checks both the PMF, and also the query extensions.
     * @param query The query
     * @return The result set concurrency string
     */
    public static String getResultSetConcurrencyForQuery(Query query)
    {
        String propName = "datanucleus.rdbms.query.resultSetConcurrency";
        String rsConcurrencyString = 
            query.getObjectManager().getOMFContext().getPersistenceConfiguration().getStringProperty(propName);
        Object rsConcurrencyExt = query.getExtension(propName);
        if (rsConcurrencyExt != null)
        {
            rsConcurrencyString = (String)rsConcurrencyExt;
        }
        return rsConcurrencyString;
    }

    /**
     * Convenience method to return if the specified query should use an "UPDATE" lock on
     * the objects returned. 
     * Uses the transaction property {Transaction.LOCK_FOR_UPDATE_OPTION} and allows it to be 
     * overridden by the query extension "datanucleus.rdbms.query.useUpdateLock".
     * @param query The query
     * @return Whether to use an "UPDATE" lock
     */
    public static boolean useUpdateLockForQuery(Query query)
    {
        boolean useUpdateLock =
            ((Boolean)query.getObjectManager().getTransaction().getOptions().get(Transaction.LOCK_FOR_UPDATE_OPTION)).booleanValue();
        Object useUpdateLockExt = query.getExtension("datanucleus.rdbms.query.useUpdateLock");
        if (useUpdateLockExt != null)
        {
            useUpdateLock = Boolean.valueOf((String)useUpdateLockExt).booleanValue();
        }

        return useUpdateLock;
    }

    /**
     * Method to create a PreparedStatement for use with the query.
     * @param conn the Connection
     * @param queryStmt The statement text for the query
     * @param query The query
     * @return the PreparedStatement
     * @throws SQLException Thrown if an error occurs creating the statement
     */
    public static PreparedStatement getPreparedStatementForQuery(ManagedConnection conn, String queryStmt, 
            Query query)
    throws SQLException
    {
        ObjectManager om = query.getObjectManager();

        // Apply any non-standard result set definition if required (either from the PMF, or via query extensions)
        String rsTypeString = RDBMSQueryUtils.getResultSetTypeForQuery(query);
        if (rsTypeString != null &&
            (!rsTypeString.equals("scroll-sensitive") && !rsTypeString.equals("forward-only") &&
             !rsTypeString.equals("scroll-insensitive")))
        {
            // TODO Localise this
            throw new NucleusUserException(
                "Query extension 'datanucleus.rdbms.query.resultSetType' has valid values of " +
                "scroll-sensitive,scroll-insensitive,forward-only only.");
        }
        String rsConcurrencyString = RDBMSQueryUtils.getResultSetConcurrencyForQuery(query);
        if (rsConcurrencyString != null &&
            (!rsConcurrencyString.equals("read-only") && !rsConcurrencyString.equals("updateable")))
        {
            // TODO Localise this
            throw new NucleusUserException(
                "Query extension 'datanucleus.rdbms.query.resultSetConcurrency' has valid values of " +
                "read-only,updateable only.");
        }

        SQLController sqlControl = ((RDBMSManager)om.getStoreManager()).getSQLController();
        PreparedStatement ps = sqlControl.getStatementForQuery(conn, queryStmt, rsTypeString, rsConcurrencyString);

        return ps;
    }

    /**
     * Method to create a PreparedStatement for use with the query.
     * @param conn the Connection
     * @param stmtText The statement text
     * @param query The query
     * @return the PreparedStatement
     * @throws SQLException Thrown if an error occurs creating the statement
     */
    public static PreparedStatement getPreparedStatementForQuery(ManagedConnection conn, StatementText stmtText, 
            Query query)
    throws SQLException
    {
        ObjectManager om = query.getObjectManager();

        // Apply any non-standard result set definition if required (either from the PMF, or via query extensions)
        String rsTypeString = RDBMSQueryUtils.getResultSetTypeForQuery(query);
        if (rsTypeString != null &&
            (!rsTypeString.equals("scroll-sensitive") && !rsTypeString.equals("forward-only") &&
             !rsTypeString.equals("scroll-insensitive")))
        {
            // TODO Localise this
            throw new NucleusUserException(
                "Query extension 'datanucleus.rdbms.query.resultSetType' has valid values of " +
                "scroll-sensitive,scroll-insensitive,forward-only only.");
        }

        String rsConcurrencyString = RDBMSQueryUtils.getResultSetConcurrencyForQuery(query);
        if (rsConcurrencyString != null &&
            (!rsConcurrencyString.equals("read-only") && !rsConcurrencyString.equals("updateable")))
        {
            // TODO Localise this
            throw new NucleusUserException(
                "Query extension 'datanucleus.rdbms.query.resultSetConcurrency' has valid values of " +
                "read-only,updateable only.");
        }

        SQLController sqlControl = ((RDBMSManager)om.getStoreManager()).getSQLController();
        PreparedStatement ps = sqlControl.getStatementForQuery(conn, stmtText.toString(), rsTypeString, rsConcurrencyString);
        stmtText.applyParametersToStatement(om, ps);

        return ps;
    }

    /**
     * Method to apply any query timeouts, and to add any restrictions to the created ResultSet.
     * @param ps The PreparedStatement
     * @param query The query
     * @throws SQLException Thrown when an error occurs applying the constraints
     */
    public static void prepareStatementForExecution(PreparedStatement ps, Query query)
    throws SQLException
    {
        OMFContext omfCtx = query.getObjectManager().getOMFContext();
        MappedStoreManager storeMgr = (MappedStoreManager)omfCtx.getStoreManager();
        PersistenceConfiguration conf = omfCtx.getPersistenceConfiguration();

        // Apply any user-specified timeout
        int timeout = conf.getIntProperty("datanucleus.query.timeout");
        Object timeoutExt = query.getExtension("datanucleus.query.timeout");
        if (timeoutExt != null)
        {
            // Accept timeout as an Integer or String
            if (timeoutExt instanceof Integer)
            {
                timeout = ((Integer)timeoutExt).intValue();
            }
            else if (timeoutExt instanceof String)
            {
                timeout = TypeConversionHelper.intFromString((String)timeoutExt, 0);
            }
        }
        if (timeout > 0)
        {
            ps.setQueryTimeout(timeout);
        }

        // Apply any fetch size
        int fetchSize = 0;
        if (query.getFetchPlan().getFetchSize() > 0)
        {
            // FetchPlan has a size set so use that
            fetchSize = query.getFetchPlan().getFetchSize();
        }
        if (storeMgr.getDatastoreAdapter().supportsQueryFetchSize(fetchSize))
        {
            ps.setFetchSize(fetchSize);
        }

        // Apply any fetch direction
        String propName = "datanucleus.rdbms.query.fetchDirection";
        String fetchDir = conf.getStringProperty(propName);
        Object fetchDirExt = query.getExtension(propName);
        if (fetchDirExt != null)
        {
            fetchDir = (String)fetchDirExt;
            if (!fetchDir.equals("forward") && !fetchDir.equals("reverse") && !fetchDir.equals("unknown"))
            {
                // TODO Localise this
                throw new NucleusUserException(
                    "Query extension \"datanucleus.rdbms.query.fetchDirection\" has valid values of " +
                    "forward,reverse,unknown only");
            }
        }

        if (fetchDir.equals("reverse"))
        {
            ps.setFetchDirection(ResultSet.FETCH_REVERSE);
        }
        else if (fetchDir.equals("unknown"))
        {
            ps.setFetchDirection(ResultSet.FETCH_UNKNOWN);
        }

        // Add a limit on the number of rows to include the maximum we may need
        long toExclNo = query.getRangeToExcl();
        if (toExclNo != 0 && toExclNo != Long.MAX_VALUE)
        {
            if (toExclNo > Integer.MAX_VALUE)
            {
                // setMaxRows takes an int as input so limit to the correct range
                ps.setMaxRows(Integer.MAX_VALUE);
            }
            else
            {
                ps.setMaxRows((int)toExclNo);
            }
        }
    }
}