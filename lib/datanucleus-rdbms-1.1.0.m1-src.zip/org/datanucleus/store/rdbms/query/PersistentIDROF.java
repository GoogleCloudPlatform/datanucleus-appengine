/**********************************************************************
Copyright (c) 2002 Kelly Grizzle (TJDO) and others. All rights reserved. 
Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License. 
 

Contributors:
2003 Erik Bengtson - removed subclasses operation
2003 Andy Jefferson - comments, and update to returned class name
2003 Erik Bengtson - added getObjectByAid
2004 Erik Bengtson - throws an JDOObjectNotFoundException
2004 Erik Bengtson - removed unused variable and import
2004 Erik Bengtson - added support for ignoreCache
2004 Andy Jefferson - coding standards
2005 Andy Jefferson - added support for using discriminator to distinguish objects 
    ...
**********************************************************************/
package org.datanucleus.store.rdbms.query;

import java.lang.reflect.Modifier;
import java.sql.ResultSet;
import java.util.Map;

import org.datanucleus.ClassLoaderResolver;
import org.datanucleus.FetchPlan;
import org.datanucleus.ObjectManager;
import org.datanucleus.StateManager;
import org.datanucleus.exceptions.NucleusUserException;
import org.datanucleus.identity.OID;
import org.datanucleus.identity.OIDFactory;
import org.datanucleus.metadata.AbstractClassMetaData;
import org.datanucleus.metadata.AbstractMemberMetaData;
import org.datanucleus.metadata.IdentityType;
import org.datanucleus.metadata.InterfaceMetaData;
import org.datanucleus.metadata.VersionMetaData;
import org.datanucleus.store.FieldValues;
import org.datanucleus.store.fieldmanager.FieldManager;
import org.datanucleus.store.mapped.DatastoreClass;
import org.datanucleus.store.mapped.StatementMappingForClass;
import org.datanucleus.store.mapped.StatementMappingIndex;
import org.datanucleus.store.mapped.mapping.JavaTypeMapping;
import org.datanucleus.store.query.ResultObjectFactory;
import org.datanucleus.store.rdbms.RDBMSManager;
import org.datanucleus.util.NucleusLogger;
import org.datanucleus.util.Localiser;
import org.datanucleus.util.SoftValueMap;

/**
 * ResultObjectFactory that takes a JDBC ResultSet and create a PersistenceCapable object instance for
 * each row in the ResultSet. We use information in the result set to determine the object type :
 * <UL>
 * <LI><B>discriminator</B> - when the candidate class and all possible subclasses in the query
 * are stored in the same table they are distinguished using a "discriminator" column that will
 * either store the class name, or a value representing that type.</LI>
 * <LI><B>NUCMETADATA</B> - in all other cases we add an extra column to the SELECT that contains
 * the class name of the object.</LI>
 * </UL>
 */
public final class PersistentIDROF implements ResultObjectFactory
{
    /** Localiser for messages. */
    protected static final Localiser LOCALISER = Localiser.getInstance(
        "org.datanucleus.store.rdbms.Localisation", RDBMSManager.class.getClassLoader());

    /**
     * Table where the objects of the candidate class are stored.
     * If the candidate uses "subclass-table" inheritance then this will be one or the other and may cause issues!
     */
    private final DatastoreClass table;

    /** Metadata for the candidate class. */
    protected final AbstractClassMetaData acmd;

    /** Persistent class that this factory will generate (may be the base class). */
    private Class persistentClass;

    /** Mapping for the statement to members of this class (and sub-objects). */
    protected StatementMappingForClass stmtMapping = null;

    /** Flag whether we should use a discriminator column to distinguish object types (otherwise use NUCMETADATA). */
    protected boolean discriminator;

    /** if the results have included a meta data column with the class name. */
    protected boolean hasMetaDataInResults;

    /** Fetch Plan to use when loading fields (if any). */
    protected final FetchPlan fetchPlan;

    /** Whether to ignore the cache */
    private final boolean ignoreCache;

    /** Resolved classes for metadata / discriminator keyed by class names. */
    private Map resolvedClasses = new SoftValueMap();

    /**
     * Constructor.
     * @param table Table being selected from
     * @param acmd MetaData for the class (base class)
     * @param mappingDefinition Mapping information for the result set and how it maps to the class
     * @param ignoreCache Whether to ignore the cache
     * @param discriminator Whether we use a discriminator column to distinguish object types
     * @param hasMetaDataInResults whether we use NUCMETADATA column    
     * @param fetchPlan the Fetch Plan
     * @param persistentClass Class that this factory will create instances of (or subclasses)
     */
    public PersistentIDROF(DatastoreClass table, AbstractClassMetaData acmd,
                           StatementMappingForClass mappingDefinition,
                           boolean ignoreCache, boolean discriminator, boolean hasMetaDataInResults,
                           FetchPlan fetchPlan, Class persistentClass)
    {
        this.stmtMapping = mappingDefinition;
        this.acmd = acmd;
        this.table = table;

        this.ignoreCache = ignoreCache;
        this.fetchPlan = fetchPlan;
        this.persistentClass = persistentClass;
        // TODO Merge discriminator/hasMetaDataInResults into an enum
        this.discriminator = discriminator;
        this.hasMetaDataInResults = hasMetaDataInResults;
    }

    /**
     * Method to update the persistent class that the result object factory requires.
     * This is used where we have an Extent(BaseClass) and we pass it to a JDOQL query but the query
     * has been specified with a candidate class that is a subclass. So we use this method to restrict
     * the results further.
     * @param cls The Class the result factory requires.
     */
    public void setPersistentClass(Class cls)
    {
        this.persistentClass = cls;
    }

    /**
     * Method to convert the current ResultSet row into an Object.
     * @param om The ObjectManager
     * @param rs The ResultSet from the Query.
     * @return The (persisted) object.
     */
    public Object getObject(final ObjectManager om, final Object rs)
    {
        // Find the class of the returned object in this row of the ResultSet
        // TODO Determine type of class based on whether there is a discriminator mapping, or NUCMETADATA column
        boolean requiresInheritanceCheck = true;
        String className = null;
        if (discriminator)
        {
            // Extract the class type from the discriminator in the ResultSet
            className = RDBMSQueryUtils.getClassNameFromDiscriminatorResultSetRow(table, (ResultSet)rs, om);
        }
        else if (hasMetaDataInResults)
        {
            // Extract the object type using the NUCMETADATA column (if available)
            try
            {
                className = RDBMSQueryUtils.getClassNameFromMetaDataResultSetRow((ResultSet)rs);
            }
            catch (Exception e)
            {
                // Do nothing
            }
        }

        ClassLoaderResolver clr = om.getClassLoaderResolver();
        Class pcClassForObject = persistentClass;
        if (className != null)
        {
            Class cls = (Class) resolvedClasses.get(className);
            if (cls != null)
            {
                pcClassForObject = cls;
            }
            else
            {
                if (persistentClass.getName().equals(className))
                {
                    pcClassForObject = persistentClass;
                }
                else
                {
                    pcClassForObject = clr.classForName(className, persistentClass.getClassLoader());
                }
                resolvedClasses.put(className, pcClassForObject);
            }
            requiresInheritanceCheck = false;
        }

        if (Modifier.isAbstract(pcClassForObject.getModifiers()))
        {
            // Persistent class is abstract so we can't create instances of that type!
            // This can happen if the user is using subclass-table and hasn't provided a discriminator in 
            // the table. Try going out one level and find a concrete subclass 
            // TODO make this more robust and go out further
            String[] subclasses = om.getMetaDataManager().getSubclassesForClass(pcClassForObject.getName(), false);
            if (subclasses != null)
            {
                for (int i=0;i<subclasses.length;i++)
                {
                    Class subcls = clr.classForName(subclasses[i]);
                    if (!Modifier.isAbstract(subcls.getModifiers()))
                    {
                        NucleusLogger.PERSISTENCE.warn(LOCALISER.msg("052300", 
                            pcClassForObject.getName(), subcls.getName()));
                        pcClassForObject = subcls;
                        break;
                    }
                    if (i == subclasses.length-1)
                    {
                        throw new NucleusUserException(LOCALISER.msg("052301",
                            pcClassForObject.getName()));
                    }
                }
            }
        }

        // Find the statement mappings and field numbers to use for the result class
        // Caters for persistent-interfaces and the result class being an implementation
        AbstractClassMetaData cmd = om.getMetaDataManager().getMetaDataForClass(pcClassForObject, clr);
        int[] fieldNumbers = stmtMapping.getMemberNumbers();
        StatementMappingForClass mappingDefinition;
        int[] mappedFieldNumbers;
        if (acmd instanceof InterfaceMetaData)
        {
            // Persistent-interface : create new mapping definition for a result type of the implementation
            mappingDefinition = new StatementMappingForClass(null);
            mappedFieldNumbers = new int[fieldNumbers.length];
            for (int i = 0; i < fieldNumbers.length; i++)
            {
                AbstractMemberMetaData mmd = acmd.getMetaDataForManagedMemberAtAbsolutePosition(fieldNumbers[i]);
                mappedFieldNumbers[i] = cmd.getAbsolutePositionOfMember(mmd.getName());
                mappingDefinition.addMappingForMember(mappedFieldNumbers[i], 
                    stmtMapping.getMappingForMemberPosition(fieldNumbers[i]));
            }
        }
        else
        {
            // Persistent class
            mappingDefinition = stmtMapping;
            mappedFieldNumbers = fieldNumbers;
        }

        // Extract the object from the ResultSet
        Object obj = null;
        if (cmd.getIdentityType() == IdentityType.APPLICATION)
        {
            obj = getObjectForApplicationId(om, rs, mappingDefinition, mappedFieldNumbers,
                cmd, pcClassForObject, requiresInheritanceCheck);
        }
        else if (cmd.getIdentityType() == IdentityType.DATASTORE)
        {
            // Generate the "oid" for this object (of type pcClassForObject), and find the object for that
            StatementMappingIndex datastoreIdMapping = stmtMapping.getMappingForMemberPosition(-1);
            JavaTypeMapping mapping = datastoreIdMapping.getMapping();
            OID oid = (OID)mapping.getObject(om, rs, datastoreIdMapping.getColumnPositions());
            Object id = oid;
            if (!pcClassForObject.getName().equals(oid.getPcClass()))
            {
                // Get an OID for the right inheritance level
                id = OIDFactory.getInstance(om, pcClassForObject.getName(), oid.getKeyValue());
            }

            if (mappedFieldNumbers == null)
            {
                obj = om.findObject(id, false, requiresInheritanceCheck, null);
            }
            else
            {
                obj = getObjectForDatastoreId(om, rs, mappingDefinition, mappedFieldNumbers, 
                    cmd, id, requiresInheritanceCheck ? null : pcClassForObject);
            }
        }
        else if (cmd.getIdentityType() == IdentityType.NONDURABLE)
        {
            Object id = om.newObjectId(className, null);
            if (mappedFieldNumbers == null)
            {
                obj = om.findObject(id, false, requiresInheritanceCheck, null);
            }
            else
            {
                obj = getObjectForDatastoreId(om, rs, mappingDefinition, mappedFieldNumbers,
                    cmd, id, pcClassForObject);
            }
        }
        // TODO Process any child classes

        // Set the version of the object where possible
        int versionFieldNumber = -1;
        VersionMetaData vermd = table.getVersionMetaData();
        if (vermd != null && vermd.getFieldName() != null)
        {
            // Version stored in a normal field
            versionFieldNumber = acmd.getMetaDataForMember(vermd.getFieldName()).getAbsoluteFieldNumber();
            if (stmtMapping.getMappingForMemberPosition(versionFieldNumber) != null)
            {
                StateManager objSM = om.findStateManager(obj);
                Object verFieldValue = objSM.provideField(versionFieldNumber);
                if (verFieldValue != null)
                {
                    objSM.setVersion(verFieldValue);
                }
            }
        }

        StatementMappingIndex versionMapping = 
            stmtMapping.getMappingForMemberPosition(StatementMappingForClass.MEMBER_VERSION);
        if (versionMapping != null)
        {
            // Surrogate version column returned by query
            JavaTypeMapping mapping = versionMapping.getMapping();
            Object version = mapping.getObject(om, rs, versionMapping.getColumnPositions());
            StateManager objSM = om.findStateManager(obj);
            objSM.setVersion(version);
        }

        return obj;
    }

    /**
     * Returns a PC instance from a ResultSet row with an application identity.
     * @param om ObjectManager
     * @param resultSet The ResultSet
     * @param mappingDefinition The mapping info for the result class
     * @param fieldNumbers Numbers of the fields (of the class) found in the ResultSet
     * @param cmd MetaData for the class
     * @param pcClass PersistenceCapable class
     * @param requiresInheritanceCheck Whether we need to check the inheritance level of the returned object
     * @return The object with this application identity
     */
    private Object getObjectForApplicationId(final ObjectManager om, final Object resultSet, 
            final StatementMappingForClass mappingDefinition, final int[] fieldNumbers, 
            AbstractClassMetaData cmd, Class pcClass, boolean requiresInheritanceCheck)
    {
        return om.findObjectUsingAID(pcClass, new FieldValues()
        {
            public void fetchFields(StateManager sm)
            {
                FieldManager fm = 
                    table.getStoreManager().getFieldManagerForResultProcessing(sm, resultSet, mappingDefinition);
                sm.replaceFields(fieldNumbers, fm, false);
            }
            public void fetchNonLoadedFields(StateManager sm)
            {
                FieldManager fm =
                    table.getStoreManager().getFieldManagerForResultProcessing(sm, resultSet, mappingDefinition);
                sm.replaceNonLoadedFields(fieldNumbers, fm);
            }
            public FetchPlan getFetchPlanForLoading()
            {
                return fetchPlan;
            }
        }, ignoreCache, requiresInheritanceCheck);
    }

    /**
     * Returns a PC instance from a ResultSet row with a datastore identity.
     * @param om ObjectManager
     * @param resultSet The ResultSet
     * @param mappingDefinition The mapping info for the result class
     * @param fieldNumbers Numbers of the fields (of the class) found in the ResultSet
     * @param cmd MetaData for the class
     * @param oid The object id
     * @param pcClass The PersistenceCapable class (where we know the instance type required, null if not)
     * @return The Object
     */
    private Object getObjectForDatastoreId(final ObjectManager om, final Object resultSet, 
            final StatementMappingForClass mappingDefinition, final int[] fieldNumbers,
            AbstractClassMetaData cmd, Object oid, Class pcClass)
    {
        if (oid == null)
        {
            return null;
        }

        if (pcClass == null)
        {
            return om.findObject(oid, new FieldValues()
            {
                public void fetchFields(StateManager sm)
                {
                    FieldManager fm = table.getStoreManager().getFieldManagerForResultProcessing(sm, resultSet,
                        mappingDefinition);
                    sm.replaceFields(fieldNumbers, fm, false);
                }
                public void fetchNonLoadedFields(StateManager sm)
                {
                    FieldManager fm = table.getStoreManager().getFieldManagerForResultProcessing(sm, resultSet,
                        mappingDefinition);
                    sm.replaceNonLoadedFields(fieldNumbers, fm);
                }
                public FetchPlan getFetchPlanForLoading()
                {
                    return fetchPlan;
                }
            });
        }
        else
        {
            return om.findObject(oid, new FieldValues()
            {
                public void fetchFields(StateManager sm)
                {
                    FieldManager fm = table.getStoreManager().getFieldManagerForResultProcessing(sm, resultSet,
                        mappingDefinition);
                    sm.replaceFields(fieldNumbers, fm, false);
                }
                public void fetchNonLoadedFields(StateManager sm)
                {
                    FieldManager fm = table.getStoreManager().getFieldManagerForResultProcessing(sm, resultSet,
                        mappingDefinition);
                    sm.replaceNonLoadedFields(fieldNumbers, fm);
                }
                public FetchPlan getFetchPlanForLoading()
                {
                    return fetchPlan;
                }
            }, pcClass, ignoreCache);
        }
    }
}