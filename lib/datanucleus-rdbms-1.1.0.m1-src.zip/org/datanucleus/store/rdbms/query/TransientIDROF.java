/**********************************************************************
Copyright (c) 2002 Kelly Grizzle (TJDO) and others. All rights reserved.
Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.

Contributors:
2002 Mike Martin (TJDO)
2003 Erik Bengtson - removed getObject
2003 Andy Jefferson - coding standards
    ...
**********************************************************************/

package org.datanucleus.store.rdbms.query;

import java.sql.ResultSet;

import org.datanucleus.FetchPlan;
import org.datanucleus.ObjectManager;
import org.datanucleus.StateManager;
import org.datanucleus.store.FieldValues;
import org.datanucleus.store.mapped.StatementExpressionIndex;
import org.datanucleus.store.query.ResultObjectFactory;
import org.datanucleus.store.rdbms.fieldmanager.ResultSetGetter;

/**
 * ResultObjectFactory that generates an instance of a "nondurable" class for each ResultSet row.
 * This is used by views though better off using a ResultClassROF.
 */
public final class TransientIDROF implements ResultObjectFactory
{
    private final Class candidateClass;
    protected final int[] fieldNumbers;
	protected final StatementExpressionIndex[] statementExpressionIndex;

	/**
     * Constructor 
     * @param candidateClass the candidate class
     * @param fieldNumbers the absolute field numbers with the retrieved fields
     * @param statementExpressionIndex the StatementExpressionIndex
	 */
    public TransientIDROF(Class candidateClass, int[] fieldNumbers, StatementExpressionIndex[] statementExpressionIndex)
    {
        this.candidateClass = candidateClass;
        this.fieldNumbers = fieldNumbers;
        this.statementExpressionIndex = statementExpressionIndex;
    }

	/**
     * Method to return an object for the row of the ResultSet.
     * @param om ObjectManager
     * @param rs ResultSet
     * @return The Object for this row of the ResultSet.
	 */
	public Object getObject(final ObjectManager om, final Object rs)
    {
        return om.findObject(om.newObjectId(candidateClass.getName(), null),
            new FieldValues()
            {
                public void fetchFields(StateManager sm)
                {
                    sm.replaceFields(fieldNumbers, new ResultSetGetter(sm, (ResultSet)rs, statementExpressionIndex), false);
                }
                public void fetchNonLoadedFields(StateManager sm)
                {
                    sm.replaceNonLoadedFields(fieldNumbers, new ResultSetGetter(sm, (ResultSet)rs, statementExpressionIndex));
                }
                public FetchPlan getFetchPlanForLoading()
                {
                    return null;
                }
            }
        );
	}
}