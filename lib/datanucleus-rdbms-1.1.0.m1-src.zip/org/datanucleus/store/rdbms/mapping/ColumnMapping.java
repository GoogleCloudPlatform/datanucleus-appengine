/**********************************************************************
Copyright (c) 2004 Erik Bengtson and others. All rights reserved.
Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.

Contributors:
2004 Andy Jefferson - coding standards and localisation of messages
    ...
**********************************************************************/
package org.datanucleus.store.rdbms.mapping;

import org.datanucleus.store.exceptions.UnsupportedDataTypeException;
import org.datanucleus.store.mapped.DatastoreField;
import org.datanucleus.store.mapped.MappedStoreManager;
import org.datanucleus.store.mapped.mapping.JavaTypeMapping;
import org.datanucleus.store.rdbms.schema.SQLTypeInfo;
import org.datanucleus.store.rdbms.table.Column;

/**
 * Column Mapping.
 */
public abstract class ColumnMapping extends RDBMSMapping
{
    protected Column column;

    /**
     * Create a new Mapping.
     * 
     * @param storeMgr The Store Manager that this Mapping should use.
     * @param mapping The Class that this mapping maps to the database.
     */
    public ColumnMapping(MappedStoreManager storeMgr, JavaTypeMapping mapping)
    {
        super(storeMgr, mapping);
    }

    /**
     * Accessor for whether the mapping is decimal-based.
     * @return Whether the mapping is decimal based
     */
    public boolean isDecimalBased()
    {
        return false;
    }

    /**
     * Accessor for whether the mapping is integer-based.
     * @return Whether the mapping is integer based
     */
    public boolean isIntegerBased()
    {
        return false;
    }

    /**
     * Accessor for whether the mapping is string-based.
     * @return Whether the mapping is string based
     */
    public boolean isStringBased()
    {
        return false;
    }

    /**
     * Accessor for whether the mapping is bit-based.
     * @return Whether the mapping is bit based
     */
    public boolean isBitBased()
    {
        return false;
    }

    /**
     * Accessor for whether the mapping is boolean-based.
     * @return Whether the mapping is boolean based
     */
    public boolean isBooleanBased()
    {
        return false;
    }

    public boolean isNullable()
    {
        if (column != null)
        {
            return column.isNullable();
        }
        return true;
    }

    /**
     * Accessor for the datastore field
     * @return The column
     */
    public DatastoreField getDatastoreField()
    {
        return column;
    }

	/**
	 * Sets the TypeInfo for the columns of the Mapping.
	 * Mappings using two or more columns using different TypeInfo(s) should
     * overwrite this method to appropriate set the TypeInfo (SQL type) for
     * all the columns
	 */
    protected void initTypeInfo()
    {
        SQLTypeInfo typeInfo = getTypeInfo();
        if (typeInfo == null)
        {
            throw new UnsupportedDataTypeException(LOCALISER.msg("055000",column));
        }

        if (column != null)
        {
            column.setTypeInfo(typeInfo);
        }
    }

    /**
     * @return Returns the column.
     */
    public Column getColumn()
    {
        return column;
    }
    
    /* (non-Javadoc)
     * @see org.datanucleus.store.rdbms.mapping.RDBMSMapping#includeInFetchStatement()
     */
    public boolean includeInFetchStatement()
    {
        return true;
    }

    /* (non-Javadoc)
     * @see org.datanucleus.store.rdbms.mapping.RDBMSMapping#getInsertionInputParameter()
     */
    public String getInsertionInputParameter()
    {
        return column.getWrapperFunction(Column.WRAPPER_FUNCTION_INSERT);
    }

    /* (non-Javadoc)
     * @see org.datanucleus.store.rdbms.mapping.RDBMSMapping#getUpdateInputParameter()
     */
    public String getUpdateInputParameter()
    {
        return column.getWrapperFunction(Column.WRAPPER_FUNCTION_UPDATE);
    }

    public boolean equals(Object obj)
    {
        if (this == obj)
        {
            return true;
        }

        if (!(obj instanceof ColumnMapping))
        {
            return false;
        }

        ColumnMapping cm = (ColumnMapping)obj;

        return getClass().equals(cm.getClass()) &&
            storeMgr.equals(cm.storeMgr) &&
            (column == null ? cm.column == null : column.equals(cm.column));
    }

    public int hashCode()
    {
        return storeMgr.hashCode() ^ (column == null ? 0 : column.hashCode());
    }
}