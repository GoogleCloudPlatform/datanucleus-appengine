/**********************************************************************
Copyright (c) 2003 Mike Martin and others. All rights reserved.
Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.

Contributors:
    Andy Jefferson - coding standards
    ...
**********************************************************************/
package org.datanucleus.store.rdbms.exceptions;

import org.datanucleus.exceptions.NucleusException;
import org.datanucleus.store.rdbms.RDBMSManager;
import org.datanucleus.store.rdbms.table.Column;
import org.datanucleus.util.Localiser;

/**
 * A <tt>DuplicateColumnNameException</tt> is thrown if an attempt is made to
 * add a column to a table with a name already in-use by an existing column.
 *
 * @version $Revision: 1.4 $
 */
public class DuplicateColumnNameException extends NucleusException
{
    private static final Localiser LOCALISER=Localiser.getInstance("org.datanucleus.store.rdbms.Localisation",
        RDBMSManager.class.getClassLoader());

    /** Column that cannot be created because it conflicts with an existing column with the same identifier. */
    private Column conflictingColumn;

    /**
     * Constructs a duplicate column name exception.
     * @param tableName Name of the table being initialized.
     * @param column Column we already have
     * @param otherColumn Column that we tried to create
     */
    public DuplicateColumnNameException(String tableName, Column column, Column otherColumn)
    {
        super(LOCALISER.msg("020007", column.getIdentifier(), tableName,
            column.getFieldMetaData() == null ?
                LOCALISER.msg("020008") :
                (column.getFieldMetaData() != null ? column.getFieldMetaData().getFullFieldName() : null),
            otherColumn.getFieldMetaData() == null ?
                LOCALISER.msg("020008") :
                (otherColumn.getFieldMetaData() != null ? otherColumn.getFieldMetaData().getFullFieldName() : null)));
        this.conflictingColumn = otherColumn;
        setFatal();
    }

    /**
     * Accessor for the column that could not be created because it conflicts with something already present.
     * @return The column
     */
    public Column getConflictingColumn()
    {
        return conflictingColumn;
    }
}