/**********************************************************************
Copyright (c) 2009 Andy Jefferson and others. All rights reserved.
Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.

Contributors:
    ...
**********************************************************************/
package org.datanucleus.store.rdbms.sql;

import org.datanucleus.ClassLoaderResolver;
import org.datanucleus.FetchPlan;
import org.datanucleus.FetchPlan.FetchPlanForClass;
import org.datanucleus.metadata.AbstractClassMetaData;
import org.datanucleus.metadata.AbstractMemberMetaData;
import org.datanucleus.metadata.IdentityType;
import org.datanucleus.metadata.JoinMetaData;
import org.datanucleus.metadata.Relation;
import org.datanucleus.store.mapped.DatastoreClass;
import org.datanucleus.store.mapped.DatastoreContainerObject;
import org.datanucleus.store.mapped.DatastoreElementContainer;
import org.datanucleus.store.mapped.SecondaryDatastoreClass;
import org.datanucleus.store.mapped.StatementMappingForClass;
import org.datanucleus.store.mapped.StatementMappingIndex;
import org.datanucleus.store.mapped.mapping.AbstractContainerMapping;
import org.datanucleus.store.mapped.mapping.JavaTypeMapping;
import org.datanucleus.store.mapped.mapping.ReferenceMapping;
import org.datanucleus.store.rdbms.RDBMSManager;

/**
 * Series of convenience methods to help the process of generating SQLStatements.
 */
public class SQLStatementHelper
{
    /**
     * Method to return the SQLTable where the specified mapping (of the class of the provided SQLTable) 
     * is defined. If the statement doesn't currently join to the required table then a join will be
     * added. If the required table is a superclass table then the join will be INNER. If the
     * required table is a secondary table then the join will be defined by the meta-data for
     * the secondary table.
     * @param stmt The statement
     * @param sqlTbl SQLTable to start from for the supplied mapping (may be in super-table,
     *     or secondary-table of this)
     * @param mapping The mapping
     * @return The SQLTable for this mapping (may have been added to the statement during this method)
     */
    public static SQLTable getSQLTableForMappingOfTable(SQLStatement stmt, SQLTable sqlTbl, 
            JavaTypeMapping mapping)
    {
        DatastoreClass sourceTbl = (DatastoreClass)sqlTbl.getTable();
        DatastoreClass mappingTbl = null;
        if (mapping.getDatastoreContainer() != null)
        {
            mappingTbl = (DatastoreClass)mapping.getDatastoreContainer();
        }
        else
        {
            mappingTbl = sourceTbl.getBaseDatastoreClassWithMember(mapping.getMemberMetaData());
        }
        if (mappingTbl == sourceTbl)
        {
            return sqlTbl;
        }

        SQLTable mappingSqlTbl = stmt.getTable(mappingTbl);
        if (mappingSqlTbl == null)
        {
            if (mappingTbl instanceof SecondaryDatastoreClass)
            {
                // Secondary table, so add inner/outer based on metadata
                boolean innerJoin = true;
                JoinMetaData joinmd = ((SecondaryDatastoreClass)mappingTbl).getJoinMetaData();
                if (joinmd != null && joinmd.isOuter())
                {
                    innerJoin = false;
                }
                if (innerJoin)
                {
                    // Add join from {sourceTbl}.ID to {secondaryTbl}.ID
                    mappingSqlTbl = stmt.innerJoin(sqlTbl, sqlTbl.getTable().getIDMapping(),
                        mappingTbl, null, mappingTbl.getIDMapping(), null);
                }
                else
                {
                    // Add join from {sourceTbl}.ID to {secondaryTbl}.ID
                    mappingSqlTbl = stmt.leftOuterJoin(sqlTbl, sqlTbl.getTable().getIDMapping(),
                        mappingTbl, null, mappingTbl.getIDMapping(), null);
                }
            }
            else
            {
                // Add join from {sourceTbl}.ID to {superclassTbl}.ID
                mappingSqlTbl = stmt.innerJoin(sqlTbl, sqlTbl.getTable().getIDMapping(),
                    mappingTbl, null, mappingTbl.getIDMapping(), null);
            }
        }
        return mappingSqlTbl;
    }

    /**
     * Method to select all fetch plan members for the candidate class.
     * The supplied statement and mapping definition are updated during this method.
     * Shortcut to calling "selectFetchPlanOfSourceClassInStatement".
     * @param stmt The statement
     * @param mappingDefinition Mapping definition for result columns
     * @param fetchPlan FetchPlan in use
     * @param candidateCmd The candidate class meta-data
     */
    public static void selectFetchPlanOfCandidateInStatement(SQLStatement stmt,
            StatementMappingForClass mappingDefinition, FetchPlan fetchPlan,
            AbstractClassMetaData candidateCmd)
    {
        selectFetchPlanOfSourceClassInStatement(stmt, mappingDefinition, fetchPlan,
            stmt.getPrimaryTable(), candidateCmd);
    }

    /**
     * Method to select all fetch plan members for the "source" class.
     * The source class is defined by the supplied meta-data, and the SQLTable that we are selecting from.
     * The supplied statement and mapping definition are updated during this method.
     * @param stmt The statement
     * @param mappingDefinition Mapping definition for result columns
     * @param fetchPlan FetchPlan in use
     * @param sourceSqlTbl SQLTable for the source class that we select from
     * @param sourceCmd Meta-data for the source class
     */
    public static void selectFetchPlanOfSourceClassInStatement(SQLStatement stmt,
            StatementMappingForClass mappingDefinition, FetchPlan fetchPlan,
            SQLTable sourceSqlTbl, AbstractClassMetaData sourceCmd)
    {
        DatastoreClass sourceTbl = (DatastoreClass)sourceSqlTbl.getTable();
        fetchPlan.manageFetchPlanForClass(sourceCmd);
        FetchPlanForClass fpc = fetchPlan.getFetchPlanForClass(sourceCmd);
        int fieldNumbers[] = fpc.getFieldsInActualFetchPlan();
        ClassLoaderResolver clr = stmt.getRDBMSManager().getOMFContext().getClassLoaderResolver(null);

        for (int i=0;i<fieldNumbers.length;i++)
        {
            AbstractMemberMetaData mmd =
                sourceCmd.getMetaDataForManagedMemberAtAbsolutePosition(fieldNumbers[i]);
            selectMemberOfSourceInStatement(stmt, mappingDefinition, fetchPlan, sourceSqlTbl, mmd, clr);
        }

        // TODO Select discriminator ?
        if (sourceCmd.getIdentityType() == IdentityType.DATASTORE)
        {
            // Datastore-identity surrogate column
            JavaTypeMapping idMapping = sourceTbl.getDataStoreObjectIdMapping();
            StatementMappingIndex datastoreIdIdx = new StatementMappingIndex(idMapping);
            int[] colNumbers = stmt.select(sourceSqlTbl, idMapping, null);
            datastoreIdIdx.setColumnPositions(colNumbers);
            mappingDefinition.addMappingForMember(StatementMappingForClass.MEMBER_DATASTORE_ID, datastoreIdIdx);
        }

        JavaTypeMapping verMapping = sourceTbl.getVersionMapping(true);
        if (verMapping != null)
        {
            // Version surrogate column (adds inner join to any required superclass table)
            StatementMappingIndex versionIdx = new StatementMappingIndex(verMapping);
            SQLTable sqlVerTbl = SQLStatementHelper.getSQLTableForMappingOfTable(stmt, sourceSqlTbl, verMapping);
            int[] colNumbers = stmt.select(sqlVerTbl, verMapping, null);
            versionIdx.setColumnPositions(colNumbers);
            mappingDefinition.addMappingForMember(StatementMappingForClass.MEMBER_VERSION, versionIdx);
        }
    }

    /**
     * Method to select the specified member (field/property) of the source table in the passed SQL 
     * statement. This populates the mappingDefinition with the column details for this member.
     * @param stmt The SQL statement
     * @param mappingDefinition Mapping definition for the results
     * @param fetchPlan FetchPlan
     * @param sourceSqlTbl Table that has the member (or a super-table/secondary-table of this table)
     * @param mmd Meta-data for the field/property in the source that we are selecting
     * @param clr ClassLoader resolver
     */
    public static void selectMemberOfSourceInStatement(SQLStatement stmt,
            StatementMappingForClass mappingDefinition, FetchPlan fetchPlan,
            SQLTable sourceSqlTbl, AbstractMemberMetaData mmd, ClassLoaderResolver clr)
    {
        boolean selectSubobjects = false;
        if (sourceSqlTbl == stmt.getPrimaryTable())
        {
            selectSubobjects = true;
        }
        JavaTypeMapping m = sourceSqlTbl.getTable().getMemberMapping(mmd);
        if (m != null)
        {
            // omit non-persistent fields and fields not stored in the table, e.g. List, Set, etc
            int relationType = mmd.getRelationType(clr);
            RDBMSManager storeMgr = stmt.getRDBMSManager();
            if (m.includeInFetchStatement() && !(m instanceof AbstractContainerMapping))
            {
                StatementMappingIndex stmtMapping = new StatementMappingIndex(m);
                if (m.getNumberOfDatastoreFields() > 0)
                {
                    // Select of fields with columns in source table(s)
                    // Adds inner/outer join to any required superclass/secondary tables
                    SQLTable sqlTbl = SQLStatementHelper.getSQLTableForMappingOfTable(stmt, sourceSqlTbl, m);
                    int[] colNumbers = stmt.select(sqlTbl, m, null);
                    stmtMapping.setColumnPositions(colNumbers);

                    if (selectSubobjects && 
                        (relationType == Relation.ONE_TO_ONE_UNI ||
                         (relationType == Relation.ONE_TO_ONE_BI && mmd.getMappedBy() == null)))
                    {
                        // Related object so select fetch plan fields of this object
                        AbstractClassMetaData relatedCmd =
                            storeMgr.getMetaDataManager().getMetaDataForClass(mmd.getType(), clr);
                        DatastoreClass relatedTbl = storeMgr.getDatastoreClass(relatedCmd.getFullClassName(), clr);
                        SQLTable relatedSqlTbl = stmt.getTable(relatedTbl);
                        if (relatedSqlTbl == null)
                        {
                            // Add left outer join from {sourceTbl}.FK to {relatedTbl}.ID
                            relatedSqlTbl = stmt.leftOuterJoin(sqlTbl, m,
                                relatedTbl, null, relatedTbl.getIDMapping(), null);
                        }
                        StatementMappingForClass subMappingDefinition = new StatementMappingForClass(mmd.getName());
                        selectFetchPlanOfSourceClassInStatement(stmt, subMappingDefinition, fetchPlan,
                            relatedSqlTbl, relatedCmd);
                        mappingDefinition.addMappingDefinitionForMember(mmd.getAbsoluteFieldNumber(),
                            subMappingDefinition);
                    }
                }
                else
                {
                    // Select of related objects with FK in other table
                    if (relationType == Relation.ONE_TO_ONE_BI && mmd.getMappedBy() != null)
                    {
                        // 1-1 bidirectional relation with FK in related table
                        AbstractMemberMetaData[] relatedMmds = mmd.getRelatedMemberMetaData(clr);
                        AbstractMemberMetaData relatedMmd = relatedMmds[0];
                        if (m instanceof ReferenceMapping)
                        {
                            // TODO Cater for reference field and multiple implementations
                            // TODO Select fetch plan fields of this related object
                        }
                        else
                        {
                            // Add left outer join from {sourceTable}.ID to {relatedTable}.FK
                            DatastoreClass relatedTbl =
                                storeMgr.getDatastoreClass(mmd.getTypeName(), clr);
                            JavaTypeMapping relatedMapping = relatedTbl.getMemberMapping(relatedMmd);
                            SQLTable relatedSqlTbl = stmt.leftOuterJoin(sourceSqlTbl,
                                sourceSqlTbl.getTable().getIDMapping(),
                                relatedTbl, null, relatedMapping, null);
                            // TODO If the relation doesn't allow null then do innerJoin()

                            // Select the ID of the related table
                            int[] colNumbers = stmt.select(relatedSqlTbl, relatedTbl.getIDMapping(), null);
                            stmtMapping.setColumnPositions(colNumbers);

                            if (selectSubobjects)
                            {
                                // Select the fetch-plan fields of the related object
                                // TODO Limit the reach of this so we don't keep on adding more sub-objects
                                StatementMappingForClass subMappingDefinition = new StatementMappingForClass(mmd.getName());
                                selectFetchPlanOfSourceClassInStatement(stmt, subMappingDefinition, fetchPlan,
                                    relatedSqlTbl, relatedMmd.getAbstractClassMetaData());
                                mappingDefinition.addMappingDefinitionForMember(mmd.getAbsoluteFieldNumber(),
                                    subMappingDefinition);
                            }
                        }
                    }
                    else if (relationType == Relation.MANY_TO_ONE_BI)
                    {
                        AbstractMemberMetaData[] relatedMmds = mmd.getRelatedMemberMetaData(clr);
                        if (mmd.getJoinMetaData() != null || relatedMmds[0].getJoinMetaData() != null)
                        {
                            // N-1 bidirectional join table relation
                            // Add left outer join from {sourceTable}.ID to {joinTable}.ELEM_FK
                            DatastoreContainerObject joinTable =
                                storeMgr.getDatastoreContainerObject(relatedMmds[0]);
                            DatastoreElementContainer collTable = (DatastoreElementContainer)joinTable;
                            JavaTypeMapping referenceMapping = collTable.getElementMapping();
                            JavaTypeMapping selectMapping = collTable.getOwnerMapping();
                            SQLTable sqlTblRelated = stmt.leftOuterJoin(sourceSqlTbl, 
                                sourceSqlTbl.getTable().getIDMapping(),
                                collTable, null, referenceMapping, null);

                            // Select the owner mapping of the join table
                            int[] colNumbers = stmt.select(sqlTblRelated, selectMapping, null);
                            stmtMapping.setColumnPositions(colNumbers);
                        }
                        // TODO Select fetch plan fields of this related object
                    }
                }
                mappingDefinition.addMappingForMember(mmd.getAbsoluteFieldNumber(), stmtMapping);
            }
        }
    }
}