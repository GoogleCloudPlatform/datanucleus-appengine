/**********************************************************************
Copyright (c) 2008 Andy Jefferson and others. All rights reserved. 
Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License. 

Contributors:
    ...
**********************************************************************/
package org.datanucleus.store.rdbms.sql;

import java.sql.PreparedStatement;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.datanucleus.ObjectManager;
import org.datanucleus.store.mapped.expression.ExpressionHelper;
import org.datanucleus.store.mapped.mapping.JavaTypeMapping;
import org.datanucleus.store.rdbms.sql.expression.SQLExpression;

/**
 * Representation of a snippet of an SQL statement.
 * May contain parameters.
 */
public class SQLText
{
    private StringBuffer sql;
    private List<Parameter> parameters = null;
    private boolean encloseInParentheses = false;
    private String postpend;
    private List appended;

    /**
     * Constructor
     */
    public SQLText()
    {
        appended = new ArrayList();
    }

    /**
     * Constructor
     * @param initialStatementText 
     */
    public SQLText(String initialStatementText)
    {
        this();
        append(initialStatementText);
    }
    
    /**
     * Convenience method to reset the SQL for the statement.
     * This is used when updating an expression internally, and need to regenerate
     * the statement.
     */
    public void clearStatement()
    {
        sql = null;
        appended.clear();
    }

    /**
     * Whether to enclose this statement within parentheses
     */
    public void encloseInParentheses()
    {
        sql = null;
        this.encloseInParentheses = true;
    }

    /**
     * Set a String to the end of the statement.  
     * @param s the string
     * @return the StatementText
     */
    public SQLText postpend(String s)
    {
        sql = null;
        postpend = s;
        return this;
    }    

    /**
     * Append a char  
     * @param c the char
     * @return the StatementText
     */    
    public SQLText append(char c)
    {
        sql = null;
        appended.add(new Character(c));
        return this;
    }

    /**
     * Append a char  
     * @param s the String
     * @return the StatementText
     */    
    public SQLText append(String s)
    {
        sql = null;
        appended.add(s);
        return this;
    }

    /**
     * Append an SQLStatement.
     * @param stmt the SQL Statement
     * @return the SQLText
     */    
    public SQLText append(SQLStatement stmt)
    {
        sql = null;
        appended.add(stmt);
        return this;
    }

    /**
     * Append a StatementText
     * @param st the StatementText
     * @return the StatementText
     */    
    public SQLText append(SQLText st, int mode)
    {
        sql = null;
        appended.add(st.toSQL(mode));
        if (st.parameters != null)
        {
            if (parameters == null)
            {
                parameters = new ArrayList();
            }
            parameters.addAll(st.parameters);
        }
        return this;
    }

    /**
     * Append an SQLExpression.
     * @param expr the SQLExpression
     * @return the StatementText
     */    
    public SQLText append(SQLExpression expr)
    {
        sql = null;
        appended.add(expr);
        return this;
    }
    
    /**
     * Append a parameter.
     * @param mapping the mapping
     * @param value the parameter value
     * @return the StatementText
     */
    public SQLText appendParameter(JavaTypeMapping mapping, Object value)
    {
        sql = null;
        appended.add(new Parameter(mapping,value));
        return this;
    }

    /**
     * Method to set the parameters in the supplied PreparedStatement.
     * @param om ObjectManager
     * @param ps The PreparedStatement
     */
    public void applyParametersToStatement(ObjectManager om, PreparedStatement ps)
    {
        if (parameters != null)
        {
            int num = 1;

            Iterator<Parameter> i = parameters.iterator();
            while (i.hasNext())
            {
                Parameter param = i.next();
                JavaTypeMapping mapping = param.mapping;
                Object value = param.value;

                mapping.setObject(om, ps, ExpressionHelper.getParametersIndex(num, mapping), value);
                if (mapping.getNumberOfDatastoreFields() > 0)
                {
                    num += mapping.getNumberOfDatastoreFields();
                }
                else
                {
                    num += 1;
                }
            }
        }
    }

    /**
     * Accessor for the SQL of the statement.
     * @param mode (0=PROJECTION;1=FILTER) - which means WHAT exactly ?
     * @return The SQL text
     */
    public String toSQL(int mode)
    {
        if (sql == null)
        {
            sql = new StringBuffer();
            if (encloseInParentheses)
            {
                sql.append("(");
            }
            for (int i = 0; i < appended.size(); i++)
            {
                Object item = appended.get(i);
                if (item instanceof SQLExpression)
                {
                    SQLExpression expr = (SQLExpression) item;
                    SQLText st = expr.toSQL(mode);
                    sql.append(st.toSQL(mode));

                    if (st.parameters != null)
                    {
                        if (parameters == null)
                        {
                            parameters = new ArrayList();
                        }
                        parameters.addAll(st.parameters);
                    }
                }
                else if (item instanceof Parameter)
                {
                    Parameter param = (Parameter) item;
                    sql.append('?');

                    if (parameters == null)
                    {
                        parameters = new ArrayList();
                    }
                    parameters.add(param);
                }
                else if (item instanceof SQLStatement)
                {
                    SQLStatement stmt = (SQLStatement) item;
                    SQLText st = stmt.getSelectStatement();
                    sql.append(st.toSQL(mode));
                    if (st.parameters != null)
                    {
                        if (parameters == null)
                        {
                            parameters = new ArrayList();
                        }
                        parameters.addAll(st.parameters);
                    }
                }
                else if (item instanceof SQLText)
                {
                    SQLText st = (SQLText) item;
                    sql.append(st.toSQL(mode));
                    if (st.parameters != null)
                    {
                        if (parameters == null)
                        {
                            parameters = new ArrayList();
                        }
                        parameters.addAll(st.parameters);
                    }
                }
                else
                {
                    sql.append(item);
                }
            }
            if (encloseInParentheses)
            {
                sql.append(")");
            }
            sql.append((postpend == null ? "" : postpend));
        }
        return sql.toString();
    }

    /**
     * Accessor for the string form of the statement.
     * @return String form of the statement
     */
    public String toString()
    {
        //the mode should be indifferent, so we use SELECT
        return toSQL(SQLExpression.SQL_USE_SELECT);
    }

    /**
     * Internal class to keep parameters
     */
    private class Parameter
    {
        final JavaTypeMapping mapping;
        final Object value;

        public Parameter(JavaTypeMapping mapping, Object value)
        {
            this.mapping = mapping;
            this.value = value;
        }
    }
}