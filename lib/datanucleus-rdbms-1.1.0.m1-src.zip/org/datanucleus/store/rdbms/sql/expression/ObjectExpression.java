/**********************************************************************
Copyright (c) 2008 Andy Jefferson and others. All rights reserved.
Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.

Contributors:
    ...
**********************************************************************/
package org.datanucleus.store.rdbms.sql.expression;

import java.util.ArrayList;
import java.util.List;

import org.datanucleus.query.expression.Expression;
import org.datanucleus.store.mapped.mapping.BigDecimalMapping;
import org.datanucleus.store.mapped.mapping.BigIntegerMapping;
import org.datanucleus.store.mapped.mapping.BooleanMapping;
import org.datanucleus.store.mapped.mapping.ByteMapping;
import org.datanucleus.store.mapped.mapping.CharacterMapping;
import org.datanucleus.store.mapped.mapping.DateMapping;
import org.datanucleus.store.mapped.mapping.DoubleMapping;
import org.datanucleus.store.mapped.mapping.FloatMapping;
import org.datanucleus.store.mapped.mapping.IntegerMapping;
import org.datanucleus.store.mapped.mapping.JavaTypeMapping;
import org.datanucleus.store.mapped.mapping.LongMapping;
import org.datanucleus.store.mapped.mapping.ShortMapping;
import org.datanucleus.store.mapped.mapping.SqlDateMapping;
import org.datanucleus.store.mapped.mapping.SqlTimeMapping;
import org.datanucleus.store.mapped.mapping.SqlTimestampMapping;
import org.datanucleus.store.mapped.mapping.StringMapping;
import org.datanucleus.store.rdbms.sql.SQLStatement;
import org.datanucleus.store.rdbms.sql.SQLTable;
import org.datanucleus.store.rdbms.table.Column;

/**
 * Representation of an Object expression in a Query. Typically represents a persistable object,
 * and so its identity. Has a List of expressions effectively representing the object identity.
 * Let's take an example :-
 * <PRE>
 * We have classes A and B, and A contains a reference to B "b". If we do a JDOQL query for class A 
 * of "b.someField == value" then "b" is interpreted first and an ObjectExpression is created to represent
 * that object (of type B).
 * </PRE>
 */
public class ObjectExpression extends SQLExpression
{
    /** Sub-expressions that represents this object. */
    private List<SQLExpression> expressions = new ArrayList();

    /**
     * Constructor for an SQL expression for a (field) mapping in a specified table.
     * @param stmt The statement
     * @param table The table in the statement
     * @param mapping The mapping for the field
     */
    public ObjectExpression(SQLStatement stmt, SQLTable table, JavaTypeMapping mapping)
    {
        super(stmt, table, mapping);
        for (int i=0; i<mapping.getNumberOfDatastoreFields(); i++)
        {
            ColumnExpression colExpr = 
                new ColumnExpression(stmt, table, (Column)mapping.getDataStoreMapping(i).getDatastoreField());
            expressions.add(colExpr);
        }
    }

    /**
     * Cast operator. Called when the query contains "(type)obj" where "obj" is this object.
     * @param castType The type we cast this object to
     * @return Scalar expression representing the cast object.
     */
    public SQLExpression cast(Class castType)
    {
        // TODO Implement this
        return null;
    }

    /**
     * Equals operator. Called when the query contains "obj == value" where "obj" is this object.
     * @param expr The expression we compare with (the right-hand-side in the query)
     * @return Boolean expression representing the comparison.
     */
    public BooleanExpression eq(SQLExpression expr)
    {
        BooleanExpression bExpr = null;
        if (expr instanceof NullLiteral)
        {
            for (int i=0;i<expressions.size();i++)
            {
                SQLExpression sourceExpr = expressions.get(i);
                if (bExpr == null)
                {
                    bExpr = expr.eq(sourceExpr);
                }
                else
                {
                    bExpr = bExpr.and(expr.eq(sourceExpr));
                }
            }
        }
        else if (literalIsValidForSimpleComparison(expr))
        {
            if (this.expressions.size() > 1)
            {
                // More than 1 value to compare with a literal!
                bExpr = super.eq(expr);
            }
            else
            {
                // Just do a direct comparison with the basic literals
                bExpr = new BooleanExpression(this, Expression.OP_EQ, expr);
            }
        }
        else if (expr instanceof ObjectLiteral)
        {
            bExpr = expr.eq(this);
        }
        else if (expr instanceof ObjectExpression)
        {
            for (int i=0;i<expressions.size();i++)
            {
                SQLExpression sourceExpr = expressions.get(i);
                SQLExpression targetExpr = ((ObjectExpression)expr).expressions.get(i);
                if (bExpr == null)
                {
                    bExpr = sourceExpr.eq(targetExpr);
                }
                else
                {
                    bExpr = bExpr.and(sourceExpr.eq(targetExpr));
                }
            }
        }
        /*else if (expr instanceof UnboundVariable)
        {
            if (((UnboundVariable)expr).getVariableType() == null)
            {
                // Set the variable type to this objects type
                ((UnboundVariable)expr).setVariableType(qs.getClassLoaderResolver().classForName(fieldType));
            }
            bExpr = expr.eq(this);
        }*/
        else
        {
            bExpr = super.eq(expr);
        }

        return bExpr;
    }

    /**
     * Not equals operator. Called when the query contains "obj != value" where "obj" is this object.
     * @param expr The expression we compare with (the right-hand-side in the query)
     * @return Boolean expression representing the comparison.
     */
    public BooleanExpression ne(SQLExpression expr)
    {
        BooleanExpression bExpr = null;
        if (expr instanceof NullLiteral)
        {
            for (int i=0;i<expressions.size();i++)
            {
                SQLExpression sourceExpr = expressions.get(i);
                if (bExpr == null)
                {
                    bExpr = expr.eq(sourceExpr);
                }
                else
                {
                    bExpr = bExpr.and(expr.eq(sourceExpr));
                }
            }
            bExpr = new BooleanExpression(Expression.OP_NOT, bExpr.encloseInParentheses());
        }
        else if (literalIsValidForSimpleComparison(expr))
        {
            if (expressions.size() > 1)
            {
                // More than 1 value to compare with a literal!
                bExpr = super.ne(expr);
            }
            else
            {
                // Just do a direct comparison with the basic literals
                bExpr = new BooleanExpression(this, Expression.OP_NOTEQ, expr);
            }
        }
        else if (expr instanceof ObjectLiteral)
        {
            bExpr = expr.ne(this);
        }
        else if (expr instanceof ObjectExpression)
        {
            for (int i=0;i<expressions.size();i++)
            {
                SQLExpression sourceExpr = expressions.get(i);
                SQLExpression targetExpr = ((ObjectExpression)expr).expressions.get(i);
                if (bExpr == null)
                {
                    bExpr = sourceExpr.eq(targetExpr);
                }
                else
                {
                    bExpr = bExpr.and(sourceExpr.eq(targetExpr));
                }
            }
            bExpr = new BooleanExpression(Expression.OP_NOT, bExpr.encloseInParentheses());
        }
        /*else if (expr instanceof UnboundVariable)
        {
            if (((UnboundVariable)expr).getVariableType() == null)
            {
                // Set the variable type to this objects type
                ((UnboundVariable)expr).setVariableType(qs.getClassLoaderResolver().classForName(fieldType));
            }
            bExpr = expr.noteq(this);
        }*/
        else
        {
            bExpr = super.ne(expr);
        }

        return bExpr;
    }

    /**
     * Convenience method to return if this object is valid for simple comparison
     * with the passed expression. Performs a type comparison of the object and the expression
     * for compatibility. The expression must be a literal of a suitable type for simple
     * comparison (e.g where this object is a String, and the literal is a StringLiteral).
     * @param expr The expression
     * @return Whether a simple comparison is valid
     */
    private boolean literalIsValidForSimpleComparison(SQLExpression expr)
    {
        // Our mapping is a single field type and is of the same basic type as the expression
        if ((expr instanceof BooleanLiteral && (mapping instanceof BooleanMapping)) ||
            (expr instanceof ByteLiteral && (mapping instanceof ByteMapping)) ||
            (expr instanceof CharacterLiteral && (mapping instanceof CharacterMapping)) ||
            (expr instanceof FloatingPointLiteral && 
             (mapping instanceof FloatMapping || mapping instanceof DoubleMapping ||
              mapping instanceof BigDecimalMapping)) ||
            (expr instanceof IntegerLiteral &&
             (mapping instanceof IntegerMapping || mapping instanceof LongMapping ||
              mapping instanceof BigIntegerMapping) || mapping instanceof ShortMapping) ||
            (expr instanceof TemporalLiteral &&
             (mapping instanceof DateMapping || mapping instanceof SqlDateMapping || 
              mapping instanceof SqlTimeMapping || mapping instanceof SqlTimestampMapping)) ||
            (expr instanceof StringLiteral &&
             (mapping instanceof StringMapping || mapping instanceof CharacterMapping)))
        {
            return true;
        }

        return false;
    }

    public BooleanExpression in(SQLExpression expr) 
    {
        return new BooleanExpression(this, Expression.OP_IN, expr);
    }

    /**
     * Access a field in the object that this expression represents.
     * If the field is contained in a different table then will use the "innerJoin" input parameter
     * and make a join to the required table. If the field is a 1-1 relation and the current table holds the FK
     * then no join will be made.
     * @param subfieldName the field to be accessed in this object
     * @param innerJoin whether to inner join
     * @return The field expression representing the required field of this object
     */
    public SQLExpression accessField(String subfieldName, boolean innerJoin)
    {
        // TODO Implement this
        return null;
    }

    /**
     * Method to return a constraint for restricting the field to just instances of a particular class.
     * @param expr Expression for the class that we want instances of (a ClassExpression).
     * @return The expression for the instanceof clause
     */
    public BooleanExpression instanceOf(SQLExpression expr)
    {
        // TODO Implement this
        return null;
    }
}