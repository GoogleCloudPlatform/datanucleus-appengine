/**********************************************************************
Copyright (c) 2008 Andy Jefferson and others. All rights reserved.
Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.

Contributors:
    ...
**********************************************************************/
package org.datanucleus.store.rdbms.sql.expression;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;

import org.datanucleus.exceptions.NucleusException;
import org.datanucleus.store.mapped.DatastoreAdapter;
import org.datanucleus.store.mapped.mapping.JavaTypeMapping;
import org.datanucleus.store.rdbms.RDBMSManager;
import org.datanucleus.store.rdbms.sql.SQLStatement;

/**
 * An SQL expression that will test if a column of a table falls within the given Collection of values.
 * This is used for queries where a transient Collection is passed in as a parameter.
 */
public class CollectionLiteral extends SQLExpression implements SQLLiteral
{
    private final Collection value;

    private final boolean isEmpty;
    private final boolean containsNull;

    /** ScalarExpressions for all elements in the Collection **/ 
    private List scalarExpressions;

    /**
     * Constructor.
     * @param stmt SQL statement
     * @param mapping The mapping to the Collection
     * @param value The transient Collection that is the value.
     */
    public CollectionLiteral(SQLStatement stmt, JavaTypeMapping mapping, Object value)
    {
        super(stmt, null, mapping);

        if (value instanceof Collection)
        {
            Collection collValue = (Collection)value;
            this.value = collValue;
            containsNull = (collValue != null) && collValue.contains(null);

            // We'll consider the Collection to be empty if it is null, is really empty, or only 
            // contains null. If it contains null we need a special case when creating the SQL.
            isEmpty = (collValue == null) || (collValue.isEmpty()) || (collValue.size() == 1 && containsNull);

            // If the Collection is empty, don't build the list of SQLExpressions.
            if (!isEmpty)
            {
                RDBMSManager storeMgr = stmt.getRDBMSManager();
                DatastoreAdapter dba = storeMgr.getDatastoreAdapter();
                scalarExpressions = new ArrayList();
                st.append("(");

                boolean hadPrev = false;

                for (Iterator it=collValue.iterator(); it.hasNext();)
                {
                    Object current = it.next();
                    if (current != null)
                    {
                        JavaTypeMapping m = dba.getMapping(current.getClass(), storeMgr,
                            storeMgr.getOMFContext().getClassLoaderResolver(null));
                        SQLExpression expr = storeMgr.getSQLExpressionFactory().newLiteral(stmt, m, current);

                        // Append the SQLExpression (should be a literal) for the current element.
                        st.append(hadPrev ? "," : "");
                        st.append(expr);
                        scalarExpressions.add(expr);

                        hadPrev = true;
                    }
                }

                st.append(")");
            }
        }
        else
        {
            throw new NucleusException("Cannot create " + this.getClass().getName() + 
                " for value of type " + (value != null ? value.getClass().getName() : null));
        }
    }

    public SQLExpression invoke(String methodName, List args)
    {
        if (methodName.equals("isEmpty") && args.size() == 0)
        {
            // Collection.isEmpty()
            return new BooleanLiteral(stmt, mapping, isEmpty);
        }
        else if (methodName.equals("size"))
        {
            // Collection.size()
            DatastoreAdapter dba = stmt.getRDBMSManager().getDatastoreAdapter();
            JavaTypeMapping m = dba.getMapping(Integer.class, stmt.getRDBMSManager());
            return new IntegerLiteral(stmt, m, new Integer(value.size()));
        }
        else if (methodName.equals("contains") && args.size() == 1)
        {
            // Collection.contains(expr)
            if (isEmpty)
            {
                return new BooleanLiteral(stmt, mapping, Boolean.FALSE);
            }

            SQLExpression argExpr = (SQLExpression)args.get(0);
            BooleanExpression bExpr = null;
            for (int i=0; i<scalarExpressions.size(); i++)
            {
                if (bExpr == null)
                {
                    bExpr = ((SQLExpression)scalarExpressions.get(i)).eq(argExpr); 
                }
                else
                {
                    bExpr = bExpr.ior(((SQLExpression)scalarExpressions.get(i)).eq(argExpr)); 
                }
            }
            bExpr.encloseInParentheses();
            return bExpr;
        }

        return super.invoke(methodName, args);
    }

    /* (non-Javadoc)
     * @see org.datanucleus.store.rdbms.sql.expression.SQLLiteral#getValue()
     */
    public Object getValue()
    {
        return value;
    }

    /* (non-Javadoc)
     * @see org.datanucleus.store.rdbms.sql.expression.SQLLiteral#getRawValue()
     */
    public Object getRawValue()
    {
        return null;
    }

    /* (non-Javadoc)
     * @see org.datanucleus.store.rdbms.sql.expression.SQLLiteral#setRawValue(java.lang.Object)
     */
    public void setRawValue(Object val)
    {
    }
}