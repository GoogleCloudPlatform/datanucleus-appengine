/**********************************************************************
Copyright (c) 2008 Andy Jefferson and others. All rights reserved.
Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.

Contributors:
    ...
**********************************************************************/
package org.datanucleus.store.rdbms.sql.expression;

import java.lang.reflect.Field;
import java.math.BigInteger;
import java.security.AccessController;
import java.security.PrivilegedAction;
import java.util.ArrayList;

import org.datanucleus.ObjectManager;
import org.datanucleus.ObjectManagerHelper;
import org.datanucleus.StateManager;
import org.datanucleus.exceptions.NucleusException;
import org.datanucleus.exceptions.NucleusUserException;
import org.datanucleus.metadata.AbstractMemberMetaData;
import org.datanucleus.store.fieldmanager.FieldManager;
import org.datanucleus.store.fieldmanager.SingleValueFieldManager;
import org.datanucleus.store.mapped.mapping.JavaTypeMapping;
import org.datanucleus.store.rdbms.RDBMSManager;
import org.datanucleus.store.rdbms.adapter.DatabaseAdapter;
import org.datanucleus.store.rdbms.sql.SQLStatement;

/**
 * Utility methods for working with SQL expressions.
 */
public class ExpressionUtils
{
    /**
     * Method to return a numeric expression for the supplied SQL expression.
     * Makes use of the RDBMS function to convert to a numeric.
     * @param expr The expression
     * @return The numeric expression for this SQL expression
     */
    public static NumericExpression getNumericExpression(SQLExpression expr)
    {
        RDBMSManager storeMgr = expr.getSQLStatement().getRDBMSManager();
        SQLExpressionFactory factory = storeMgr.getSQLExpressionFactory();
        DatabaseAdapter dba = expr.getSQLStatement().getDatabaseAdapter();
        if (expr instanceof CharacterLiteral)
        {
            char c = ((Character)((CharacterLiteral)expr).getValue()).charValue();
            BigInteger value = new BigInteger("" + (int)c);
            return (NumericExpression)factory.newLiteral(expr.getSQLStatement(), 
                storeMgr.getMappingManager().getMapping(value.getClass()), value);
        }
        else if (expr instanceof SQLLiteral)
        {
            BigInteger value = new BigInteger((String)((SQLLiteral)expr).getValue());
            return (NumericExpression)factory.newLiteral(expr.getSQLStatement(), 
                storeMgr.getMappingManager().getMapping(value.getClass()), value);
        }

        ArrayList args = new ArrayList();
        args.add(expr);
        return new NumericExpression(dba.getNumericConversionFunction(), args);
    }

    /**
     * Get the value of a field from the passed object.
     * @param pc the pc object
     * @param fmd metadata for the field/property
     * @return The field value
     */
    public static Object getFieldValue(Object pc, AbstractMemberMetaData fmd)
    {
        ObjectManager om = ObjectManagerHelper.getObjectManager(pc);
        if (om == null)
        {
            // Not currently managed so use reflection
            Object fieldValue;
            final Field field = getDeclaredFieldPrivileged(pc.getClass(), fmd.getName());
            if (field == null)
            {
                throw new NucleusUserException("Cannot access field: " + fmd.getName() + " in type " + pc.getClass());
            }

            try
            {
                // if the field is not accessible, try to set the accessible flag.
                if (!field.isAccessible())
                {
                    try
                    {
                        AccessController.doPrivileged(
                            new PrivilegedAction()
                            {
                                public Object run()
                                {
                                    field.setAccessible(true);
                                    return null;
                                }
                            });
                    }
                    catch (SecurityException ex)
                    {
                        throw new NucleusException("Cannot access field: " + fmd.getName(),ex).setFatal();
                    }
                }
                fieldValue = field.get(pc);
            }
            catch (IllegalArgumentException e2)
            {
                throw new NucleusUserException("Cannot access field: " + fmd.getName(),e2);
            }
            catch (IllegalAccessException e2)
            {
                throw new NucleusUserException("Cannot access field: " + fmd.getName(),e2);
            }
            return fieldValue;
        }

        // Managed object so access via the StateManager
        StateManager sm = om.findStateManager(pc);
        FieldManager fm = new SingleValueFieldManager();
        if (!fmd.isPrimaryKey())
        {
            // we expect that primary key field are non null
            om.getApiAdapter().isLoaded(sm, fmd.getAbsoluteFieldNumber());
        }
        sm.provideFields(new int[] {fmd.getAbsoluteFieldNumber()},fm);

        return fm.fetchObjectField(fmd.getAbsoluteFieldNumber());
    }

    /**
     * Helper method to retrieve the java.lang.reflect.Field for the named field.
     * @param cls the Class instance of the declaring class or interface
     * @param fieldName the field name
     * @return The field
     */
    private static Field getDeclaredFieldPrivileged(final Class cls, final String fieldName)
    {
        if ((cls == null) || (fieldName == null))
        {
            return null;
        }

        return (Field) AccessController.doPrivileged(
            new PrivilegedAction()
            {
                public Object run ()
                {
                    Class seekingClass = cls;
                    do
                    {
                        try
                        {
                            return seekingClass.getDeclaredField(fieldName);
                        }
                        catch (SecurityException ex)
                        {
                            throw new NucleusException("CannotGetDeclaredField",ex).setFatal();
                        }
                        catch (NoSuchFieldException ex)
                        {
                            // do nothing, we will return null later if no 
                            // field is found in this class or superclasses
                        }
                        catch (LinkageError ex)
                        {
                            throw new NucleusException("ClassLoadingError",ex).setFatal();
                        }
                        seekingClass = seekingClass.getSuperclass();
                    } while(seekingClass != null);

                    //no field found
                    return null;
                }
            }
            );
    }

    /**
     * Convenience accessor for a literal for the number 1.
     * @param stmt The SQL statement
     * @return The literal
     */
    public static SQLExpression getLiteralForOne(SQLStatement stmt)
    {
        RDBMSManager storeMgr = stmt.getRDBMSManager();
        JavaTypeMapping mapping = storeMgr.getMappingManager().getMapping(BigInteger.class);
        return storeMgr.getSQLExpressionFactory().newLiteral(stmt, mapping, BigInteger.ONE);
    }
}