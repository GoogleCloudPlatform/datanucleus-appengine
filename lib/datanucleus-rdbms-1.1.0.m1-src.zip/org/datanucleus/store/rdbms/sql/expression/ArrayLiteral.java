/**********************************************************************
Copyright (c) 2008 Andy Jefferson and others. All rights reserved.
Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.

Contributors:
    ...
**********************************************************************/
package org.datanucleus.store.rdbms.sql.expression;

import java.lang.reflect.Array;
import java.util.List;

import org.datanucleus.exceptions.NucleusUserException;
import org.datanucleus.store.mapped.mapping.JavaTypeMapping;
import org.datanucleus.store.rdbms.sql.SQLStatement;

/**
 * Representation of array literal.
 */
public class ArrayLiteral extends ArrayExpression implements SQLLiteral
{
    /** value of the array **/
    Object value;

    /**
     * Constructor.
     * @param stmt The SQL statement
     * @param mapping the mapping to use
     * @param literal the array value
     */
    public ArrayLiteral(SQLStatement stmt, JavaTypeMapping mapping, Object literal)
    {
        super(stmt, null, mapping);

        this.value = literal;
        if (value == null || !value.getClass().isArray())
        {
            throw new NucleusUserException("Invalid argument literal : " + value);
        }
    }

    public SQLExpression invoke(String methodName, List args)
    {
        if (methodName.equals("size"))
        {
            // {array}.size()
            JavaTypeMapping m = stmt.getRDBMSManager().getMappingManager().getMapping(Integer.class);
            return new IntegerLiteral(stmt, m, new Integer(Array.getLength(value)));
        }

        return super.invoke(methodName, args);
    }

    /* (non-Javadoc)
     * @see org.datanucleus.store.rdbms.sql.expression.SQLLiteral#getValue()
     */
    public Object getValue()
    {
        return value;
    }

    /* (non-Javadoc)
     * @see org.datanucleus.store.rdbms.sql.expression.SQLLiteral#getRawValue()
     */
    public Object getRawValue()
    {
        return null;
    }

    /* (non-Javadoc)
     * @see org.datanucleus.store.rdbms.sql.expression.SQLLiteral#setRawValue(java.lang.Object)
     */
    public void setRawValue(Object val)
    {
    }
}