/**********************************************************************
Copyright (c) 2008 Andy Jefferson and others. All rights reserved.
Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.

Contributors:
    ...
**********************************************************************/
package org.datanucleus.store.rdbms.sql.expression;

import java.util.Calendar;
import java.util.Date;
import java.util.List;

import org.datanucleus.exceptions.NucleusException;
import org.datanucleus.store.mapped.DatastoreAdapter;
import org.datanucleus.store.mapped.mapping.JavaTypeMapping;
import org.datanucleus.store.rdbms.sql.SQLStatement;

/**
 * Representation of temporal literal in a Query.
 * Can be used for anything based on java.util.Date.
 */
public class TemporalLiteral extends TemporalExpression implements SQLLiteral
{
    private final Date value;

    /** Raw value that this literal represents. */
    Object rawValue;

    /**
     * Creates a temporal literal.
     * @param stmt the SQL statement
     * @param mapping the mapping
     * @param value the value
     */
    public TemporalLiteral(SQLStatement stmt, JavaTypeMapping mapping, Object value)
    {
        super(stmt, null, mapping);

        if (value instanceof Date)
        {
            this.value = (Date)value;
        }
        else
        {
            throw new NucleusException("Cannot create " + this.getClass().getName() + 
                " for value of type " + (value != null ? value.getClass().getName() : null));
        }

        st.appendParameter(mapping, this.value);
    }

    public String toString()
    {
        return super.toString() + " = " + value.toString();
    }

    public SQLExpression invoke(String methodName, List args)
    {
        if (methodName.equals("getDay"))
        {
            // Date.getDay()
            Calendar cal = Calendar.getInstance();
            cal.setTime(value);
            DatastoreAdapter dba = stmt.getRDBMSManager().getDatastoreAdapter();
            JavaTypeMapping m = dba.getMapping(Integer.class, stmt.getRDBMSManager());
            return new IntegerLiteral(stmt, m, new Integer(cal.get(Calendar.DAY_OF_MONTH)));
        }
        else if (methodName.equals("getMonth"))
        {
            // Date.getMonth()
            Calendar cal = Calendar.getInstance();
            cal.setTime(value);
            DatastoreAdapter dba = stmt.getRDBMSManager().getDatastoreAdapter();
            JavaTypeMapping m = dba.getMapping(Integer.class, stmt.getRDBMSManager());
            return new IntegerLiteral(stmt, m, new Integer(cal.get(Calendar.MONTH)));
        }
        else if (methodName.equals("getYear"))
        {
            // Date.getMonth()
            Calendar cal = Calendar.getInstance();
            cal.setTime(value);
            DatastoreAdapter dba = stmt.getRDBMSManager().getDatastoreAdapter();
            JavaTypeMapping m = dba.getMapping(Integer.class, stmt.getRDBMSManager());
            return new IntegerLiteral(stmt, m, new Integer(cal.get(Calendar.YEAR)));
        }
        else if (methodName.equals("getHour"))
        {
            // Date.getHour()
            Calendar cal = Calendar.getInstance();
            cal.setTime(value);
            DatastoreAdapter dba = stmt.getRDBMSManager().getDatastoreAdapter();
            JavaTypeMapping m = dba.getMapping(Integer.class, stmt.getRDBMSManager());
            return new IntegerLiteral(stmt, m, new Integer(cal.get(Calendar.HOUR_OF_DAY)));
        }
        else if (methodName.equals("getMinutes"))
        {
            // Date.getMinutes()
            Calendar cal = Calendar.getInstance();
            cal.setTime(value);
            DatastoreAdapter dba = stmt.getRDBMSManager().getDatastoreAdapter();
            JavaTypeMapping m = dba.getMapping(Integer.class, stmt.getRDBMSManager());
            return new IntegerLiteral(stmt, m, new Integer(cal.get(Calendar.MINUTE)));
        }
        else if (methodName.equals("getSeconds"))
        {
            // Date.getMinutes()
            Calendar cal = Calendar.getInstance();
            cal.setTime(value);
            DatastoreAdapter dba = stmt.getRDBMSManager().getDatastoreAdapter();
            JavaTypeMapping m = dba.getMapping(Integer.class, stmt.getRDBMSManager());
            return new IntegerLiteral(stmt, m, new Integer(cal.get(Calendar.SECOND)));
        }

        return super.invoke(methodName, args);
    }

    public Object getValue()
    {
        return value;
    }

    /**
     * Method to save a "raw" value that this literal represents.
     * This value differs from the literal value since that is of the same type as this literal.
     * @param val The raw value
     */
    public void setRawValue(Object val)
    {
        this.rawValue = val;
    }

    /**
     * Accessor for the "raw" value that this literal represents.
     * This value differs from the literal value since that is of the same type as this literal.
     * @return The raw value
     */
    public Object getRawValue()
    {
        return rawValue;
    }
}