/**********************************************************************
Copyright (c) 2008 Andy Jefferson and others. All rights reserved.
Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.

Contributors:
    ...
**********************************************************************/
package org.datanucleus.store.rdbms.sql.expression;

import org.datanucleus.exceptions.NucleusException;
import org.datanucleus.store.mapped.DatastoreAdapter;
import org.datanucleus.store.mapped.mapping.DatastoreMapping;
import org.datanucleus.store.mapped.mapping.JavaTypeMapping;
import org.datanucleus.store.rdbms.sql.SQLStatement;

/**
 * Representation of a Boolean literal in a Query.
 */
public class BooleanLiteral extends BooleanExpression implements SQLLiteral
{
    private final boolean value;

    /** Raw value that this literal represents (optional). */
    Object rawValue;

    /**
     * Creates a boolean literal with the specified value, using the provided mapping.
     * @param stmt The SQL statement
     * @param mapping the mapping
     * @param value the value
     */
    public BooleanLiteral(SQLStatement stmt, JavaTypeMapping mapping, Object value)
    {
        super(stmt, null, mapping);

        if (value instanceof Boolean)
        {
            this.value = ((Boolean)value).booleanValue();
        }
        else
        {
            throw new NucleusException("Cannot create " + this.getClass().getName() + 
                " for value of type " + (value != null ? value.getClass().getName() : null));
        }

        DatastoreMapping datastoreMapping = mapping.getDataStoreMapping(0);
        if (datastoreMapping.isStringBased())
        {
            // Persisted using "Y", "N"
            st.append(this.value ? "'Y'" : "'N'");
        }
        else if ((datastoreMapping.isBitBased() || datastoreMapping.isIntegerBased()) &&
                !stmt.getDatabaseAdapter().supportsOption(DatastoreAdapter.BIT_IS_REALLY_BOOLEAN))
        {
            // Persisted using "1", "0"
            st.append(this.value ? "1" : "0");
        }
        else
        {
            st.append(this.value ? "TRUE" : "(1=0)");
        }
    }

    public Object getValue()
    {
        return new Boolean(value);
    }

    public BooleanExpression and(SQLExpression expr)
    {
        if (expr instanceof BooleanExpression)
        {
            return value ? (BooleanExpression)expr : this;
        }
        else
        {
            return super.and(expr);
        }
    }

    public BooleanExpression eor(SQLExpression expr)
    {
        if (expr instanceof BooleanExpression)
        {
            return value ? expr.not() : (BooleanExpression)expr;
        }
        else
        {
            return super.eor(expr);
        }
    }

    public BooleanExpression ior(SQLExpression expr)
    {
        if (expr instanceof BooleanExpression)
        {
            return value ? this : (BooleanExpression)expr;
        }
        else
        {
            return super.ior(expr);
        }
    }

    public BooleanExpression not()
    {
        return new BooleanLiteral(stmt, mapping, !value);
    }

    public BooleanExpression eq(SQLExpression expr)
    {
//        assertValidTypeForParameterComparison(expr, BooleanExpression.class);

        if (expr instanceof BooleanExpression)
        {
            return value ? (BooleanExpression)expr : expr.not();
        }
        else
        {
            return super.eq(expr);
        }
    }

    public BooleanExpression ne(SQLExpression expr)
    {
//        assertValidTypeForParameterComparison(expr, BooleanExpression.class);

        if (expr instanceof BooleanExpression)
        {
            return value ? expr.not() : (BooleanExpression)expr;
        }
        else
        {
            return super.ne(expr);
        }
    }

    /**
     * Method to save a "raw" value that this literal represents.
     * This value differs from the literal value since that is of the same type as this literal.
     * @param val The raw value
     */
    public void setRawValue(Object val)
    {
        this.rawValue = val;
    }

    /**
     * Accessor for the "raw" value that this literal represents.
     * This value differs from the literal value since that is of the same type as this literal.
     * @return The raw value
     */
    public Object getRawValue()
    {
        return rawValue;
    }
}