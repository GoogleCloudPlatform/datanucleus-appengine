/**********************************************************************
Copyright (c) 2008 Andy Jefferson and others. All rights reserved. 
Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.

Contributors:
    ...
**********************************************************************/
package org.datanucleus.store.rdbms.sql.expression;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.datanucleus.exceptions.NucleusException;
import org.datanucleus.store.mapped.DatastoreAdapter;
import org.datanucleus.store.mapped.mapping.JavaTypeMapping;
import org.datanucleus.store.rdbms.RDBMSManager;
import org.datanucleus.store.rdbms.sql.SQLStatement;

/**
 * An SQL expression that will test if a column of a table falls within the given Map. 
 * This is used for queries where a Map is passed in as a parameter.
 */
public class MapLiteral extends SQLExpression implements SQLLiteral
{
    private final Map value;

    private final boolean isEmpty;
    private final boolean containsNull;

    private final MapValueLiteral mapValueLiteral;
    private final MapKeyLiteral mapKeyLiteral; 

    /**
     * Constructor.
     * @param stmt  The SQLStatement the MapLiteral will be used in.
     * @param mapping The mapping to the Map
     * @param value The Map that is the value.
     */
    public MapLiteral(SQLStatement stmt, JavaTypeMapping mapping, Object value)
    {
        super(stmt, null, mapping);

        if (value instanceof Map)
        {
            Map mapValue = (Map)value;
            this.value = mapValue;

            mapValueLiteral = new MapValueLiteral(stmt, mapping, value);
            mapKeyLiteral = new MapKeyLiteral(stmt, mapping, value);

            containsNull = (mapValue != null) && mapValue.containsValue(null);

            // We'll consider the Map to be empty if it is null, is really empty, or only contains null. 
            // If it contains null we need a special case when creating the SQL.
            isEmpty = (mapValue == null) || (mapValue.isEmpty()) || (mapValue.size() == 1 && containsNull);
        }
        else
        {
            throw new NucleusException("Cannot create " + this.getClass().getName() + 
                " for value of type " + (value != null ? value.getClass().getName() : null));
        }
    }

    public SQLExpression invoke(String methodName, List args)
    {
        if (methodName.equals("isEmpty") && args.size() == 0)
        {
            // Map.isEmpty()
            return new BooleanLiteral(stmt, mapping, isEmpty ? Boolean.TRUE : Boolean.FALSE);
        }
        else if (methodName.equals("size"))
        {
            // Map.size()
            DatastoreAdapter dba = stmt.getRDBMSManager().getDatastoreAdapter();
            JavaTypeMapping m = dba.getMapping(Integer.class, stmt.getRDBMSManager());
            return new IntegerLiteral(stmt, m, new Integer(value.size()));
        }
        else if (methodName.equals("containsKey"))
        {
            // Map.containsKey(expr)
            if (isEmpty)
            {
                return new BooleanLiteral(stmt, mapping, Boolean.FALSE);
            }
            return mapKeyLiteral.invoke("contains", args);
        }
        else if (methodName.equals("containsValue"))
        {
            // Map.containsValue(expr)
            if (isEmpty)
            {
                return new BooleanLiteral(stmt, mapping, Boolean.FALSE);
            }
            return mapValueLiteral.invoke("contains", args);
        }
        else if (methodName.equals("containsEntry"))
        {
            // Map.containsEntry(expr)
            // TODO When comparing an entry we should split out key and value and pass in to these
            // methods separately
//          return mapKeyLiteral.invoke("contains", args).and(mapValueLiteral.invoke("contains", args));
        }
        else if (methodName.equals("get"))
        {
            // Map.get(expr)
            if (value == null)
            {
                return new NullLiteral(stmt, null, null);
            }
            return mapKeyLiteral.invoke("get", args);
        }

        // TODO Implement methods (size, length, contains)
        return super.invoke(methodName, args);
    }

    /* (non-Javadoc)
     * @see org.datanucleus.store.rdbms.sql.expression.SQLLiteral#getValue()
     */
    public Object getValue()
    {
        return value;
    }

    /* (non-Javadoc)
     * @see org.datanucleus.store.rdbms.sql.expression.SQLLiteral#getRawValue()
     */
    public Object getRawValue()
    {
        return null;
    }

    /* (non-Javadoc)
     * @see org.datanucleus.store.rdbms.sql.expression.SQLLiteral#setRawValue(java.lang.Object)
     */
    public void setRawValue(Object val)
    {
    }

    /**
     * An SQL expression that will test if a column of a table falls within the given Map's keys.
     */
    class MapKeyLiteral extends SQLExpression implements SQLLiteral
    {
        private final Map value;

        /** ScalarExpressions for all elements in the Map **/ 
        private List scalarExpressions;
        
        /**
         * Constructor.
         * @param stmt SQL statement
         * @param mapping The mapping for the Map
         * @param value The transient Map that is the value.
         */
        public MapKeyLiteral(SQLStatement stmt, JavaTypeMapping mapping, Object value)
        {
            super(stmt, null, mapping);

            if (value instanceof Map)
            {
                Map mapValue = (Map)value;
                this.value = mapValue;

                // We'll consider the Map to be empty if it is null, is really
                // empty, or only contains null. 
                // If it contains null we need a special case when creating the SQL.
                boolean isEmpty = 
                    (mapValue == null) || (mapValue.isEmpty()) || (mapValue.size() == 1 && containsNull);

                // If the Map is empty, don't build the list of SQLExpressions.
                if (!isEmpty)
                {
                    RDBMSManager storeMgr = stmt.getRDBMSManager();
                    DatastoreAdapter dba = storeMgr.getDatastoreAdapter();
                    st.append("(");
                    scalarExpressions = new ArrayList();

                    boolean hadPrev = false;

                    Set keys = mapValue.keySet();
                    for (Iterator it=keys.iterator(); it.hasNext();)
                    {
                        Object current = it.next();
                        if (null != current)
                        {
                            JavaTypeMapping m = dba.getMapping(current.getClass(), storeMgr,
                                storeMgr.getOMFContext().getClassLoaderResolver(null));
                            SQLExpression expr = storeMgr.getSQLExpressionFactory().newLiteral(stmt, m, current);

                            // Append the SQLExpression (should be a literal) for the current element.
                            st.append(hadPrev ? "," : "");
                            st.append(expr);
                            scalarExpressions.add(expr);

                            hadPrev = true;
                        }
                    }

                    st.append(")");
                }
            }
            else
            {
                throw new NucleusException("Cannot create " + this.getClass().getName() + 
                    " for value of type " + (value != null ? value.getClass().getName() : null));
            }
        }

        public SQLExpression invoke(String methodName, List args)
        {
            if (methodName.equals("contains") && args.size() == 1)
            {
                // Map.containsKey(expr)
                SQLExpression argExpr = (SQLExpression)args.get(0);
                BooleanExpression bExpr = null;
                for (int i=0; i<scalarExpressions.size(); i++)
                {
                    if (bExpr == null)
                    {
                        bExpr = ((SQLExpression)scalarExpressions.get(i)).eq(argExpr); 
                    }
                    else
                    {
                        bExpr = bExpr.ior(((SQLExpression)scalarExpressions.get(i)).eq(argExpr)); 
                    }
                }
                bExpr.encloseInParentheses();
                return bExpr;
            }
            else if (methodName.equals("get") && args.size() == 1)
            {
                // Map.get(expr)
                SQLExpression argExpr = (SQLExpression)args.get(0);
                if (argExpr instanceof SQLLiteral)
                {
                    DatastoreAdapter dba = stmt.getRDBMSManager().getDatastoreAdapter();
                    Object val = value.get(((SQLLiteral)argExpr).getValue());
                    if (val == null)
                    {
                        return new NullLiteral(stmt, null, null);
                    }
                    JavaTypeMapping m = dba.getMapping(val.getClass(), stmt.getRDBMSManager(), 
                        stmt.getRDBMSManager().getOMFContext().getClassLoaderResolver(null));
                    return new ObjectLiteral(stmt, m, val);
                }
                else
                {
                    // Don't support Map.get(SQLExpression)
                    throw new IllegalExpressionOperationException(this, "getMethod", argExpr);
                }
            }

            return super.invoke(methodName, args);
        }

        /* (non-Javadoc)
         * @see org.datanucleus.store.rdbms.sql.expression.SQLLiteral#getValue()
         */
        public Object getValue()
        {
            return value;
        }

        /* (non-Javadoc)
         * @see org.datanucleus.store.rdbms.sql.expression.SQLLiteral#getRawValue()
         */
        public Object getRawValue()
        {
            return null;
        }

        /* (non-Javadoc)
         * @see org.datanucleus.store.rdbms.sql.expression.SQLLiteral#setRawValue(java.lang.Object)
         */
        public void setRawValue(Object val)
        {
        }
    }

    /**
     * An SQL expression that will test if a column of a table falls within the given Map's values.
     */
    class MapValueLiteral extends SQLExpression implements SQLLiteral
    {
        private final Map value;

        /** ScalarExpressions for all elements in the Map **/ 
        private List scalarExpressions;

        /**
         * Constructor.
         * @param stmt SQL Statement
         * @param mapping The mapping to the Map
         * @param value The transient Map that is the value.
         */
        public MapValueLiteral(SQLStatement stmt, JavaTypeMapping mapping, Object value)
        {
            super(stmt, null, mapping);

            if (value instanceof Map)
            {
                Map mapValue = (Map)value;
                this.value = mapValue;

                // We'll consider the Map to be empty if it is null, is really
                // empty, or only contains null. 
                // If it contains null we need a special case when creating the SQL.
                boolean isEmpty = 
                    (mapValue == null) || (mapValue.isEmpty()) || (mapValue.size() == 1 && containsNull);

                // If the Map is empty, don't build the list of SQLExpressions.
                if (!isEmpty)
                {
                    RDBMSManager storeMgr = stmt.getRDBMSManager();
                    DatastoreAdapter dba = storeMgr.getDatastoreAdapter();
                    scalarExpressions = new ArrayList();
                    st.append("(");

                    boolean hadPrev = false;

                    Collection values = mapValue.values();
                    for (Iterator it=values.iterator(); it.hasNext();)
                    {
                        Object current = it.next();
                        if (null != current)
                        {
                            JavaTypeMapping m = dba.getMapping(current.getClass(), storeMgr,
                                storeMgr.getOMFContext().getClassLoaderResolver(null));
                            SQLExpression expr = storeMgr.getSQLExpressionFactory().newLiteral(stmt, m, current);

                            // Append the SQLExpression (should be a literal) for the current element.
                            st.append(hadPrev ? "," : "");
                            st.append(expr);
                            scalarExpressions.add(expr);

                            hadPrev = true;
                        }
                    }

                    st.append(")");
                }
            }
            else
            {
                throw new NucleusException("Cannot create " + this.getClass().getName() + 
                    " for value of type " + (value != null ? value.getClass().getName() : null));
            }
        }

        public SQLExpression invoke(String methodName, List args)
        {
            if (methodName.equals("contains") && args.size() == 1)
            {
                // Map.containsValue(expr)
                SQLExpression argExpr = (SQLExpression)args.get(0);
                BooleanExpression bExpr = null;
                for (int i=0; i<scalarExpressions.size(); i++)
                {
                    if (bExpr == null)
                    {
                        bExpr = ((SQLExpression)scalarExpressions.get(i)).eq(argExpr); 
                    }
                    else
                    {
                        bExpr = bExpr.ior(((SQLExpression)scalarExpressions.get(i)).eq(argExpr)); 
                    }
                }
                bExpr.encloseInParentheses();
                return bExpr;
            }

            return super.invoke(methodName, args);
        }

        /* (non-Javadoc)
         * @see org.datanucleus.store.rdbms.sql.expression.SQLLiteral#getValue()
         */
        public Object getValue()
        {
            return value;
        }

        /* (non-Javadoc)
         * @see org.datanucleus.store.rdbms.sql.expression.SQLLiteral#getRawValue()
         */
        public Object getRawValue()
        {
            return null;
        }

        /* (non-Javadoc)
         * @see org.datanucleus.store.rdbms.sql.expression.SQLLiteral#setRawValue(java.lang.Object)
         */
        public void setRawValue(Object val)
        {
        }
    }
}