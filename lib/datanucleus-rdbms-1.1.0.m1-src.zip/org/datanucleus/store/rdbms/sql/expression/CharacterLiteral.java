/**********************************************************************
Copyright (c) 2008 Andy Jefferson and others. All rights reserved.
Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.

Contributors:
    ...
**********************************************************************/
package org.datanucleus.store.rdbms.sql.expression;

import java.util.List;

import org.datanucleus.exceptions.NucleusException;
import org.datanucleus.store.mapped.mapping.JavaTypeMapping;
import org.datanucleus.store.rdbms.sql.SQLStatement;

/**
 * Representation of a Character literal in a Query.
 */
public class CharacterLiteral extends CharacterExpression implements SQLLiteral
{
    private final String value;

    /** Raw value that this literal represents. */
    Object rawValue;

    /**
     * Creates an integer literal.
     * @param stmt the SQL statement
     * @param mapping the mapping
     * @param value the value
     */
    public CharacterLiteral(SQLStatement stmt, JavaTypeMapping mapping, Object value)
    {
        super(stmt, null, mapping);

        if (value instanceof Character)
        {
            this.value = ((Character)value).toString();
            st.append('\'').append(this.value).append('\'');
        }
        else if (value instanceof String)
        {
            this.value = (String)value;
            st.appendParameter(mapping, value);
        }
        else
        {
            throw new NucleusException("Cannot create " + this.getClass().getName() + 
                " for value of type " + (value != null ? value.getClass().getName() : null));
        }

        st.append('\'').append(this.value).append('\'');
    }

    public BooleanExpression eq(SQLExpression expr)
    {
        if (expr instanceof CharacterLiteral)
        {
            return new BooleanLiteral(stmt, mapping, value.equals(((CharacterLiteral)expr).value));
        }
        else
        {
            return super.eq(expr);
        }
    }

    public BooleanExpression ne(SQLExpression expr)
    {
        if (expr instanceof CharacterLiteral)
        {
            return new BooleanLiteral(stmt, mapping, !value.equals(((CharacterLiteral)expr).value));
        }
        else
        {
            return super.ne(expr);
        }
    }

    public BooleanExpression lt(SQLExpression expr)
    {
        if (expr instanceof CharacterLiteral)
        {
            return new BooleanLiteral(stmt, mapping, value.compareTo(((CharacterLiteral)expr).value) < 0);
        }
        else
        {
            return super.lt(expr);
        }
    }

    public BooleanExpression le(SQLExpression expr)
    {
        if (expr instanceof CharacterLiteral)
        {
            return new BooleanLiteral(stmt, mapping, value.compareTo(((CharacterLiteral)expr).value) <= 0);
        }
        else
        {
            return super.le(expr);
        }
    }

    public BooleanExpression gt(SQLExpression expr)
    {
        if (expr instanceof CharacterLiteral)
        {
            return new BooleanLiteral(stmt, mapping, value.compareTo(((CharacterLiteral)expr).value) > 0);
        }
        else
        {
            return super.gt(expr);
        }
    }

    public BooleanExpression ge(SQLExpression expr)
    {
        if (expr instanceof CharacterLiteral)
        {
            return new BooleanLiteral(stmt, mapping, value.compareTo(((CharacterLiteral)expr).value) >= 0);
        }
        else
        {
            return super.ge(expr);
        }
    }

    public SQLExpression add(SQLExpression expr)
    {
        if (expr instanceof CharacterLiteral)
        {
            int v = value.charAt(0)+((CharacterLiteral)expr).value.charAt(0);
            return new IntegerLiteral(stmt, mapping, new Integer(v));
        }
        else if (expr instanceof IntegerLiteral)
        {
            int v = value.charAt(0)+((Number)((IntegerLiteral)expr).getValue()).intValue();
            return new IntegerLiteral(stmt, mapping, new Integer(v));
        }
        else
        {
            return super.add(expr);
        }
    }
    
    public SQLExpression sub(SQLExpression expr)
    {
        if (expr instanceof CharacterLiteral)
        {
            int v = value.charAt(0)-((CharacterLiteral)expr).value.charAt(0);
            return new IntegerLiteral(stmt, mapping, new Integer(v));
        }
        else if (expr instanceof IntegerLiteral)
        {
            int v = value.charAt(0)-((Number)((IntegerLiteral)expr).getValue()).intValue();
            return new IntegerLiteral(stmt, mapping, new Integer(v));
        }
        else
        {
            return super.add(expr);
        }
    }    

    public SQLExpression mod(SQLExpression expr)
    {
        if (expr instanceof CharacterLiteral)
        {
            int v = value.charAt(0)%((CharacterLiteral)expr).value.charAt(0);
            return new IntegerLiteral(stmt, mapping, new Integer(v));
        }
        else if (expr instanceof IntegerLiteral)
        {
            int v = value.charAt(0)%((Number)((IntegerLiteral)expr).getValue()).intValue();
            return new IntegerLiteral(stmt, mapping, new Integer(v));
        }       
        else
        {
            return super.mod(expr);
        }
    }

    public SQLExpression neg()
    {
        int v = -(value.charAt(0));
        return new IntegerLiteral(stmt, mapping, new Integer(v));
    }    

    public SQLExpression com()
    {
        int v = ~(value.charAt(0));
        return new IntegerLiteral(stmt, mapping, new Integer(v));
    }

    public SQLExpression invoke(String methodName, List args)
    {
        if (methodName.equals("toUpperCase"))
        {
            return new CharacterLiteral(stmt, mapping, value.toUpperCase());
        }
        else if (methodName.equals("toLowerCase"))
        {
            return new CharacterLiteral(stmt, mapping, value.toLowerCase());
        }

        return super.invoke(methodName, args);
    }

    public Object getValue()
    {
        if (value == null)
        {
            return null;
        }
        return new Character(value.charAt(0));
    }

    /**
     * Method to save a "raw" value that this literal represents.
     * This value differs from the literal value since that is of the same type as this literal.
     * @param val The raw value
     */
    public void setRawValue(Object val)
    {
        this.rawValue = val;
    }

    /**
     * Accessor for the "raw" value that this literal represents.
     * This value differs from the literal value since that is of the same type as this literal.
     * @return The raw value
     */
    public Object getRawValue()
    {
        return rawValue;
    }
}