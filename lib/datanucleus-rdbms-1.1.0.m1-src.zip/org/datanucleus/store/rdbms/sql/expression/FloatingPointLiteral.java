/**********************************************************************
Copyright (c) 2008 Andy Jefferson and others. All rights reserved.
Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.

Contributors:
    ...
**********************************************************************/
package org.datanucleus.store.rdbms.sql.expression;

import java.math.BigDecimal;

import org.datanucleus.exceptions.NucleusException;
import org.datanucleus.query.expression.Expression;
import org.datanucleus.store.mapped.mapping.JavaTypeMapping;
import org.datanucleus.store.rdbms.sql.SQLStatement;
import org.datanucleus.util.StringUtils;

/**
 * Representation of a FloatPoint literal in a query.
 */
public class FloatingPointLiteral extends NumericExpression implements SQLLiteral
{
    private final BigDecimal value;

    /** Raw value that this literal represents. */
    Object rawValue;

    /**
     * Creates a floating point literal.
     * @param stmt the SQL statement
     * @param mapping the mapping
     * @param value the value
     */
    public FloatingPointLiteral(SQLStatement stmt, JavaTypeMapping mapping, Object value)
    {
        super(stmt, null, mapping);

        if (value instanceof Float)
        {
            this.value = new BigDecimal(((Float)value).toString());
        }
        else if (value instanceof Double)
        {
            this.value = new BigDecimal(((Double)value).toString());
        }
        else if (value instanceof BigDecimal)
        {
            this.value = (BigDecimal)value;
        }
        else
        {
            throw new NucleusException("Cannot create " + this.getClass().getName() + 
                " for value of type " + (value != null ? value.getClass().getName() : null));
        }

        st.append(StringUtils.exponentialFormatBigDecimal(this.value));
    }

    public BooleanExpression eq(SQLExpression expr)
    {
//        assertValidTypeForParameterComparison(expr, NumericExpression.class);

        if (expr instanceof FloatingPointLiteral)
        {
            return new BooleanLiteral(stmt, mapping, value.compareTo(((FloatingPointLiteral)expr).value) == 0);
        }
        else if (expr instanceof CharacterExpression)
        {
            CharacterLiteral literal = new CharacterLiteral(stmt, mapping, String.valueOf((char)value.intValue()));
            return new BooleanExpression(expr, Expression.OP_EQ, literal);         
        }            
        else
        {
            return super.eq(expr);
        }
    }

    public BooleanExpression ne(SQLExpression expr)
    {
//        assertValidTypeForParameterComparison(expr, NumericExpression.class);

        if (expr instanceof FloatingPointLiteral)
        {
            return new BooleanLiteral(stmt, mapping, value.compareTo(((FloatingPointLiteral)expr).value) != 0);
        }
        else if (expr instanceof CharacterExpression)
        {
            CharacterLiteral literal = new CharacterLiteral(stmt, mapping, String.valueOf((char)value.intValue()));
            return new BooleanExpression(expr, Expression.OP_NOTEQ, literal);          
        }             
        else
        {
            return super.ne(expr);
        }
    }

    public BooleanExpression lt(SQLExpression expr)
    {
        if (expr instanceof FloatingPointLiteral)
        {
            return new BooleanLiteral(stmt, mapping, value.compareTo(((FloatingPointLiteral)expr).value) < 0);
        }
        else if (expr instanceof CharacterExpression)
        {
            CharacterLiteral literal = new CharacterLiteral(stmt, mapping, String.valueOf((char)value.intValue()));
            return new BooleanExpression(literal, Expression.OP_LT, expr);         
        }
        else
        {
            return super.lt(expr);
        }
    }

    public BooleanExpression le(SQLExpression expr)
    {
        if (expr instanceof FloatingPointLiteral)
        {
            return new BooleanLiteral(stmt, mapping, value.compareTo(((FloatingPointLiteral)expr).value) <= 0);
        }
        else if (expr instanceof CharacterExpression)
        {
            CharacterLiteral literal = new CharacterLiteral(stmt, mapping, String.valueOf(
                (char)value.intValue()));
            return new BooleanExpression(literal, Expression.OP_LTEQ, expr);           
        }
        else
        {
            return super.le(expr);
        }
    }

    public BooleanExpression gt(SQLExpression expr)
    {
        if (expr instanceof FloatingPointLiteral)
        {
            return new BooleanLiteral(stmt, mapping, value.compareTo(((FloatingPointLiteral)expr).value) > 0);
        }
        else if (expr instanceof CharacterExpression)
        {
            CharacterLiteral literal = new CharacterLiteral(stmt, mapping, String.valueOf(
                (char)value.intValue()));
            return new BooleanExpression(literal, Expression.OP_GT, expr);         
        }            
        else
        {
            return super.gt(expr);
        }
    }

    public BooleanExpression ge(SQLExpression expr)
    {
        if (expr instanceof FloatingPointLiteral)
        {
            return new BooleanLiteral(stmt, mapping, value.compareTo(((FloatingPointLiteral)expr).value) >= 0);
        }
        else if (expr instanceof CharacterExpression)
        {
            CharacterLiteral literal = new CharacterLiteral(stmt, mapping, String.valueOf(
                (char)value.intValue()));
            return new BooleanExpression(literal, Expression.OP_GTEQ, expr);           
        }            
        else
        {
            return super.ge(expr);
        }
    }

    public SQLExpression add(SQLExpression expr)
    {
        if (expr instanceof FloatingPointLiteral)
        {
            return new FloatingPointLiteral(stmt, mapping, value.add(((FloatingPointLiteral)expr).value));
        }
        else
        {
            return super.add(expr);
        }
    }

    public SQLExpression sub(SQLExpression expr)
    {
        if (expr instanceof FloatingPointLiteral)
        {
            return new FloatingPointLiteral(stmt, mapping, value.subtract(((FloatingPointLiteral)expr).value));
        }
        else
        {
            return super.sub(expr);
        }
    }

    public SQLExpression mul(SQLExpression expr)
    {
        if (expr instanceof FloatingPointLiteral)
        {
            return new FloatingPointLiteral(stmt, mapping, value.multiply(((FloatingPointLiteral)expr).value));
        }
        else
        {
            return super.mul(expr);
        }
    }

    public SQLExpression div(SQLExpression expr)
    {
        if (expr instanceof FloatingPointLiteral)
        {
            return new FloatingPointLiteral(stmt, mapping, value.divide(((FloatingPointLiteral)expr).value, BigDecimal.ROUND_DOWN));
        }
        else
        {
            return super.mul(expr);
        }
    }

    public SQLExpression neg()
    {
        return new FloatingPointLiteral(stmt, mapping, value.negate());
    }

    public Object getValue()
    {
        return value;
    }

    /**
     * Method to save a "raw" value that this literal represents.
     * This value differs from the literal value since that is of the same type as this literal.
     * @param val The raw value
     */
    public void setRawValue(Object val)
    {
        this.rawValue = val;
    }

    /**
     * Accessor for the "raw" value that this literal represents.
     * This value differs from the literal value since that is of the same type as this literal.
     * @return The raw value
     */
    public Object getRawValue()
    {
        return rawValue;
    }
}