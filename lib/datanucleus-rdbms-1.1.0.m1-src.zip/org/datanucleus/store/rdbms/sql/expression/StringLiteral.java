/**********************************************************************
Copyright (c) 2008 Andy Jefferson and others. All rights reserved.
Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.

Contributors:
    ...
**********************************************************************/
package org.datanucleus.store.rdbms.sql.expression;

import java.util.List;

import org.datanucleus.exceptions.NucleusException;
import org.datanucleus.store.mapped.mapping.JavaTypeMapping;
import org.datanucleus.store.rdbms.sql.SQLStatement;
import org.datanucleus.store.rdbms.sql.SQLText;
import org.datanucleus.util.StringUtils;

/**
 * Representation of a string literal.
 */
public class StringLiteral extends StringExpression implements SQLLiteral
{
    private final String value;

    /** Raw value that this literal represents. */
    Object rawValue;

    private SQLText stUsingParameter = new SQLText();

    /**
     * Creates a String literal.
     * @param stmt the SQL statement
     * @param mapping the mapping
     * @param value the value
     */
    public StringLiteral(SQLStatement stmt, JavaTypeMapping mapping, Object value)
    {
        super(stmt, null, mapping);

        if (value instanceof String)
        {
            this.value = (String)value;
        }
        else if (value instanceof Character)
        {
            this.value = ((Character)value).toString();
        }
        else
        {
            throw new NucleusException("Cannot create " + this.getClass().getName() + 
                " for value of type " + (value != null ? value.getClass().getName() : null));
        }

        // Escape any single-quotes
        st.append('\'').append(StringUtils.replaceAll(this.value, "'", "''")).append('\'');

        if (mapping == null)
        {
            stUsingParameter.appendParameter(mapping, this.value);
        }
        else
        {
            stUsingParameter.appendParameter(mapping, this.value);
        }
    }

    /**
     * Convenience method to generate the statement without any quotes.
     * This is called when we create a literal using a mapping, and dont want quotes
     * because the string is an SQL keyword.
     */
    public void generateStatementWithoutQuotes()
    {
        st.clearStatement();
        st.append(StringUtils.replaceAll(value, "'", "''"));
    }

    public Object getValue()
    {
        return value;
    }

    public BooleanExpression eq(SQLExpression expr)
    {
//        assertValidTypeForParameterComparison(expr, StringExpression.class);

        if (expr instanceof StringLiteral)
        {
            return new BooleanLiteral(stmt, mapping, value.equals(((StringLiteral)expr).value));
        }
        else
        {
            return super.eq(expr);
        }
    }

    public BooleanExpression ne(SQLExpression expr)
    {
//        assertValidTypeForParameterComparison(expr, StringExpression.class);

        if (expr instanceof StringLiteral)
        {
            return new BooleanLiteral(stmt, mapping, !value.equals(((StringLiteral)expr).value));
        }
        else
        {
            return super.ne(expr);
        }
    }

    public BooleanExpression lt(SQLExpression expr)
    {
        if (expr instanceof StringLiteral)
        {
            return new BooleanLiteral(stmt, mapping, value.compareTo(((StringLiteral)expr).value) < 0);
        }
        else
        {
            return super.lt(expr);
        }
    }

    public BooleanExpression le(SQLExpression expr)
    {
        if (expr instanceof StringLiteral)
        {
            return new BooleanLiteral(stmt, mapping, value.compareTo(((StringLiteral)expr).value) <= 0);
        }
        else
        {
            return super.le(expr);
        }
    }

    public BooleanExpression gt(SQLExpression expr)
    {
        if (expr instanceof StringLiteral)
        {
            return new BooleanLiteral(stmt, mapping, value.compareTo(((StringLiteral)expr).value) > 0);
        }
        else
        {
            return super.gt(expr);
        }
    }

    public BooleanExpression ge(SQLExpression expr)
    {
        if (expr instanceof StringLiteral)
        {
            return new BooleanLiteral(stmt, mapping, value.compareTo(((StringLiteral)expr).value) >= 0);
        }
        else
        {
            return super.ge(expr);
        }
    }

    public SQLExpression add(SQLExpression expr)
    {
        if (expr instanceof StringLiteral)
        {
            return new StringLiteral(stmt, mapping, value.concat(((StringLiteral)expr).value));
        }
        else if (expr instanceof CharacterLiteral)
        {
            return new StringLiteral(stmt, mapping, value.concat(((SQLLiteral)expr).getValue().toString()));
        }
        else if (expr instanceof IntegerLiteral || expr instanceof FloatingPointLiteral || expr instanceof BooleanLiteral )
        {
            return new StringLiteral(stmt, mapping, value.concat(((SQLLiteral)expr).getValue().toString()));
        }        
        else
        {
            return super.add(expr);
        }
    }

    public SQLExpression invoke(String methodName, List args)
    {
        if (methodName.equals("toUpperCase"))
        {
            return new StringLiteral(stmt, mapping, value.toUpperCase());
        }
        else if (methodName.equals("toLowerCase"))
        {
            return new StringLiteral(stmt, mapping, value.toLowerCase());
        }
        else if (methodName.equals("length"))
        {
            return new IntegerLiteral(stmt, mapping, new Integer(value.length()));
        }
        else if (methodName.equals("trim"))
        {
            return new StringLiteral(stmt, mapping, value.trim());
        }
        // TODO Support other methods

        return super.invoke(methodName, args);
    }

    public SQLText toSQL()
    {
        return stUsingParameter;
    }

    /**
     * Method to save a "raw" value that this literal represents.
     * This value differs from the literal value since that is of the same type as this literal.
     * @param val The raw value
     */
    public void setRawValue(Object val)
    {
        this.rawValue = val;
    }

    /**
     * Accessor for the "raw" value that this literal represents.
     * This value differs from the literal value since that is of the same type as this literal.
     * @return The raw value
     */
    public Object getRawValue()
    {
        return rawValue;
    }
}