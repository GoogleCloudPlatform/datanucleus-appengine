/**********************************************************************
Copyright (c) 2008 Andy Jefferson and others. All rights reserved.
Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.

Contributors:
    ...
**********************************************************************/
package org.datanucleus.store.rdbms.sql.expression;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.datanucleus.ClassLoaderResolver;
import org.datanucleus.exceptions.ClassNotResolvedException;
import org.datanucleus.exceptions.NucleusException;
import org.datanucleus.metadata.JoinMetaData;
import org.datanucleus.plugin.ConfigurationElement;
import org.datanucleus.plugin.ExtensionPoint;
import org.datanucleus.store.mapped.DatastoreClass;
import org.datanucleus.store.mapped.DatastoreContainerObject;
import org.datanucleus.store.mapped.SecondaryDatastoreClass;
import org.datanucleus.store.mapped.mapping.JavaTypeMapping;
import org.datanucleus.store.rdbms.RDBMSManager;
import org.datanucleus.store.rdbms.sql.SQLStatement;
import org.datanucleus.store.rdbms.sql.SQLTable;
import org.datanucleus.store.rdbms.sql.method.SQLMethod;
import org.datanucleus.store.rdbms.sql.operation.SQLOperation;
import org.datanucleus.util.ClassUtils;
import org.datanucleus.util.Localiser;
import org.datanucleus.util.NucleusLogger;

/**
 * Factory for creating SQL expressions/literals.
 * These are typically called when we are building up an SQL statement and we want to impose conditions
 * using the fields of a class, and values for the field.
 */
public class SQLExpressionFactory
{
    /** Localiser for messages */
    protected static final Localiser LOCALISER = Localiser.getInstance(
        "org.datanucleus.store.rdbms.Localisation", RDBMSManager.class.getClassLoader());

    RDBMSManager storeMgr;

    ClassLoaderResolver clr;

    /** Map of the SQLExpression class name, keyed by the JavaTypeMapping class name. */
    Map<String, String> expressionByMapping = new HashMap<String, String>();

    /** Map of the Literal class name, keyed by the JavaTypeMapping class name. */
    Map<String, String> literalByMapping = new HashMap<String, String>();

    /** Map of SQLMethod class name, keyed by "datastore#{class}.{method}". */
    Map<String, String> methodByDatastoreMethodName = new HashMap<String, String>();

    /** Map of SQLOperation class name, keyed by "datastore#{operation}". */
    Map<String, String> operationByDatastoreOperationName = new HashMap<String, String>();

    /**
     * Constructor for an SQLExpressionFactory.
     * Loads up the defined SQL expressions 
     * [extension-point "org.datanucleus.store.rdbms.sql_expression"] and caches them. 
     * Also loads up the defined SQL methods
     * [extension-point: "org.datanucleus.store.rdbms.sql_method"] and caches them.
     * Also loads up the defined SQL operations
     * [extension-point: "org.datanucleus.store.rdbms.sql_operation"] and caches them.
     * @param storeMgr RDBMS Manager
     */
    public SQLExpressionFactory(RDBMSManager storeMgr)
    {
        this.storeMgr = storeMgr;
        this.clr = storeMgr.getOMFContext().getClassLoaderResolver(null);

        ExtensionPoint exPoint = storeMgr.getOMFContext().getPluginManager().getExtensionPoint(
                "org.datanucleus.store.rdbms.sql_expression");
        for (int i = 0; i < exPoint.getExtensions().length; i++)
        {
            ConfigurationElement[] elms = exPoint.getExtensions()[i].getConfigurationElements();
            for (int e = 0; e < elms.length; e++)
            {
                String mappingName = elms[e].getAttribute("mapping-class").trim();
                String expressionName = elms[e].getAttribute("expression-class").trim();
                String literalName = elms[e].getAttribute("literal-class").trim();

                expressionByMapping.put(mappingName, expressionName);
                literalByMapping.put(mappingName, literalName);
            }
        }

        exPoint = storeMgr.getOMFContext().getPluginManager().getExtensionPoint(
                "org.datanucleus.store.rdbms.sql_method");
        for (int i = 0; i < exPoint.getExtensions().length; i++)
        {
            ConfigurationElement[] elms = exPoint.getExtensions()[i].getConfigurationElements();
            for (int e = 0; e < elms.length; e++)
            {
                String datastoreName = elms[e].getAttribute("datastore");
                String className = elms[e].getAttribute("class");
                String methodName = elms[e].getAttribute("method").trim();
                String sqlMethodName = elms[e].getAttribute("evaluator").trim();

                String key = getSQLMethodKey(datastoreName, className, methodName);
                methodByDatastoreMethodName.put(key, sqlMethodName);
            }
        }

        exPoint = storeMgr.getOMFContext().getPluginManager().getExtensionPoint(
                "org.datanucleus.store.rdbms.sql_operation");
        for (int i = 0; i < exPoint.getExtensions().length; i++)
        {
            ConfigurationElement[] elms = exPoint.getExtensions()[i].getConfigurationElements();
            for (int e = 0; e < elms.length; e++)
            {
                String datastoreName = elms[e].getAttribute("datastore");
                String name = elms[e].getAttribute("name").trim();
                String sqlOperationName = elms[e].getAttribute("evaluator").trim();

                String key = getSQLOperationKey(datastoreName, name);
                operationByDatastoreOperationName.put(key, sqlOperationName);
            }
        }
    }

    /**
     * Factory for an expression representing a mapping on a table.
     * @param stmt The statement
     * @param table The table
     * @param mapping The mapping
     * @return The expression
     */
    public SQLExpression newExpression(SQLStatement stmt, SQLTable table, JavaTypeMapping mapping)
    {
        String expressionClassName = expressionByMapping.get(mapping.getClass().getName());
        if (expressionClassName == null)
        {
            throw new NucleusException(LOCALISER.msg("060004", mapping.getClass().getName()));
        }

        SQLTable expressionTable = table;
        if (table.getTable() instanceof DatastoreClass)
        {
            // Check that the mapping is managed by the specified table
            // and cater for situation where is in superclass table, or secondary table
            // Note that we don't process join tables here since they don't support inheritance
            DatastoreClass tbl = (DatastoreClass)table.getTable();
            if (!tbl.managesMapping(mapping))
            {
                // Provided table doesn't manage this mapping so check for secondary tables/supertables
                if (mapping.getDatastoreContainer() != null)
                {
                    DatastoreContainerObject tableOfMapping = mapping.getDatastoreContainer();
                    boolean innerJoin = true;
                    if (tableOfMapping instanceof SecondaryDatastoreClass)
                    {
                        // Need join to secondary table
                        JoinMetaData joinmd = ((SecondaryDatastoreClass)tableOfMapping).getJoinMetaData();
                        if (joinmd != null && joinmd.isOuter())
                        {
                            innerJoin = false;
                        }
                    }
                    else if (!tbl.isSuperDatastoreClass((DatastoreClass)tableOfMapping))
                    {
                        // Should be supertable, yet the supplied mapping isn't for any supertable!
                        throw new NucleusException("Attempt to create expression for " + mapping +
                            " in SQLTable " + table + " yet this mapping is for " + tableOfMapping +
                            " which is not a supertable of the required table!");
                    }

                    expressionTable = stmt.getTable(tableOfMapping);
                    if (expressionTable == null)
                    {
                        // This table is not referenced by the SQLStatement so join to it
                        NucleusLogger.JDO.debug(">> newExpression needs join from " + table + 
                            " to " + tableOfMapping +
                            " jointype=" + (innerJoin ? "INNER" : "OUTER"));
                        if (innerJoin)
                        {
                            expressionTable = stmt.innerJoin(table, table.getTable().getIDMapping(), 
                                tableOfMapping, null, tableOfMapping.getIDMapping(), null);
                        }
                        else
                        {
                            expressionTable = stmt.leftOuterJoin(table, table.getTable().getIDMapping(), 
                                tableOfMapping, null, tableOfMapping.getIDMapping(), null);
                        }
                    }
                }
                else
                {
                    // TODO Uncomment something here. This needs to allow for PCMapping that doesn't
                    // have the table set
//                    throw new NucleusException("Attempt to create expression for " + mapping + 
//                        " in SQLTable " + table + " yet this is not present in that table");
                }
            }
        }

        try
        {
            // Use "new SQLExpression(SQLStatement, SQLTable, JavaTypeMapping)"
            Class exprCls = clr.classForName(expressionClassName);
            SQLExpression expr = (SQLExpression)ClassUtils.newInstance(exprCls, 
                new Class[] {SQLStatement.class, SQLTable.class, JavaTypeMapping.class},
                new Object[] {stmt, expressionTable, mapping});
            return expr;
        }
        catch (ClassNotResolvedException cnre)
        {
            throw new NucleusException(LOCALISER.msg("060005", expressionClassName));
        }
    }

    /**
     * Factory for a literal representing a value.
     * @param stmt The statement
     * @param mapping The mapping
     * @param value The value
     * @return The literal
     */
    public SQLExpression newLiteral(SQLStatement stmt, JavaTypeMapping mapping, Object value)
    {
        String literalClassName = literalByMapping.get(mapping.getClass().getName());
        if (literalClassName == null)
        {
            throw new NucleusException(LOCALISER.msg("060006", mapping.getClass().getName()));
        }

        try
        {
            // Use "new SQLLiteral(SQLStatement, JavaTypeMapping, Object)"
            Class exprCls = clr.classForName(literalClassName);
            SQLExpression expr = (SQLExpression)ClassUtils.newInstance(exprCls, 
                new Class[] {SQLStatement.class, JavaTypeMapping.class, Object.class},
                new Object[] {stmt, mapping, value});
            return expr;
        }
        catch (ClassNotResolvedException cnre)
        {
            throw new NucleusException(LOCALISER.msg("060007", literalClassName));
        }
    }

    /**
     * Accessor for the result of a method call on the supplied expression with the supplied args.
     * Throws a NucleusException is the method is not supported.
     * @param className Class we are invoking the method on
     * @param methodName Name of the method
     * @param expr The expression we invoke the method on
     * @param args Any arguments to the method call
     * @return The result
     */
    public SQLExpression invokeMethod(String className, String methodName, SQLExpression expr, List args)
    {
        // Try a datastore-specific key
        String datastoreId = storeMgr.getDatastoreAdapter().getVendorID();
        String key = getSQLMethodKey(datastoreId, className, methodName);
        String sqlMethodClassName = methodByDatastoreMethodName.get(key);
        if (sqlMethodClassName == null)
        {
            // Try a datastore-independent key
            key = getSQLMethodKey(null, className, methodName);
            sqlMethodClassName = methodByDatastoreMethodName.get(key);
            if (sqlMethodClassName == null)
            {
                if (className == null)
                {
                    throw new NucleusException(LOCALISER.msg("060008", methodName, className));
                }
                else
                {
                    throw new NucleusException(LOCALISER.msg("060009", methodName));
                }
            }
        }

        // Use SQLMethod().getExpression(SQLExpression, args)
        try
        {
            SQLMethod method = (SQLMethod)clr.classForName(sqlMethodClassName).newInstance();
            return method.getExpression(expr, args);
        }
        catch (ClassNotResolvedException cnre)
        {
            throw new NucleusException(LOCALISER.msg("060010", sqlMethodClassName));
        }
        catch (InstantiationException e)
        {
            throw new NucleusException(LOCALISER.msg("060011", sqlMethodClassName), e);
        }
        catch (IllegalAccessException e)
        {
            throw new NucleusException(LOCALISER.msg("060011", sqlMethodClassName), e);
        }
    }

    /**
     * Accessor for the result of an operation call on the supplied expression with the supplied args.
     * Throws a NucleusException is the method is not supported.
     * @param name Operation to be invoked
     * @param expr The first expression to perform the operation on
     * @param expr2 The second expression to perform the operation on
     * @return The result
     */
    public SQLExpression invokeOperation(String name, SQLExpression expr, SQLExpression expr2)
    {
        // Try a datastore-specific key
        String datastoreId = storeMgr.getDatastoreAdapter().getVendorID();
        String key = getSQLOperationKey(datastoreId, name);
        String sqlOperationClassName = operationByDatastoreOperationName.get(key);
        if (sqlOperationClassName == null)
        {
            // Try a datastore-independent key
            key = getSQLOperationKey(null, name);
            sqlOperationClassName = operationByDatastoreOperationName.get(key);
            if (sqlOperationClassName == null)
            {
                throw new NucleusException(LOCALISER.msg("060012", name));
            }
        }

        // Use SQLOperation().getExpression(SQLExpression, SQLExpression)
        try
        {
            NucleusLogger.JDO.info(">> Invoke " + name + " returns " + sqlOperationClassName);
            SQLOperation operation = (SQLOperation)clr.classForName(sqlOperationClassName).newInstance();
            return operation.getExpression(expr, expr2);
        }
        catch (ClassNotResolvedException cnre)
        {
            throw new NucleusException(LOCALISER.msg("060013", sqlOperationClassName));
        }
        catch (InstantiationException e)
        {
            throw new NucleusException(LOCALISER.msg("060014", sqlOperationClassName), e);
        }
        catch (IllegalAccessException e)
        {
            throw new NucleusException(LOCALISER.msg("060014", sqlOperationClassName), e);
        }
    }

    /**
     * Convenience method to return the key for the SQL method.
     * Returns a string like <pre>{datastore}#{class}.{method}</pre> if the class is defined, and
     * <pre>{datastore}#{method}</pre> if the class is not defined (function).
     * @param datastoreName Vendor id of the RDBMS datastore
     * @param className Name of the class that we are invoking on (null if static).
     * @param methodName Method to be invoked
     * @return Key for the SQLMethod
     */
    private String getSQLMethodKey(String datastoreName, String className, String methodName)
    {
        return (datastoreName != null ? datastoreName.trim() : "ALL") + "#" +
            (className != null ? (className.trim() + ".") : "") + methodName;
    }

    /**
     * Convenience method to return the key for the SQL operation.
     * Returns a string like <pre>{datastore}#{operation}</pre>.
     * @param datastoreName Vendor id of the RDBMS datastore
     * @param name Operation to be invoked
     * @return Key for the SQLOperation
     */
    private String getSQLOperationKey(String datastoreName, String name)
    {
        return (datastoreName != null ? datastoreName.trim() : "ALL") + "#" + name;
    }
}