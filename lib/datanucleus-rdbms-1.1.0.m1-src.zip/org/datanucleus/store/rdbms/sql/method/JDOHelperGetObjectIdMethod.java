/**********************************************************************
Copyright (c) 2008 Andy Jefferson and others. All rights reserved.
Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.

Contributors:
    ...
**********************************************************************/
package org.datanucleus.store.rdbms.sql.method;

import java.util.List;

import org.datanucleus.api.ApiAdapter;
import org.datanucleus.store.mapped.mapping.JavaTypeMapping;
import org.datanucleus.store.mapped.mapping.PersistenceCapableMapping;
import org.datanucleus.store.rdbms.RDBMSManager;
import org.datanucleus.store.rdbms.sql.expression.IllegalExpressionOperationException;
import org.datanucleus.store.rdbms.sql.expression.NullLiteral;
import org.datanucleus.store.rdbms.sql.expression.ObjectExpression;
import org.datanucleus.store.rdbms.sql.expression.ObjectLiteral;
import org.datanucleus.store.rdbms.sql.expression.SQLExpression;
import org.datanucleus.store.rdbms.sql.expression.SQLLiteral;

/**
 * Expression handler to evaluate JDOHelper.getObjectId({expression}).
 * Returns an ObjectExpression or NullLiteral.
 */
public class JDOHelperGetObjectIdMethod extends AbstractSQLMethod
{
    /* (non-Javadoc)
     * @see org.datanucleus.store.rdbms.sql.method.SQLMethod#getExpression(org.datanucleus.store.rdbms.sql.expression.SQLExpression, java.util.List)
     */
    public SQLExpression getExpression(SQLExpression expr, List args)
    {
        if (expr == null)
        {
            return new NullLiteral(expr.getSQLStatement(), null, null);
        }
        if (expr instanceof SQLLiteral)
        {
            RDBMSManager storeMgr = expr.getSQLStatement().getRDBMSManager();
            ApiAdapter api = storeMgr.getApiAdapter();
            Object id = api.getIdForObject(((SQLLiteral)expr).getValue());
            if (id == null)
            {
                return new NullLiteral(expr.getSQLStatement(), null, null);
            }
            else
            {                
                JavaTypeMapping m = storeMgr.getMappingManager().getMappingWithDatastoreMapping(
                    id.getClass(), false, false,
                    storeMgr.getOMFContext().getClassLoaderResolver(null));
                return new ObjectLiteral(expr.getSQLStatement(), m, id);
            }
        }
        else if (ObjectExpression.class.isAssignableFrom(expr.getClass()))
        {
            if (((ObjectExpression)expr).getJavaTypeMapping() instanceof PersistenceCapableMapping)
            {
                // TODO Handle this
                // JDOHelper.getObjectId only requires the identity, whereas a PCMapping by default will
                // represent the object so we change it to be an identity representation.
//                ((ObjectExpression)expr).useIdentityFormOfPCMapping();
            }
            return expr;
        }

        throw new IllegalExpressionOperationException("JDOHelper.getObjectId", expr);
    }
}