/**********************************************************************
Copyright (c) 2002 Kelly Grizzle (TJDO) and others. All rights reserved.
Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
 

Contributors:
2002 Mike Martin (TJDO)
2003 Andy Jefferson - coding standards
    ...
**********************************************************************/
package org.datanucleus.store.rdbms.request;

import java.util.Arrays;

import org.datanucleus.metadata.AbstractMemberMetaData;
import org.datanucleus.store.mapped.DatastoreClass;

/**
 * Representation of a request id.
 */
public class RequestIdentifier
{
    private final DatastoreClass table;
    private final int[] fields;
    private final Type type;
    private final int hashCode;
    private final String className;

    /**
     * Constructor.
     * @param table Datastore class for which this is a request
     * @param fields MetaData of fields to use in the request
     * @param type The type being represented
     * @param className The name of the class
     */
    public RequestIdentifier(DatastoreClass table, AbstractMemberMetaData[] fields, Type type, String className)
    {
        this.table = table;
        this.type = type;

        if (fields == null)
        {
            this.fields = null;
        }
        else
        {
            this.fields = new int[fields.length];
            for (int i=0;i<this.fields.length;i++)
            {
                this.fields[i] = fields[i].getAbsoluteFieldNumber();
            }

            // The key uniqueness is dependent on fields being sorted
            Arrays.sort(this.fields);
        }
        this.className = className;
        
        /*
         * Since we are an immutable object, pre-compute the hash code for
         * improved performance in equals().
         */
        int h = table.hashCode() ^ type.hashCode() ^ className.hashCode();

        if (this.fields != null)
        {
            for (int i = 0; i < this.fields.length; ++i)
            {
                h ^= this.fields[i];
            }
        }

        hashCode = h;
    }

    /**
     * Accessor for the table of this request.
     * @return Table used in the request
     */
    public DatastoreClass getTable()
    {
        return table;
    }

    /**
     * Accessor for the hashcode
     * @return The hashcode
     **/
    public int hashCode()
    {
        return hashCode;
    }

    /**
     * Equality operator
     * @param o Object to compare with
     * @return Whether the objects are equal
     **/
    public boolean equals(Object o)
    {
        if (o == this)
        {
            return true;
        }

        if (!(o instanceof RequestIdentifier))
        {
            return false;
        }

        RequestIdentifier ri = (RequestIdentifier)o;

        if (hashCode != ri.hashCode)
        {
            return false;
        }

        return table.equals(ri.table) &&
            type.equals(ri.type) &&
            Arrays.equals(fields, ri.fields) &&
            className.equals(ri.className);
    }

    /**
     * Inner class representing the Type of request
     **/
    public static class Type
    {
        private int typeId;

        /** INSERT **/
        public static final Type INSERT        = new Type(0);
        /** FETCH **/
        public static final Type FETCH         = new Type(1);
        /** UPDATE **/
        public static final Type UPDATE        = new Type(2);
        /** DELETE **/
        public static final Type DELETE        = new Type(3);
        /** LOCATE **/
        public static final Type LOCATE        = new Type(4);

        private static final String[] TYPE_NAMES =
        {
            "Insert",
            "Fetch",
            "Update",
            "Delete",
            "Locate"
        };

        private Type(int typeId)
        {
            this.typeId = typeId;
        }

        public String toString()
        {
            return TYPE_NAMES[typeId];
        }
    }
}