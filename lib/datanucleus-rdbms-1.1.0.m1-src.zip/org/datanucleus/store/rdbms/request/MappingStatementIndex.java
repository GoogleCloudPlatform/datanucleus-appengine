/**********************************************************************
Copyright (c) 2004 Erik Bengtson and others. All rights reserved. 
Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License. 
 

Contributors:
    ...
**********************************************************************/
package org.datanucleus.store.rdbms.request;

import org.datanucleus.store.mapped.StatementExpressionIndex;

/**
 * Holder for the StatementExpressionIndex for datastore id, PKs, version, and fields mappings.
 * Effectively provides the lookup of StatementExpressionINdex for the different mapping of a
 * request statement.
 */
class MappingStatementIndex
{
    private StatementExpressionIndex datastoreId = new StatementExpressionIndex();
    private StatementExpressionIndex[] primaryKeys;

    private StatementExpressionIndex[] fields;

    private StatementExpressionIndex version = new StatementExpressionIndex();
    private StatementExpressionIndex version2 = new StatementExpressionIndex();
    
    /**
     * Accessor for the datastore id mapping index.
     * @return Returns the datastoreId.
     */
    public StatementExpressionIndex getDatastoreId()
    {
        return datastoreId;
    }

    /**
     * Mutator for the datastore id mapping index.
     * @param datastoreId The datastoreId to set.
     */
    public void setDatastoreId(StatementExpressionIndex datastoreId)
    {
        this.datastoreId = datastoreId;
    }

    /**
     * Accessor for the version mapping index.
     * @return Returns the version index.
     */
    public StatementExpressionIndex getVersion()
    {
        return version;
    }

    /**
     * Mutator for the version mapping index.
     * @param optimistic The version to set.
     */
    public void setVersion(StatementExpressionIndex optimistic)
    {
        this.version = optimistic;
    }

    /**
     * Accessor for the second version mapping index.
     * @return Returns the version index.
     */
    public StatementExpressionIndex getVersion2()
    {
        return version2;
    }

    /**
     * Accessor for the second version mapping index.
     * @param optimistic The version to set.
     */
    public void setVersion2(StatementExpressionIndex optimistic)
    {
        this.version2 = optimistic;
    }

    /**
     * Accessor for the mapping indices for the fields.
     * @return Returns the fields.
     */
    public StatementExpressionIndex[] getFields()
    {
        return fields;
    }

    /**
     * Mutator for the mapping indices for the fields.
     * @param fields The fields to set.
     */
    public void setFields(StatementExpressionIndex[] fields)
    {
        this.fields = fields;
    }

    /**
     * Accessor for the primary key mapping indices for the fields.
     * @return Returns the primaryKeys.
     */
    public StatementExpressionIndex[] getPrimaryKeys()
    {
        return primaryKeys;
    }

    /**
     * Mutator for the primary key mapping indices for the fields.
     * @param primaryKeys The primaryKeys to set.
     */
    public void setPrimaryKeys(StatementExpressionIndex[] primaryKeys)
    {
        this.primaryKeys = primaryKeys;
    }
}