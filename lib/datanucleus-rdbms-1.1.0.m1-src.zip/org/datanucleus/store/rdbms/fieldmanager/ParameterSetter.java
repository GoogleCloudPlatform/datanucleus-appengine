/**********************************************************************
Copyright (c) 2002 Mike Martin (TJDO) and others. All rights reserved.
Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
 

Contributors:
2003 Andy Jefferson - coding standards
    ...
**********************************************************************/
package org.datanucleus.store.rdbms.fieldmanager;

import java.sql.PreparedStatement;

import org.datanucleus.ObjectManager;
import org.datanucleus.StateManager;
import org.datanucleus.exceptions.NucleusUserException;
import org.datanucleus.metadata.NullValue;
import org.datanucleus.store.exceptions.NotYetFlushedException;
import org.datanucleus.store.fieldmanager.AbstractFieldManager;
import org.datanucleus.store.mapped.StatementExpressionIndex;
import org.datanucleus.store.mapped.mapping.EmbeddedPCMapping;
import org.datanucleus.store.mapped.mapping.InterfaceMapping;
import org.datanucleus.store.mapped.mapping.JavaTypeMapping;
import org.datanucleus.store.mapped.mapping.PersistenceCapableMapping;
import org.datanucleus.store.mapped.mapping.SerialisedPCMapping;
import org.datanucleus.store.mapped.mapping.SerialisedReferenceMapping;
import org.datanucleus.store.rdbms.RDBMSManager;
import org.datanucleus.util.Localiser;

/**
 * Parameter setter implementation of a field manager.
 * 
 * @version $Revision: 1.22 $
 **/
public class ParameterSetter extends AbstractFieldManager
{
    private static final Localiser LOCALISER = Localiser.getInstance("org.datanucleus.store.rdbms.Localisation",
        RDBMSManager.class.getClassLoader()); 

    private final StateManager sm;
    private final ObjectManager om;
    private final PreparedStatement ps;
    private final StatementExpressionIndex[] statementExpressionIndex;
    private final boolean checkNonNullable;

    /**
     * Constructor.
     * @param sm The state manager for the object.
     * @param ps The Prepared Statement to set values on.
     * @param statementExpressionIndex the index of parameters/mappings
     * @param checkNonNullable Whether to check for nullability
     **/
    public ParameterSetter(StateManager sm,
                           PreparedStatement ps,
                           StatementExpressionIndex[] statementExpressionIndex,
                           boolean checkNonNullable)
    {
        this.sm = sm;
        this.om = sm.getObjectManager();
        this.ps = ps;
        this.statementExpressionIndex = statementExpressionIndex;
        this.checkNonNullable = checkNonNullable;
    }

    public void storeBooleanField(int fieldNumber, boolean value)
    {
        statementExpressionIndex[fieldNumber].getMapping().setBoolean(om, ps, statementExpressionIndex[fieldNumber].getParameterIndex(), value);
    }

    public void storeCharField(int fieldNumber, char value)
    {
        statementExpressionIndex[fieldNumber].getMapping().setChar(om, ps, statementExpressionIndex[fieldNumber].getParameterIndex(), value);
    }

    public void storeByteField(int fieldNumber, byte value)
    {
        statementExpressionIndex[fieldNumber].getMapping().setByte(om, ps, statementExpressionIndex[fieldNumber].getParameterIndex(), value);
    }

    public void storeShortField(int fieldNumber, short value)
    {
        statementExpressionIndex[fieldNumber].getMapping().setShort(om, ps, statementExpressionIndex[fieldNumber].getParameterIndex(), value);
    }

    public void storeIntField(int fieldNumber, int value)
    {
        statementExpressionIndex[fieldNumber].getMapping().setInt(om, ps, statementExpressionIndex[fieldNumber].getParameterIndex(), value);
    }

    public void storeLongField(int fieldNumber, long value)
    {
        statementExpressionIndex[fieldNumber].getMapping().setLong(om, ps, statementExpressionIndex[fieldNumber].getParameterIndex(), value);
    }

    public void storeFloatField(int fieldNumber, float value)
    {
        statementExpressionIndex[fieldNumber].getMapping().setFloat(om, ps, statementExpressionIndex[fieldNumber].getParameterIndex(), value);
    }

    public void storeDoubleField(int fieldNumber, double value)
    {
        statementExpressionIndex[fieldNumber].getMapping().setDouble(om, ps, statementExpressionIndex[fieldNumber].getParameterIndex(), value);
    }

    public void storeStringField(int fieldNumber, String value)
    {
        if (checkNonNullable &&
            value == null &&
            statementExpressionIndex[fieldNumber].getMapping().getFieldMetaData().getNullValue() == NullValue.EXCEPTION)
        {
            throw new NucleusUserException(LOCALISER.msg("052400",statementExpressionIndex[fieldNumber].getMapping().getFieldMetaData().getFullFieldName()));
        }
        statementExpressionIndex[fieldNumber].getMapping().setString(om, ps, statementExpressionIndex[fieldNumber].getParameterIndex(), value);
    }

    public void storeObjectField(int fieldNumber, Object value)
    {
        if (checkNonNullable && value == null &&
            statementExpressionIndex[fieldNumber].getMapping().getFieldMetaData().getNullValue() == NullValue.EXCEPTION)
        {
            throw new NucleusUserException(LOCALISER.msg("052400",statementExpressionIndex[fieldNumber].getMapping().getFieldMetaData().getFullFieldName()));
        }

        try
        {
            JavaTypeMapping mapping = statementExpressionIndex[fieldNumber].getMapping();
            if (mapping instanceof EmbeddedPCMapping ||
                mapping instanceof SerialisedPCMapping ||
                mapping instanceof SerialisedReferenceMapping ||
                mapping instanceof PersistenceCapableMapping ||
                mapping instanceof InterfaceMapping)
            {
                // Pass in the owner StateManager/field for any mappings that need to perform management of the relation
                mapping.setObject(om, ps, statementExpressionIndex[fieldNumber].getParameterIndex(), value, sm, fieldNumber);
            }
            else
            {
                mapping.setObject(om, ps, statementExpressionIndex[fieldNumber].getParameterIndex(), value);
            }

            // Make sure the field is wrapped where appropriate
	        sm.wrapSCOField(fieldNumber, value, false, true, true);
        }
        catch (NotYetFlushedException e)
        {
            if (sm.getClassMetaData().getMetaDataForManagedMemberAtAbsolutePosition(fieldNumber).getNullValue() == NullValue.EXCEPTION)
            {
                throw e;
            }
            sm.updateFieldAfterInsert(e.getPersistable(),fieldNumber);
        }
    }
}