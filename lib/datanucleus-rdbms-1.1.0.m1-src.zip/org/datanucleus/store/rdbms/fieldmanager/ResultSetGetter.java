/**********************************************************************
Copyright (c) 2002 Mike Martin (TJDO) and others. All rights reserved. 
Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.

Contributors:
    Andy Jefferson - coding standards
    ...
**********************************************************************/
package org.datanucleus.store.rdbms.fieldmanager;

import java.sql.ResultSet;

import org.datanucleus.ObjectManager;
import org.datanucleus.StateManager;
import org.datanucleus.store.fieldmanager.AbstractFieldManager;
import org.datanucleus.store.mapped.StatementExpressionIndex;
import org.datanucleus.store.mapped.mapping.EmbeddedPCMapping;
import org.datanucleus.store.mapped.mapping.JavaTypeMapping;
import org.datanucleus.store.mapped.mapping.SerialisedPCMapping;
import org.datanucleus.store.mapped.mapping.SerialisedReferenceMapping;

/**
 * ResultSet getter implementation of a field manager.
 */
public class ResultSetGetter extends AbstractFieldManager
{
    private final StateManager sm;
    private final ObjectManager om;
    private final ResultSet rs;
    private final StatementExpressionIndex[] statementExpressionIndex;

    /**
     * Constructor
     * @param sm the StateManager
     * @param rs the ResultSet
     * @param statementExpressionIndex the StatementExpressionIndex
     */
    public ResultSetGetter(StateManager sm, ResultSet rs, StatementExpressionIndex[] statementExpressionIndex)
    {
        this.sm = sm;
        this.om = sm.getObjectManager();
        this.rs = rs;
        this.statementExpressionIndex = statementExpressionIndex;
    }

    public boolean fetchBooleanField(int fieldNumber)
    {
        return statementExpressionIndex[fieldNumber].getMapping().getBoolean(om, rs, statementExpressionIndex[fieldNumber].getExpressionIndex());
    }

    public char fetchCharField(int fieldNumber)
    {
        return statementExpressionIndex[fieldNumber].getMapping().getChar(om, rs, statementExpressionIndex[fieldNumber].getExpressionIndex());
    }

    public byte fetchByteField(int fieldNumber)
    {
        return statementExpressionIndex[fieldNumber].getMapping().getByte(om, rs, statementExpressionIndex[fieldNumber].getExpressionIndex());
    }

    public short fetchShortField(int fieldNumber)
    {
        return statementExpressionIndex[fieldNumber].getMapping().getShort(om, rs, statementExpressionIndex[fieldNumber].getExpressionIndex());
    }

    public int fetchIntField(int fieldNumber)
    {
        return statementExpressionIndex[fieldNumber].getMapping().getInt(om, rs, statementExpressionIndex[fieldNumber].getExpressionIndex());
    }

    public long fetchLongField(int fieldNumber)
    {
        return statementExpressionIndex[fieldNumber].getMapping().getLong(om, rs, statementExpressionIndex[fieldNumber].getExpressionIndex());
    }

    public float fetchFloatField(int fieldNumber)
    {
        return statementExpressionIndex[fieldNumber].getMapping().getFloat(om, rs, statementExpressionIndex[fieldNumber].getExpressionIndex());
    }

    public double fetchDoubleField(int fieldNumber)
    {
        return statementExpressionIndex[fieldNumber].getMapping().getDouble(om, rs, statementExpressionIndex[fieldNumber].getExpressionIndex());
    }

    public String fetchStringField(int fieldNumber)
    {
        return statementExpressionIndex[fieldNumber].getMapping().getString(om, rs, statementExpressionIndex[fieldNumber].getExpressionIndex());
    }

    public Object fetchObjectField(int fieldNumber)
    {
        JavaTypeMapping mapping = statementExpressionIndex[fieldNumber].getMapping();
        Object value;
        if (mapping instanceof EmbeddedPCMapping ||
            mapping instanceof SerialisedPCMapping ||
            mapping instanceof SerialisedReferenceMapping)
        {
            value = mapping.getObject(om, rs, statementExpressionIndex[fieldNumber].getExpressionIndex(), sm, fieldNumber);
        }
        else
        {
            value = mapping.getObject(om, rs, statementExpressionIndex[fieldNumber].getExpressionIndex());
        }

        // Return the field value (as a wrapper if wrappable)
        return sm.wrapSCOField(fieldNumber, value, false, false, false);
    }
}