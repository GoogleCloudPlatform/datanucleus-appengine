/**********************************************************************
Copyright (c) 2003 Andy Jefferson and others. All rights reserved. 
Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License. 
 

Contributors:
2004 David Ezzio - fix the use of the default package for the persistent class
2004 Erik Bengtson - removed Connection parameter for generateTableNameForMetaData method 
2004 Andy Jefferson - added getClassForAppIdKey()
2004 Andy Jefferson - moved collection/map join table naming to generateTableName
2005 Andy Jefferson - fixed use of catalog/schema so we always query multi-schema
    ...
**********************************************************************/
package org.datanucleus.store.rdbms;

import java.lang.reflect.Modifier;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Iterator;
import java.util.List;

import org.datanucleus.ClassLoaderResolver;
import org.datanucleus.ManagedConnection;
import org.datanucleus.ObjectManager;
import org.datanucleus.StateManager;
import org.datanucleus.Transaction;
import org.datanucleus.exceptions.NucleusDataStoreException;
import org.datanucleus.exceptions.NucleusException;
import org.datanucleus.metadata.ClassMetaData;
import org.datanucleus.metadata.DiscriminatorMetaData;
import org.datanucleus.metadata.DiscriminatorStrategy;
import org.datanucleus.state.StateManagerFactory;
import org.datanucleus.store.StoreData;
import org.datanucleus.store.mapped.DatastoreAdapter;
import org.datanucleus.store.mapped.DatastoreClass;
import org.datanucleus.store.mapped.DatastoreIdentifier;
import org.datanucleus.store.mapped.IdentifierType;
import org.datanucleus.store.mapped.MappedStoreData;
import org.datanucleus.store.mapped.query.DiscriminatorIteratorStatement;
import org.datanucleus.store.mapped.expression.LogicSetExpression;
import org.datanucleus.store.mapped.expression.MetaDataStringLiteral;
import org.datanucleus.store.mapped.expression.NullLiteral;
import org.datanucleus.store.mapped.expression.QueryExpression;
import org.datanucleus.store.mapped.expression.ScalarExpression;
import org.datanucleus.store.mapped.mapping.JavaTypeMapping;
import org.datanucleus.store.rdbms.adapter.RDBMSAdapter;
import org.datanucleus.store.rdbms.query.RDBMSQueryUtils;
import org.datanucleus.store.rdbms.query.RDBMSDiscriminatorIteratorStatement;
import org.datanucleus.store.rdbms.table.ClassTable;
import org.datanucleus.util.NucleusLogger;
import org.datanucleus.util.StringUtils;

/**
 * Provides a series of uilities assisting in the datastore management process for RDBMS datastores.
 */
public class RDBMSStoreHelper
{
    /**
     * Utility that takes an id and a list of possible class RDBMSStoreData
     * and finds which of these classes contains the object with that id.
     * Works via a query to the datastore. Operates for all types of identity.
     * @param om Object Manager
     * @param storeMgr Store Manager
     * @param id The id
     * @param schemaDataOptions List of possible RDBMSStoreData
     * @return Name of the class with this key (or null if none found)
     **/
    public static String getClassNameForIdKeyUsingUnion(ObjectManager om,
                                                  RDBMSManager storeMgr,
                                                  Object id,
                                                  List schemaDataOptions)
    {
        String className = null;

        // Check for input error
        if (schemaDataOptions == null || id == null || schemaDataOptions.size() == 0)
        {
            return null;
        }

        // Calculate max length of class name for identifier
        int metadata_id_len = 0;
        Iterator optionsIter = schemaDataOptions.iterator();
        while (optionsIter.hasNext())
        {
            RDBMSStoreData schemaDataOption = (RDBMSStoreData)optionsIter.next();
            metadata_id_len = Math.max(schemaDataOption.getName().length(), metadata_id_len);
        }

        // Form the query to find which one of these classes has the instance with this id
        QueryExpression qs_base = null;
        optionsIter = schemaDataOptions.iterator();
        while (optionsIter.hasNext())
        {
            RDBMSStoreData schemaDataOption = (RDBMSStoreData)optionsIter.next();
            ClassMetaData cmd = (ClassMetaData)schemaDataOption.getMetaData();

            QueryExpression qs = storeMgr.getDatastoreAdapter().newQueryStatement(
                schemaDataOption.getDatastoreContainerObject(), null, om.getClassLoaderResolver());
            String classname = StringUtils.leftAlignedPaddedString(schemaDataOption.getName(), metadata_id_len);
            qs.selectScalarExpression(new MetaDataStringLiteral(qs,classname));

            // LEFT OUTER JOIN to all direct subclasses
            Iterator subclass_iter = storeMgr.getSubClassesForClass(schemaDataOption.getName(),false, om.getClassLoaderResolver()).iterator();
            int subclasses_seq_id = 0;
            while (subclass_iter.hasNext())
            {
                String subclass = (String)subclass_iter.next();
                DatastoreClass subclassTable = storeMgr.getDatastoreClass(subclass, om.getClassLoaderResolver());

                // No need to LEFT OUTER JOIN for "subclass-table" and "superclass-table" cases
                // "subclass-table" objects dont exist on their own
                // "superclass-table" are excluded using the discriminator clause
                if (subclassTable != null && !subclassTable.getIdentifier().equals(schemaDataOption.getDatastoreContainerObject().getIdentifier()))
                {
                    DatastoreIdentifier subclassTableIdentifier = storeMgr.getIdentifierFactory().newIdentifier(IdentifierType.TABLE, "SUBCLASS" + (subclasses_seq_id++));
                    QueryExpression st = storeMgr.getDatastoreAdapter().newQueryStatement(subclassTable, subclassTableIdentifier, om.getClassLoaderResolver());
                    LogicSetExpression table_expr_sub = st.newTableExpression(subclassTable, subclassTableIdentifier);
                    JavaTypeMapping subMapping = subclassTable.getIDMapping();
                    st.select(subclassTableIdentifier, subMapping);

                    ScalarExpression subExpr = subMapping.newScalarExpression(qs, table_expr_sub);
                    ScalarExpression schExpr = 
                        (((DatastoreClass)schemaDataOption.getDatastoreContainerObject()).getIDMapping()).newScalarExpression(
                            qs,qs.getMainTableExpression());
                    qs.leftOuterJoin(subExpr, schExpr, table_expr_sub, true);
                    qs.andCondition(new NullLiteral(qs).eq(subExpr));
                }
            }

            // WHERE (object id) = ?
            JavaTypeMapping idMapping = ((DatastoreClass)schemaDataOption.getDatastoreContainerObject()).getIDMapping();

            // We have to create a StateManager here just to map fields from the AppId key object
            // to the table fields. Really the table should have some way of doing this. TODO : Refactor this
            Class pc_class = om.getClassLoaderResolver().classForName(schemaDataOption.getName());
            StateManager sm = StateManagerFactory.newStateManagerForHollow(om,pc_class,id);
            ScalarExpression fieldExpr = idMapping.newScalarExpression(qs, qs.getMainTableExpression());
            ScalarExpression fieldValue = idMapping.newLiteral(qs, sm.getObject());
            qs.andCondition(fieldExpr.eq(fieldValue), true);
 
            // Discriminator for this class
            JavaTypeMapping discrimMapping = schemaDataOption.getDatastoreContainerObject().getDiscriminatorMapping(false);
            DiscriminatorMetaData discrimMetaData = cmd.getInheritanceMetaData().getDiscriminatorMetaData();
            if (discrimMapping != null)
            {
                ScalarExpression discrimExpr = discrimMapping.newScalarExpression(qs, qs.getMainTableExpression());
                Object value = null;
                if (cmd.getDiscriminatorStrategy() == DiscriminatorStrategy.CLASS_NAME)
                {
                    value = schemaDataOption.getName();
                }
                else if (cmd.getDiscriminatorStrategy() == DiscriminatorStrategy.VALUE_MAP)
                {
                    value = discrimMetaData.getValue();
                }
                ScalarExpression discrimValue = discrimMapping.newLiteral(qs, value);
                qs.andCondition(discrimExpr.eq(discrimValue), true);
            }

            if (qs_base==null)
            {
                qs_base = qs;
            }
            else
            {
                qs_base.union(qs);
            }
        }

        // Perform the query
        try
        {
            Transaction tx = om.getTransaction();
            ManagedConnection mconn = storeMgr.getConnection(om);
            SQLController sqlControl = storeMgr.getSQLController();
            boolean useUpdateLock = ((Boolean)tx.getOptions().get(Transaction.LOCK_FOR_UPDATE_OPTION)).booleanValue();
            String statement = storeMgr.getStatementTextForQuery(qs_base, useUpdateLock);
            try
            {
                PreparedStatement ps = storeMgr.getStatementForQuery(qs_base, om, mconn, useUpdateLock, null, null);
                try
                {
                    ResultSet rs = sqlControl.executeStatementQuery(mconn, statement, ps);
                    try
                    {
                        if (rs != null)
                        {
                            while (rs.next())
                            {
                                className = RDBMSQueryUtils.getClassNameFromMetaDataResultSetRow(rs);
                            }
                        }
                    }
                    finally
                    {
                        rs.close();
                    }
                }
                finally
                {
                    sqlControl.closeStatement(mconn, ps);
                }
            }
            finally
            {
                mconn.release();
            }
        }
        catch (SQLException sqe)
        {
            NucleusLogger.DATASTORE.error(sqe);
            throw new NucleusDataStoreException(sqe.toString());
        }

        return className;
    }

    /**
     * Utility that takes an id and a list of possible class RDBMSStoreData
     * and finds which of these classes contains the object with that id.
     * Works via a query to the datastore. Operates for all types of identity.
     * TODO The "schemaDataOptions" could be changed to be an array of class names.
     * @param om Object Manager
     * @param storeMgr Store Manager
     * @param id The id
     * @param schemaDataOptions List of possible RDBMSStoreData
     * @return Name of the class with this key (or null if none found)
     **/
    public static String getClassNameForIdKeyUsingDiscriminator(ObjectManager om,
                                                  RDBMSManager storeMgr,
                                                  Object id,
                                                  List schemaDataOptions)
    {
        String className = null;

        // Check for input error
        if (schemaDataOptions == null || schemaDataOptions.size() == 0 || id == null)
        {
            return null;
        }

        ClassLoaderResolver clr = om.getClassLoaderResolver();
        Class primaryClass = clr.classForName(((RDBMSStoreData)schemaDataOptions.get(0)).getName());
        Class objectClass = primaryClass;
        if (Modifier.isAbstract(primaryClass.getModifiers()))
        {
            // The primary class is abstract so find one that isnt. We only need a valid object type
            Iterator optionsIter = schemaDataOptions.iterator();
            while (optionsIter.hasNext())
            {
                RDBMSStoreData data = (RDBMSStoreData)optionsIter.next();
                Class dataClass = clr.classForName(data.getName());
                if (!Modifier.isAbstract(dataClass.getModifiers()))
                {
                    objectClass = dataClass;
                    break;
                }
            }
        }
        if (Modifier.isAbstract(objectClass.getModifiers()))
        {
            throw new NucleusException("Class "+objectClass.getName()+" is abstract, and a non abstract was expected.").setFatal();
        }

        // Form the query to find which one of these classes has the instance with this id
        DiscriminatorIteratorStatement discrimStmt = new RDBMSDiscriminatorIteratorStatement(clr, new Class[] {primaryClass}, true, storeMgr, true);

        // Check all instances of this table to see if we have all possible candidates in our "options" list
        DatastoreClass primaryTable = storeMgr.getDatastoreClass(primaryClass.getName(), clr);
        StoreData[] storeData = storeMgr.getStoreDataForDatastoreContainerObject(primaryTable.getIdentifier());
        boolean haveAllCandidates = true;
        for (int i=0;i<storeData.length;i++)
        {
            if (storeData[i] instanceof MappedStoreData)
            {
                ClassTable tbl = (ClassTable)((MappedStoreData)storeData[i]).getDatastoreContainerObject();
                String[] managedClasses = tbl.getManagedClasses();
                for (int j=0;j<managedClasses.length;j++)
                {
                    boolean managedClassFound = false;
                    Iterator optionsIter = schemaDataOptions.iterator();
                    while (optionsIter.hasNext())
                    {
                        StoreData optionData = (StoreData)optionsIter.next();
                        if (optionData.getName().equals(managedClasses[j]))
                        {
                            managedClassFound = true;
                            break;
                        }
                    }
                    if (!managedClassFound)
                    {
                        haveAllCandidates = false;
                        break;
                    }
                }
                if (!haveAllCandidates)
                {
                    break;
                }
            }
        }

        if (haveAllCandidates)
        {
            // We have all possible candidates that are stored in this table so we can omit the restriction on the discriminator
            discrimStmt.setRestrictDiscriminator(false); // Just retrieve the discriminator for this id (accept any possible disc values)
        }

        // Create the statement
        QueryExpression stmt = discrimStmt.getQueryStatement(null);

        // WHERE (object id) = ?
        // We have to create a StateManager here just to map fields from the AppId key object to the table fields.
        // Really the table should have some way of doing this. TODO : Refactor this
        StateManager sm = StateManagerFactory.newStateManagerForHollow(om, objectClass, id);
        JavaTypeMapping idMapping = primaryTable.getIDMapping();
        ScalarExpression fieldExpr = idMapping.newScalarExpression(stmt, stmt.getMainTableExpression());
        ScalarExpression fieldValue = idMapping.newLiteral(stmt, sm.getObject());
        stmt.andCondition(fieldExpr.eq(fieldValue), true);

        // Perform the query
        try
        {
            Transaction tx = om.getTransaction();
            ManagedConnection mconn = storeMgr.getConnection(om);
            SQLController sqlControl = storeMgr.getSQLController();
            boolean useUpdateLock = ((Boolean)tx.getOptions().get(Transaction.LOCK_FOR_UPDATE_OPTION)).booleanValue();
            String statement = storeMgr.getStatementTextForQuery(stmt, useUpdateLock);
            try
            {
                PreparedStatement ps = storeMgr.getStatementForQuery(stmt, om, mconn, useUpdateLock, null, null);
                try
                {
                    ResultSet rs = sqlControl.executeStatementQuery(mconn, statement, ps);
                    try
                    {
                        if (rs != null)
                        {
                            while (rs.next())
                            {
                                className = RDBMSQueryUtils.getClassNameFromDiscriminatorResultSetRow(primaryTable, rs, om);
                            }
                        }
                    }
                    finally
                    {
                        rs.close();
                    }
                }
                finally
                {
                    sqlControl.closeStatement(mconn, ps);
                }
            }
            finally
            {
                mconn.release();
            }
        }
        catch (SQLException sqe)
        {
            NucleusLogger.DATASTORE.error(sqe);
            throw new NucleusDataStoreException(sqe.toString());
        }

        return className;
    }

    /**
     * Convenience method to return if a datastore adapter supports a particular isolation level for txns.
     * @param dba Datastore adapter
     * @param level The isolation level (as defined by Connection enums).
     * @return Whether it is supported.
     */
    public static boolean supportsTransactionIsolation(DatastoreAdapter dba, int level)
    {
        if ((level == Connection.TRANSACTION_NONE && dba.supportsOption(RDBMSAdapter.TX_ISOLATION_NONE)) ||
            (level == Connection.TRANSACTION_READ_COMMITTED && dba.supportsOption(RDBMSAdapter.TX_ISOLATION_READ_COMMITTED)) ||
            (level == Connection.TRANSACTION_READ_UNCOMMITTED && dba.supportsOption(RDBMSAdapter.TX_ISOLATION_READ_UNCOMMITTED)) ||
            (level == Connection.TRANSACTION_REPEATABLE_READ && dba.supportsOption(RDBMSAdapter.TX_ISOLATION_REPEATABLE_READ)) ||
            (level == Connection.TRANSACTION_SERIALIZABLE && dba.supportsOption(RDBMSAdapter.TX_ISOLATION_SERIALIZABLE)))
        {
            return true;
        }
        return false;
    }
}