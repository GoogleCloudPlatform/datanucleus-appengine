/**********************************************************************
Copyright (c) 2003 Erik Bengtson and others. All rights reserved. 
Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License. 
 

Contributors:
2003 Andy Jefferson - coding standards
2004 Andy Jefferson - change from Integer to Long
2004 Andy Jefferson - removed last-id option since was dangerous in concurrent apps
    ...
**********************************************************************/
package org.datanucleus.store.rdbms.valuegenerator;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Properties;

import org.datanucleus.store.mapped.MappedStoreManager;
import org.datanucleus.store.rdbms.RDBMSManager;
import org.datanucleus.store.rdbms.SQLController;
import org.datanucleus.store.valuegenerator.ValueGenerationBlock;
import org.datanucleus.store.valuegenerator.ValueGenerationException;
import org.datanucleus.util.Localiser;

/**
 * This generator for Relational Databases uses the "select max(column) from
 * table" strategy. The block size is limited to 1. MaxPoidGenerator works
 * with numbers, so clients using this generator must cast the ID to Long *
 * <P>
 * <B>Required user properties</B>
 * </P>
 * <UL>
 * </UL>
 * <P>
 * <B>Optional user properties</B>
 * <UL>
 * </UL>
 * </P>
 */
public class MaxGenerator extends AbstractRDBMSGenerator
{
    protected static final Localiser LOCALISER_RDBMS = Localiser.getInstance(
        "org.datanucleus.store.rdbms.Localisation", RDBMSManager.class.getClassLoader());

    /**
     * Constructor.
     * @param name Symbolic name for this generator
     * @param props Properties defining the behaviour of this generator
     */
    public MaxGenerator(String name, Properties props)
    {
        super(name, props);
        allocationSize = 1;
    }

    /**
     * Method to reserve a block of identities.
     * Note : Only allocates a single id always.
     * @param size The block size
     * @return The reserved block
     */
    public ValueGenerationBlock reserveBlock(long size)
    {
        // search an Id in the database
        PreparedStatement ps = null;
        ResultSet rs = null;
        RDBMSManager rdbmsMgr = (RDBMSManager)storeMgr;
        SQLController sqlControl = rdbmsMgr.getSQLController();
        try
        {
            String stmt = getStatement();
            ps = sqlControl.getStatementForUpdate(connection, stmt, false);

            rs = sqlControl.executeStatementQuery(connection, stmt, ps);
            if (!rs.next())
            {
                return new ValueGenerationBlock(new Object[] { new Long(1) });
            }

            return new ValueGenerationBlock(new Object[] { new Long(rs.getLong(1) + 1)});
        }
        catch (SQLException e)
        {
            //TODO adds a message correspondent to the exception. 
            //we need to work to create user friendly messages
            throw new ValueGenerationException(e.getMessage());
        }
        finally
        {
            try
            {
                if (rs != null)
                {
                    rs.close();
                }
                if (ps != null)
                {
                    sqlControl.closeStatement(connection, ps);
                }
            }
            catch (SQLException e)
            {
                // no recoverable error
            }           
        }
    }

    /**
     * Return the SQL statement.
     * TODO Allow this to work in different catalog/schema
     * @return statement
     */
    private String getStatement()
    {
        MappedStoreManager srm = (MappedStoreManager)storeMgr;
        StringBuffer stmt = new StringBuffer();
        stmt.append("SELECT max(");
        stmt.append(srm.getIdentifierFactory().getIdentifierInAdapterCase((String)properties.get("column-name")));
        stmt.append(") FROM ");
        stmt.append(srm.getIdentifierFactory().getIdentifierInAdapterCase((String)properties.get("table-name")));  
        return stmt.toString();
    }
}