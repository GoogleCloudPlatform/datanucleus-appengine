/**********************************************************************
 Copyright (c) 2007 Andy Jefferson and others. All rights reserved.
 Licensed under the Apache License, Version 2.0 (the "License");
 you may not use this file except in compliance with the License.
 You may obtain a copy of the License at

 http://www.apache.org/licenses/LICENSE-2.0

 Unless required by applicable law or agreed to in writing, software
 distributed under the License is distributed on an "AS IS" BASIS,
 WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 See the License for the specific language governing permissions and
 limitations under the License.

 Contributors:
 ...
 **********************************************************************/
package org.datanucleus.store.rdbms.scostore;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashSet;
import java.util.Iterator;

import org.datanucleus.ClassLoaderResolver;
import org.datanucleus.ManagedConnection;
import org.datanucleus.ObjectManager;
import org.datanucleus.StateManager;
import org.datanucleus.exceptions.NucleusDataStoreException;
import org.datanucleus.metadata.AbstractClassMetaData;
import org.datanucleus.metadata.AbstractMemberMetaData;
import org.datanucleus.metadata.DiscriminatorStrategy;
import org.datanucleus.store.fieldmanager.FieldManager;
import org.datanucleus.store.mapped.MappedStoreManager;
import org.datanucleus.store.mapped.StatementMappingIndex;
import org.datanucleus.store.mapped.expression.ExpressionHelper;
import org.datanucleus.store.mapped.expression.QueryExpression;
import org.datanucleus.store.mapped.mapping.EmbeddedElementPCMapping;
import org.datanucleus.store.mapped.mapping.JavaTypeMapping;
import org.datanucleus.store.mapped.scostore.BaseContainerStore;
import org.datanucleus.store.mapped.scostore.BaseElementContainerStoreSpecialization;
import org.datanucleus.store.mapped.scostore.ElementContainerStore;
import org.datanucleus.store.mapped.scostore.ElementContainerStoreSpecialization;
import org.datanucleus.store.rdbms.RDBMSManager;
import org.datanucleus.store.rdbms.SQLController;
import org.datanucleus.store.rdbms.SQLWarnings;
import org.datanucleus.store.rdbms.mapping.RDBMSMapping;
import org.datanucleus.util.Localiser;

/**
 * RDBMS-specific implementation of an {@link ElementContainerStoreSpecialization}.
 */
public class RDBMSElementContainerStoreSpecialization extends BaseElementContainerStoreSpecialization
{
    private final RDBMSManager storeMgr;

    /** Statement for getting the size of the container. */
    protected String sizeStmt;

    /** Statement for clearing the container. */
    protected String clearStmt;

    /** Statement for adding an element to the container. */
    protected String addStmt;

    /** Statement for removing an element from the container. */
    protected String removeStmt;

    /** Whether we are using a discriminator in the "size" statement. */
    protected boolean usingDiscriminatorInSizeStmt = false;

    public RDBMSElementContainerStoreSpecialization(Localiser localiser, ClassLoaderResolver clr, 
            RDBMSManager storeMgr)
    {
        super(localiser, clr);
        this.storeMgr = storeMgr;
    }

    /**
     * Convenience method to populate the passed PreparedStatement with the value from the owner.
     * @param sm State Manager
     * @param om Object Manager
     * @param ps The PreparedStatement
     * @param jdbcPosition Position in JDBC statement to populate
     * @return The next position in the JDBC statement
     */
    protected int populateOwnerInStatement(StateManager sm, ObjectManager om, Object ps, int jdbcPosition, 
            BaseContainerStore bcs)
    {
        if (!storeMgr.insertValuesOnInsert(bcs.getOwnerMapping().getDataStoreMapping(0)))
        {
            // Don't try to insert any mappings with insert parameter that isnt ? (e.g Oracle)
            return jdbcPosition;
        }
        if (bcs.getOwnerMemberMetaData() != null)
        {
            bcs.getOwnerMapping().setObject(om, ps,
                ExpressionHelper.getParametersIndex(jdbcPosition, bcs.getOwnerMapping()),
                sm.getObject(), sm, bcs.getOwnerMemberMetaData().getAbsoluteFieldNumber());
        }
        else
        {
            bcs.getOwnerMapping().setObject(om, ps,
                ExpressionHelper.getParametersIndex(jdbcPosition, bcs.getOwnerMapping()),
                sm.getObject());
        }
        return jdbcPosition + bcs.getOwnerMapping().getNumberOfDatastoreFields();
    }

    /**
     * Convenience method to populate the passed PreparedStatement with the value for the distinguisher value.
     *
     * @param om           Object Manager
     * @param ps           The PreparedStatement
     * @param jdbcPosition Position in JDBC statement to populate
     * @return The next position in the JDBC statement
     */
    protected int populateRelationDiscriminatorInStatement(ObjectManager om, PreparedStatement ps, int jdbcPosition,
                                                           ElementContainerStore ecs)
    {
        ecs.getRelationDiscriminatorMapping().setObject(
            om, ps, ExpressionHelper.getParametersIndex(jdbcPosition, ecs.getRelationDiscriminatorMapping()), ecs.getRelationDiscriminatorValue());
        return jdbcPosition + ecs.getRelationDiscriminatorMapping().getNumberOfDatastoreFields();
    }

    /**
     * Generates the statement for adding items.
     * The EMBEDDEDFIELDX columns are only added for embedded PC elements.
     * <PRE> INSERT INTO
     * COLLTABLE (OWNERCOL,[ELEMENTCOL],[EMBEDDEDFIELD1, EMBEDDEDFIELD2,...],[ORDERCOL]) VALUES (?,?,?)
     * </PRE>
     *
     * @return The Statement for adding an item
     */
    protected String getAddStmt(ElementContainerStore ecs)
    {
        if (addStmt == null)
        {
            StringBuffer stmt = new StringBuffer();
            stmt.append("INSERT INTO ");
            stmt.append(ecs.getContainerTable().toString());
            stmt.append(" (");
            for (int i = 0; i < ecs.getOwnerMapping().getNumberOfDatastoreFields(); i++)
            {
                if (i > 0)
                {
                    stmt.append(",");
                }
                stmt.append(ecs.getOwnerMapping().getDataStoreMapping(i).getDatastoreField().getIdentifier().toString());
            }

            for (int i = 0; i < ecs.getElementMapping().getNumberOfDatastoreFields(); i++)
            {
                stmt.append(",");
                stmt.append(ecs.getElementMapping().getDataStoreMapping(i).getDatastoreField().getIdentifier().toString());
            }

            if (ecs.getOrderMapping() != null)
            {
                for (int i = 0; i < ecs.getOrderMapping().getNumberOfDatastoreFields(); i++)
                {
                    stmt.append(",");
                    stmt.append(ecs.getOrderMapping().getDataStoreMapping(i).getDatastoreField().getIdentifier().toString());
                }
            }
            if (ecs.getRelationDiscriminatorMapping() != null)
            {
                for (int i = 0; i < ecs.getRelationDiscriminatorMapping().getNumberOfDatastoreFields(); i++)
                {
                    stmt.append(",");
                    stmt.append(
                        ecs.getRelationDiscriminatorMapping().getDataStoreMapping(i).getDatastoreField().getIdentifier().toString());
                }
            }

            stmt.append(") VALUES (");
            for (int i = 0; i < ecs.getOwnerMapping().getNumberOfDatastoreFields(); i++)
            {
                if (i > 0)
                {
                    stmt.append(",");
                }
                stmt.append(((RDBMSMapping) ecs.getOwnerMapping().getDataStoreMapping(i)).getInsertionInputParameter());
            }

            for (int i = 0; i < ecs.getElementMapping().getNumberOfDatastoreFields(); i++)
            {
                stmt.append(",");
                stmt.append(((RDBMSMapping) ecs.getElementMapping().getDataStoreMapping(0)).getInsertionInputParameter());
            }

            if (ecs.getOrderMapping() != null)
            {
                for (int i = 0; i < ecs.getOrderMapping().getNumberOfDatastoreFields(); i++)
                {
                    stmt.append(",");
                    stmt.append(((RDBMSMapping) ecs.getOrderMapping().getDataStoreMapping(0)).getInsertionInputParameter());
                }
            }
            if (ecs.getRelationDiscriminatorMapping() != null)
            {
                for (int i = 0; i < ecs.getRelationDiscriminatorMapping().getNumberOfDatastoreFields(); i++)
                {
                    stmt.append(",");
                    stmt.append(((RDBMSMapping) ecs.getRelationDiscriminatorMapping().getDataStoreMapping(0)).getInsertionInputParameter());
                }
            }

            stmt.append(") ");

            addStmt = stmt.toString();
        }

        return addStmt;
    }

    public void executeClear(StateManager ownerSM, org.datanucleus.store.mapped.scostore.ElementContainerStore ecs)
    {
        String clearStmt = getClearStmt(ecs);
        try
        {
            ObjectManager om = ownerSM.getObjectManager();
            ManagedConnection mconn = storeMgr.getConnection(om);
            SQLController sqlControl = storeMgr.getSQLController();
            try
            {
                PreparedStatement ps = sqlControl.getStatementForUpdate(mconn, clearStmt, false);
                try
                {
                    int jdbcPosition = 1;
                    jdbcPosition = populateOwnerInStatement(ownerSM, om, ps, jdbcPosition, ecs);
                    if (ecs.getRelationDiscriminatorMapping() != null)
                    {
                        jdbcPosition = populateRelationDiscriminatorInStatement(om, ps, jdbcPosition, ecs);
                    }

                    sqlControl.executeStatementUpdate(mconn, clearStmt, ps, true);
                }
                finally
                {
                    sqlControl.closeStatement(mconn, ps);
                }
            }
            finally
            {
                mconn.release();
            }
        }
        catch (SQLException e)
        {
            throw new NucleusDataStoreException(localiser.msg("056013", clearStmt), e);
        }
    }

    /**
     * Generate statement for clearing the container.
     * <PRE>
     * DELETE FROM CONTAINERTABLE WHERE OWNERCOL = ? [AND RELATION_DISCRIM=?]
     * </PRE>
     * TODO Add a discriminator restriction on this statement so we only clear ones with a
     * valid discriminator value
     *
     * @return Statement for clearing the container.
     */
    protected String getClearStmt(ElementContainerStore ecs)
    {
        if (clearStmt == null)
        {
            StringBuffer stmt = new StringBuffer();
            stmt.append("DELETE FROM ");
            stmt.append(ecs.getContainerTable().toString());
            stmt.append(" WHERE ");
            for (int i = 0; i < ecs.getOwnerMapping().getNumberOfDatastoreFields(); i++)
            {
                if (i > 0)
                {
                    stmt.append(" AND ");
                }
                stmt.append(ecs.getOwnerMapping().getDataStoreMapping(i).getDatastoreField().getIdentifier().toString());
                stmt.append(" = ");
                stmt.append(((RDBMSMapping) ecs.getOwnerMapping().getDataStoreMapping(i)).getUpdateInputParameter());
            }
            if (ecs.getRelationDiscriminatorMapping() != null)
            {
                for (int i = 0; i < ecs.getRelationDiscriminatorMapping().getNumberOfDatastoreFields(); i++)
                {
                    stmt.append(" AND ");
                    stmt.append(
                        ecs.getRelationDiscriminatorMapping().getDataStoreMapping(i).getDatastoreField().getIdentifier().toString());
                    stmt.append(" = ");
                    stmt.append(((RDBMSMapping) ecs.getRelationDiscriminatorMapping().getDataStoreMapping(i)).getUpdateInputParameter());
                }
            }
            clearStmt = stmt.toString();
        }

        return clearStmt;
    }

    public int getSize(StateManager ownerSM, ElementContainerStore ecs)
    {
        int numRows;

        String sizeStmt = getSizeStmt(ecs);
        try
        {
            ObjectManager om = ownerSM.getObjectManager();
            ManagedConnection mconn = storeMgr.getConnection(om);
            SQLController sqlControl = storeMgr.getSQLController();
            try
            {
                PreparedStatement ps = sqlControl.getStatementForQuery(mconn, sizeStmt);
                try
                {
                    int jdbcPosition = 1;
                    jdbcPosition = populateOwnerInStatement(ownerSM, om, ps, jdbcPosition, ecs);
                    if (ecs.getElementInfo() != null && ecs.getElementInfo().length == 1)
                    {
                        // TODO Allow for multiple element types (e.g interface implementations)
                        for (int i = 0; i < ecs.getElementInfo().length; i++)
                        {
                            if (ecs.getElementInfo()[i].getDiscriminatorMapping() != null)
                            {
                                jdbcPosition = populateElementDiscriminatorInStatement(om, ps, jdbcPosition, true, ecs.getElementInfo()[i]);
                            }
                        }
                    }
                    if (ecs.getRelationDiscriminatorMapping() != null)
                    {
                        jdbcPosition = populateRelationDiscriminatorInStatement(om, ps, jdbcPosition, ecs);
                    }

                    ResultSet rs = sqlControl.executeStatementQuery(mconn, sizeStmt, ps);
                    try
                    {
                        if (!rs.next())
                        {
                            throw new NucleusDataStoreException(localiser.msg("056007", sizeStmt));
                        }

                        numRows = rs.getInt(1);
                        SQLWarnings.log(rs);
                    }
                    finally
                    {
                        rs.close();
                    }
                }
                finally
                {
                    sqlControl.closeStatement(mconn, ps);
                }
            }
            finally
            {
                mconn.release();
            }
        }
        catch (SQLException e)
        {
            throw new NucleusDataStoreException(localiser.msg("056007", sizeStmt), e);
        }

        return numRows;
    }

    /**
     * Generate statement for getting the size of thecontainer.
     * The order part is only present when an order mapping is used.
     * The discriminator part is only present when the element has a discriminator.
     * <PRE>
     * SELECT COUNT(*) FROM TBL THIS
     * [INNER JOIN ELEM_TBL ELEM ON TBL.COL = ELEM.ID] - when no null
     * [LEFT OUTER JOIN ELEM_TBL ELEM ON TBL.COL = ELEM.ID] - when allows null
     * WHERE THIS.OWNERCOL=?
     * [AND THIS.ORDERCOL IS NOT NULL]
     * [AND (DISCRIMINATOR=? OR DISCRMINATOR=? OR DISCRIMINATOR=? [OR DISCRIMINATOR IS NULL])]
     * [AND RELATION_DISCRIM=?]
     * </PRE>
     * The discriminator part includes all subclasses of the element type.
     * If the element is in a different table to the container then an INNER JOIN will be present to
     * link the two tables, and table aliases will be present also.
     * TODO Update this to allow for getting the size when more than 1 element table.
     *
     * @return The Statement returning the size of the container.
     */
    protected String getSizeStmt(ElementContainerStore ecs)
    {
        if (sizeStmt != null && !usingDiscriminatorInSizeStmt)
        {
            // Statement exists and didnt need any discriminator when setting up the statement so just reuse it
            return sizeStmt;
        }

        boolean allowNulls = false;
        if (ecs.getOwnerMemberMetaData() != null &&
            ecs.getOwnerMemberMetaData().hasExtension("allow-nulls") &&
            ecs.getOwnerMemberMetaData().getValueForExtension("allow-nulls").equalsIgnoreCase("true"))
        {
            allowNulls = true;
        }

        StringBuffer stmt = new StringBuffer();
        String containerAlias = "THIS";
        String joinedElementAlias = "ELEM";
        stmt.append("SELECT COUNT(*) FROM ");
        stmt.append(ecs.getContainerTable().toString()).append(" ").append(containerAlias);

        // Add join to element table if required (only allows for 1 element table currently)
        boolean joinedDiscrim = false;
        if (ecs.getElementInfo() != null && ecs.getElementInfo().length == 1 &&
            ecs.getElementInfo()[0].getDatastoreClass() != ecs.getContainerTable() &&
            ecs.getElementInfo()[0].getDiscriminatorMapping() != null)
        {
            // TODO Allow for more than 1 possible element table
            // Need join to the element table to restrict the discriminator
            joinedDiscrim = true;
            JavaTypeMapping elemIdMapping = ecs.getElementInfo()[0].getDatastoreClass().getIDMapping();
            if (allowNulls)
            {
                // User wants to allow for nulls so have to use left outer join
                stmt.append(" LEFT OUTER JOIN ");
            }
            else
            {
                // No nulls so use inner join
                stmt.append(" INNER JOIN ");
            }
            stmt.append(ecs.getElementInfo()[0].getDatastoreClass().toString()).append(" ").append(joinedElementAlias).append(" ON ");
            for (int i = 0; i < ecs.getElementMapping().getNumberOfDatastoreFields(); i++)
            {
                if (i > 0)
                {
                    stmt.append(" AND ");
                }
                stmt.append(containerAlias).append(".")
                    .append(ecs.getElementMapping().getDataStoreMapping(i).getDatastoreField().getIdentifier());
                stmt.append("=");
                stmt.append(joinedElementAlias).append(".")
                    .append(elemIdMapping.getDataStoreMapping(i).getDatastoreField().getIdentifier());
            }
        }

        stmt.append(" WHERE ");
        for (int i = 0; i < ecs.getOwnerMapping().getNumberOfDatastoreFields(); i++)
        {
            if (i > 0)
            {
                stmt.append(" AND ");
            }
            stmt.append(containerAlias).append(".")
                .append(ecs.getOwnerMapping().getDataStoreMapping(i).getDatastoreField().getIdentifier().toString());
            stmt.append("=");
            stmt.append(((RDBMSMapping) ecs.getOwnerMapping().getDataStoreMapping(i)).getUpdateInputParameter());
        }

        if (ecs.getOrderMapping() != null)
        {
            // If an ordering is present, restrict to items where the index is not null to
            // eliminate records that are added but may not be positioned yet.
            for (int i = 0; i < ecs.getOrderMapping().getNumberOfDatastoreFields(); i++)
            {
                stmt.append(" AND ");
                stmt.append(containerAlias).append(".")
                    .append(ecs.getOrderMapping().getDataStoreMapping(i).getDatastoreField().getIdentifier().toString());
                stmt.append(">=0");
            }
        }

        if (ecs.getElementInfo() != null && ecs.getElementInfo().length == 1)
        {
            // TODO Support more than one element table
            // Add a discriminator filter for collections with an element discriminator
            StringBuffer discrStmt = new StringBuffer();
            for (int i = 0; i < ecs.getElementInfo().length; i++)
            {
                if (ecs.getElementInfo()[i].getDiscriminatorMapping() != null)
                {
                    usingDiscriminatorInSizeStmt = true;
                    if (discrStmt.length() > 0)
                    {
                        discrStmt.append(" OR ");
                    }
                    JavaTypeMapping discrimMapping = ecs.getElementInfo()[i].getDiscriminatorMapping();
                    for (int j = 0; j < discrimMapping.getNumberOfDatastoreFields(); j++)
                    {
                        if (joinedDiscrim)
                        {
                            discrStmt.append(joinedElementAlias);
                        }
                        else
                        {
                            discrStmt.append(containerAlias);
                        }
                        discrStmt.append(".");
                        discrStmt.append(discrimMapping.getDataStoreMapping(j).getDatastoreField().getIdentifier().toString());
                        discrStmt.append("=");
                        discrStmt.append(((RDBMSMapping) discrimMapping.getDataStoreMapping(j)).getUpdateInputParameter());
                    }

                    HashSet subclasses = storeMgr.getSubClassesForClass(ecs.getElementInfo()[i].getClassName(), true, clr);
                    if (subclasses != null && subclasses.size() > 0)
                    {
                        for (int j = 0; j < subclasses.size(); j++)
                        {
                            for (int k = 0; k < discrimMapping.getNumberOfDatastoreFields(); k++)
                            {
                                discrStmt.append(" OR ");
                                if (joinedDiscrim)
                                {
                                    discrStmt.append(joinedElementAlias);
                                }
                                else
                                {
                                    discrStmt.append(containerAlias);
                                }
                                discrStmt.append(".");
                                discrStmt.append(discrimMapping.getDataStoreMapping(k).getDatastoreField().getIdentifier().toString());
                                discrStmt.append("=");
                                discrStmt.append(((RDBMSMapping) discrimMapping.getDataStoreMapping(k)).getUpdateInputParameter());
                            }
                        }
                    }
                }
            }
            if (discrStmt.length() > 0)
            {
                stmt.append(" AND (");
                stmt.append(discrStmt);
                if (allowNulls)
                {
                    stmt.append(" OR ");
                    stmt.append(
                        ecs.getElementInfo()[0].getDiscriminatorMapping().getDataStoreMapping(0).getDatastoreField()
                            .getIdentifier().toString());
                    stmt.append(" IS NULL");
                }
                stmt.append(")");
            }
        }
        if (ecs.getRelationDiscriminatorMapping() != null)
        {
            for (int i = 0; i < ecs.getRelationDiscriminatorMapping().getNumberOfDatastoreFields(); i++)
            {
                stmt.append(" AND ");
                stmt.append(containerAlias).append(".")
                    .append(ecs.getRelationDiscriminatorMapping().getDataStoreMapping(i).getDatastoreField().getIdentifier().toString());
                stmt.append("=");
                stmt.append(((RDBMSMapping) ecs.getRelationDiscriminatorMapping().getDataStoreMapping(i)).getUpdateInputParameter());
            }
        }

        sizeStmt = stmt.toString();
        return sizeStmt;
    }

    /**
     * Convenience method to populate the passed PreparedStatement with the value from the element
     * discriminator, optionally including all subclasses of the element type.
     *
     * @param om                Persistence Manager
     * @param ps                The PreparedStatement
     * @param jdbcPosition      Position in JDBC statement to populate
     * @param includeSubclasses Whether to include subclasses
     * @param info              The element information
     * @return The next position in the JDBC statement
     */
    protected int populateElementDiscriminatorInStatement(ObjectManager om,
                                                          PreparedStatement ps,
                                                          int jdbcPosition,
                                                          boolean includeSubclasses,
                                                          ElementContainerStore.ElementInfo info)
    {
        DiscriminatorStrategy strategy = info.getDiscriminatorStrategy();
        JavaTypeMapping discrimMapping = info.getDiscriminatorMapping();

        // Include element type
        if (strategy == DiscriminatorStrategy.CLASS_NAME)
        {
            discrimMapping.setObject(om, ps, ExpressionHelper.getParametersIndex(jdbcPosition, discrimMapping),
                info.getClassName());
            jdbcPosition += discrimMapping.getNumberOfDatastoreFields();
        }
        else
        {
            if (strategy == DiscriminatorStrategy.VALUE_MAP)
            {
                discrimMapping.setObject(om, ps, ExpressionHelper.getParametersIndex(jdbcPosition, discrimMapping),
                    info.getAbstractClassMetaData().getInheritanceMetaData().getDiscriminatorMetaData().getValue());
                jdbcPosition += discrimMapping.getNumberOfDatastoreFields();
            }
        }

        // Include all subclasses
        if (includeSubclasses)
        {
            HashSet subclasses = storeMgr.getSubClassesForClass(info.getClassName(), true, clr);
            if (subclasses != null && subclasses.size() > 0)
            {
                Iterator iter = subclasses.iterator();
                while (iter.hasNext())
                {
                    String subclass = (String) iter.next();
                    if (strategy == DiscriminatorStrategy.CLASS_NAME)
                    {
                        discrimMapping.setObject(om, ps, ExpressionHelper.getParametersIndex(jdbcPosition,
                            discrimMapping), subclass);
                        jdbcPosition += discrimMapping.getNumberOfDatastoreFields();
                    }
                    else
                    {
                        if (strategy == DiscriminatorStrategy.VALUE_MAP)
                        {
                            AbstractClassMetaData subclassCmd = storeMgr.getOMFContext().getMetaDataManager()
                                .getMetaDataForClass(subclass, clr);
                            discrimMapping.setObject(om, ps, ExpressionHelper.getParametersIndex(jdbcPosition,
                                discrimMapping),
                                subclassCmd.getInheritanceMetaData().getDiscriminatorMetaData().getValue());
                            jdbcPosition += discrimMapping.getNumberOfDatastoreFields();
                        }
                    }
                }
            }
        }
        return jdbcPosition;
    }

    /**
     * Helper method to get the SQLController.
     *
     * @return The sql controller
     */
    protected SQLController getSQLController()
    {
        return storeMgr.getSQLController();
    }

    protected String getStatementTextForQuery(QueryExpression stmt, boolean useUpdateLock)
    {
        return storeMgr.getStatementTextForQuery(stmt, useUpdateLock);
    }

    protected PreparedStatement getStatementForQuery(QueryExpression qs, ObjectManager om,
                                                     ManagedConnection conn, boolean updateLock, String resultSetType,
                                                     String resultSetConcurrency)
        throws SQLException
    {
        return storeMgr.getStatementForQuery(qs, om, conn, updateLock, resultSetType, resultSetConcurrency);
    }

    /**
     * Convenience method to populate the passed PreparedStatement with the value for the order index.
     *
     * @param om           Object Manager
     * @param ps           The PreparedStatement
     * @param idx          The order value
     * @param jdbcPosition Position in JDBC statement to populate
     * @param orderMapping The order mapping
     * @return The next position in the JDBC statement
     */
    protected int populateOrderInStatement(ObjectManager om, Object ps, int idx, int jdbcPosition, JavaTypeMapping orderMapping)
    {
        orderMapping.setObject(om, ps, ExpressionHelper.getParametersIndex(jdbcPosition, orderMapping), new Integer(idx));
        return jdbcPosition + orderMapping.getNumberOfDatastoreFields();
    }


    /**
     * Convenience method to populate the passed PreparedStatement with the field values from
     * the embedded element starting at the specified jdbc position.
     *
     * @param sm State Manager of the owning container
     * @param element The embedded element
     * @param ps The PreparedStatement
     * @param jdbcPosition JDBC position in the statement to start at
     * @param ownerFieldMetaData The meta data for the owner field
     * @param bcs Container store
     * @return The next JDBC position
     */
    protected int populateEmbeddedElementFieldsInStatement(StateManager sm, Object element, Object ps,
            int jdbcPosition, AbstractMemberMetaData ownerFieldMetaData, JavaTypeMapping elementMapping,
            AbstractClassMetaData emd, BaseContainerStore bcs)
    {
        EmbeddedElementPCMapping embeddedMapping = (EmbeddedElementPCMapping) elementMapping;
        StatementMappingIndex[] stmtMappings =
            new StatementMappingIndex[emd.getNoOfManagedMembers() + emd.getNoOfInheritedManagedMembers()];
        int[] elementFieldNumbers = new int[embeddedMapping.getNumberOfJavaTypeMappings()];
        for (int i = 0; i < embeddedMapping.getNumberOfJavaTypeMappings(); i++)
        {
            JavaTypeMapping fieldMapping = embeddedMapping.getJavaTypeMapping(i);
            int absFieldNum = emd.getAbsolutePositionOfMember(fieldMapping.getMemberMetaData().getName());
            elementFieldNumbers[i] = absFieldNum;
            if (fieldMapping != null)
            {
                stmtMappings[absFieldNum] = new StatementMappingIndex(fieldMapping);
                int[] jdbcParamPositions = new int[fieldMapping.getNumberOfDatastoreFields()];
                for (int j = 0; j < fieldMapping.getNumberOfDatastoreFields(); j++)
                {
                    jdbcParamPositions[j] = jdbcPosition++;
                }
                stmtMappings[absFieldNum].setParameterPositions(jdbcParamPositions);
            }
        }

        StateManager elementSM = bcs.getStateManagerForEmbeddedPCObject(sm, element, ownerFieldMetaData);
        elementSM.setPcObjectType(StateManager.EMBEDDED_COLLECTION_ELEMENT_PC);
        FieldManager fm = storeMgr.getFieldManagerForStatementGeneration(elementSM, ps,
            stmtMappings, true);
        elementSM.provideFields(elementFieldNumbers, fm);

        return jdbcPosition;
    }

    /**
     * Convenience method to populate the passed PreparedStatement with the value for the element.
     * Not used with embedded PC elements.
     * @param om Object Manager
     * @param ps The PreparedStatement
     * @param element The element
     * @param jdbcPosition Position in JDBC statement to populate
     * @return The next position in the JDBC statement
     */
    protected int populateElementInStatement(ObjectManager om, Object ps, Object element, int jdbcPosition, 
            JavaTypeMapping elementMapping, MappedStoreManager storeMgr)
    {
        if (!storeMgr.insertValuesOnInsert(elementMapping.getDataStoreMapping(0)))
        {
            // Don't try to insert any mappings with insert parameter that isn't ? (e.g Oracle)
            return jdbcPosition;
        }
        elementMapping.setObject(om, ps, ExpressionHelper.getParametersIndex(jdbcPosition, elementMapping), element);
        return jdbcPosition + elementMapping.getNumberOfDatastoreFields();
    }
}