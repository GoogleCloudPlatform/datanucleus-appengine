package org.datanucleus.store.rdbms.scostore;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Iterator;

import org.datanucleus.ClassLoaderResolver;
import org.datanucleus.ManagedConnection;
import org.datanucleus.ObjectManager;
import org.datanucleus.StateManager;
import org.datanucleus.Transaction;
import org.datanucleus.exceptions.NucleusDataStoreException;
import org.datanucleus.exceptions.NucleusException;
import org.datanucleus.metadata.AbstractMemberMetaData;
import org.datanucleus.store.exceptions.NotYetFlushedException;
import org.datanucleus.store.mapped.DatastoreContainerObject;
import org.datanucleus.store.mapped.exceptions.MappedDatastoreException;
import org.datanucleus.store.mapped.expression.QueryExpression;
import org.datanucleus.store.mapped.scostore.AbstractArrayStore;
import org.datanucleus.store.mapped.scostore.AbstractArrayStoreSpecialization;
import org.datanucleus.store.mapped.scostore.ElementContainerStore;
import org.datanucleus.store.query.ResultObjectFactory;
import org.datanucleus.store.rdbms.RDBMSManager;
import org.datanucleus.store.rdbms.SQLController;
import org.datanucleus.store.rdbms.table.JoinTable;
import org.datanucleus.util.Localiser;

/**
 * RDBMS-specific implementation of an {@link AbstractArrayStoreSpecialization}.
 */
public class RDBMSAbstractArrayStoreSpecialization extends RDBMSAbstractCollectionStoreSpecialization implements
    AbstractArrayStoreSpecialization
{
    public RDBMSAbstractArrayStoreSpecialization(Localiser localiser, ClassLoaderResolver clr, 
            RDBMSManager storeMgr)
    {
        super(localiser, clr, storeMgr);
    }

    public void clear(StateManager ownerSM, ElementContainerStore ecs)
    {
        String clearStmt = getClearStmt(ecs);
        try
        {
            ObjectManager om = ownerSM.getObjectManager();
            ManagedConnection mconn = ecs.getStoreManager().getConnection(om);
            SQLController sqlControl = getSQLController();
            try
            {
                PreparedStatement ps = sqlControl.getStatementForUpdate(mconn, clearStmt, false);
                try
                {
                    int jdbcPosition = 1;
                    jdbcPosition = populateOwnerInStatement(ownerSM, om, ps, jdbcPosition, ecs);
                    if (ecs.getRelationDiscriminatorMapping() != null)
                    {
                        jdbcPosition = populateRelationDiscriminatorInStatement(om, ps, jdbcPosition, ecs);
                    }

                    sqlControl.executeStatementUpdate(mconn, clearStmt, ps, true);
                }
                finally
                {
                    sqlControl.closeStatement(mconn, ps);
                }
            }
            finally
            {
                mconn.release();
            }
        }
        catch (SQLException e)
        {
            throw new NucleusDataStoreException(localiser.msg("056013", clearStmt), e);
        }
    }

    /**
     * Internal method to add a row to the join table.
     * Used by add() and set() to add a row to the join table.
     * @param sm StateManager for the owner of the collection
     * @param element The element to add the relation to
     * @param conn The connection
     * @param batched Whether we are batching
     * @param orderId The order id to use for this element relation
     * @param executeNow Whether to execute the statement now (and not wait for any batch)
     * @return Whether a row was inserted
     * @throws SQLException Thrown if an error occurs
     */
    public int[] internalAdd(StateManager sm, AbstractArrayStore aas, Object element, ManagedConnection conn, 
            boolean batched, int orderId, boolean executeNow)
        throws MappedDatastoreException
    {
        ObjectManager om = sm.getObjectManager();
        SQLController sqlControl = getSQLController();
        String addStmt = getAddStmt(aas);
        try
        {
            PreparedStatement ps = sqlControl.getStatementForUpdate(conn, addStmt, false);
            boolean notYetFlushedError = false;
            try
            {
                // Insert the join table row
                int jdbcPosition = 1;
                jdbcPosition = populateOwnerInStatement(sm, om, ps, jdbcPosition, aas);
                jdbcPosition = populateElementInStatement(om, ps, element, jdbcPosition, aas.getElementMapping(), aas.getStoreManager());
                jdbcPosition = populateOrderInStatement(om, ps, orderId, jdbcPosition, aas.getOrderMapping());
                if (aas.getRelationDiscriminatorMapping() != null)
                {
                    jdbcPosition = populateRelationDiscriminatorInStatement(om, ps, jdbcPosition, aas);
                }

                // Execute the statement
                return sqlControl.executeStatementUpdate(conn, addStmt, ps, executeNow);
            }
            catch (NotYetFlushedException nfe)
            {
                notYetFlushedError = true;
                throw nfe;
            }
            finally
            {
                if (notYetFlushedError)
                {
                    sqlControl.abortStatementForConnection(conn, ps);
                }
                else
                {
                    sqlControl.closeStatement(conn, ps);
                }
            }
        }
        catch (SQLException e)
        {
            throw new MappedDatastoreException(addStmt, e);
        }
    }

    public Iterator iterator(ElementContainerStore ecs, StateManager ownerSM, ObjectManager om, Transaction tx,
            boolean useUpdateLock, QueryExpression stmt, ResultObjectFactory rof)
    {
        String statement = getStatementTextForQuery(stmt, useUpdateLock);
        if (statement == null)
        {
            // this happens when collection is null
            throw new NucleusException(localiser.msg("056005")).setFatal();
        }

        Iterator iter;
        try
        {
            ManagedConnection mconn = ecs.getStoreManager().getConnection(om);
            SQLController sqlControl = getSQLController();
            try
            {
                PreparedStatement ps = getStatementForQuery(stmt, om, mconn, useUpdateLock, null, null);
                try
                {
                    ResultSet rs = sqlControl.executeStatementQuery(mconn, statement, ps);
                    try
                    {
                        iter = new RDBMSArrayStoreIterator(ownerSM, rs, rof, ecs);
                    }
                    finally
                    {
                        rs.close();
                    }
                }
                finally
                {
                    sqlControl.closeStatement(mconn, ps);
                }
            }
            finally
            {
                mconn.release();
            }
        }
        catch (SQLException e)
        {
            throw new NucleusDataStoreException(localiser.msg("056006", statement), e);
        }
        catch (MappedDatastoreException e)
        {
            throw new NucleusDataStoreException(localiser.msg("056006", statement), e.getCause());
        }

        return iter;
    }

    private static class RDBMSArrayStoreIterator extends AbstractArrayStore.ArrayStoreIterator
    {
        private RDBMSArrayStoreIterator(StateManager sm, ResultSet rs, ResultObjectFactory rof, 
                ElementContainerStore ecs) throws MappedDatastoreException
        {
            super(sm, rs, rof, ecs);
        }

        protected AbstractMemberMetaData getOwnerFieldMetaData(DatastoreContainerObject containerTable)
        {
            return ((JoinTable) containerTable).getOwnerMemberMetaData();
        }

        protected boolean next(Object rs) throws MappedDatastoreException
        {
            try
            {
                return ((ResultSet) rs).next();
            }
            catch (SQLException e)
            {
                throw new MappedDatastoreException("SQLException", e);
            }
        }
    }

    public void processBatchedWrites(ManagedConnection mconn) throws MappedDatastoreException
    {
        SQLController sqlControl = getSQLController();
        try
        {
            sqlControl.processStatementsForConnection(mconn); // Process all waiting batched statements before we start our work
        }
        catch (SQLException e)
        {
            throw new MappedDatastoreException("SQLException", e);
        }
    }
}