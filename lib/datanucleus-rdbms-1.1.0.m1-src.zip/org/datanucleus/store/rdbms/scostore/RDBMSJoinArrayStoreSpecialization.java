package org.datanucleus.store.rdbms.scostore;

import org.datanucleus.store.mapped.scostore.JoinArrayStoreSpecialization;
import org.datanucleus.store.rdbms.RDBMSManager;
import org.datanucleus.util.Localiser;
import org.datanucleus.ClassLoaderResolver;

/**
 * RDBMS-specific implementation of an {@link JoinArrayStoreSpecialization}.
 */
public class RDBMSJoinArrayStoreSpecialization extends RDBMSAbstractArrayStoreSpecialization implements JoinArrayStoreSpecialization
{
    public RDBMSJoinArrayStoreSpecialization(Localiser localiser, ClassLoaderResolver clr, 
            RDBMSManager storeMgr)
    {
        super(localiser, clr, storeMgr);
    }
}