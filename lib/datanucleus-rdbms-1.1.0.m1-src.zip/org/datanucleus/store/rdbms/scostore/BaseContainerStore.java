/**********************************************************************
Copyright (c) 2005 Andy Jefferson and others. All rights reserved. 
Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License. 
 

Contributors:
    ...
**********************************************************************/
package org.datanucleus.store.rdbms.scostore;

import java.sql.PreparedStatement;

import org.datanucleus.ObjectManager;
import org.datanucleus.StateManager;
import org.datanucleus.metadata.AbstractMemberMetaData;
import org.datanucleus.state.StateManagerFactory;
import org.datanucleus.store.StoreManager;
import org.datanucleus.store.mapped.DatastoreAdapter;
import org.datanucleus.store.mapped.mapping.InterfaceMapping;
import org.datanucleus.store.mapped.mapping.JavaTypeMapping;
import org.datanucleus.store.mapped.mapping.OIDMapping;
import org.datanucleus.store.rdbms.RDBMSManager;
import org.datanucleus.store.rdbms.adapter.RDBMSAdapter;
import org.datanucleus.store.rdbms.mapping.RDBMSMapping;
import org.datanucleus.store.rdbms.table.JoinTable;
import org.datanucleus.util.Localiser;

/**
 * Base class for all RDBMS container stores (collections, maps, arrays).
 * Provides a series of helper methods for handling the store process.
 *
 * @version $revision$
 */
abstract class BaseContainerStore
{
    /** Localiser for messages. */
    protected static final Localiser LOCALISER = Localiser.getInstance("org.datanucleus.store.rdbms.Localisation",
        RDBMSManager.class.getClassLoader());

    /** Manager for the store. */
    protected RDBMSManager storeMgr;

    /** Datastore adapter in use by this store. */
    protected DatastoreAdapter dba;

    /** Mapping to the owner of the container. */
    protected JavaTypeMapping ownerMapping;

    /** MetaData for the field/property in the owner with this container. */
    protected AbstractMemberMetaData ownerMemberMetaData;

    /** Whether the container allows null elements/values. */
    protected boolean allowsNull = false;

    /**
     * Constructor.
     * @param storeMgr Manager for the datastore being used
     */
    protected BaseContainerStore(StoreManager storeMgr)
    {
        this.storeMgr = (RDBMSManager)storeMgr;
        this.dba = this.storeMgr.getDatastoreAdapter();
    }

    /**
     * Method to set the owner field/property MetaData and sets whether null elements/values are allowed.
     * @param mmd MetaData for the field/property owning this backing store.
     */
    protected void setOwnerMemberMetaData(AbstractMemberMetaData mmd)
    {
        this.ownerMemberMetaData = mmd;
        if (ownerMemberMetaData.hasExtension("allow-nulls") &&
            ownerMemberMetaData.getValueForExtension("allow-nulls").equalsIgnoreCase("true"))
        {
            // User has requested allowing nulls in this field/property
            allowsNull = true;
        }
    }

    /**
     * Accessor for the RDBMSManager.
     * @return The RDBMSManager.
     */
    public StoreManager getStoreManager()
    {
        return storeMgr;
    }

    /**
     * Accessor for the owner mapping.
     * @return Owner mapping.
     */
    public JavaTypeMapping getOwnerMapping()
    {
        return ownerMapping;
    }

    /**
     * Check if the mapping correspond to a non pc object or embedded field
     * @param mapping the mapping
     * @return true if the field is embedded into one column
     */
    protected boolean isEmbeddedMapping(JavaTypeMapping mapping)
    {
        return !InterfaceMapping.class.isAssignableFrom(mapping.getClass()) &&
               !OIDMapping.class.isAssignableFrom(mapping.getClass());
    }

    /**
     * Convenience method to populate the passed PreparedStatement with the value from the owner.
     * @param sm State Manager
     * @param om Object Manager
     * @param ps The PreparedStatement
     * @param jdbcPosition Position in JDBC statement to populate
     * @return The next position in the JDBC statement
     */
    protected int populateOwnerInStatement(StateManager sm, ObjectManager om, PreparedStatement ps, int jdbcPosition)
    {
        if (!((RDBMSMapping)ownerMapping.getDataStoreMapping(0)).insertValuesOnInsert())
        {
            // Dont try to insert any mappings with insert parameter that isnt ? (e.g Oracle)
            return jdbcPosition;
        }
        if (ownerMemberMetaData != null)
        {
            ownerMapping.setObject(om, ps, 
                org.datanucleus.store.mapped.mapping.Mappings.getParametersIndex(jdbcPosition, ownerMapping),
                sm.getObject(),  sm, ownerMemberMetaData.getAbsoluteFieldNumber());
        }
        else
        {
            ownerMapping.setObject(om, ps, 
                org.datanucleus.store.mapped.mapping.Mappings.getParametersIndex(jdbcPosition, ownerMapping), 
                sm.getObject());
        }
        return jdbcPosition + ownerMapping.getNumberOfDatastoreFields();
    }

    /**
     * Method to return the StateManager for an embedded PC object (element, key, value).
     * It creates one if the element is not currently managed.
     * @param sm State Manager of the owner
     * @param obj The embedded PC object
     * @param table Join table where the objects are stored
     * @return The state manager
     */
    protected StateManager getStateManagerForEmbeddedPCObject(StateManager sm, Object obj, JoinTable table)
    {
        ObjectManager om = sm.getObjectManager();
        StateManager objSM = om.findStateManager(obj);
        if (objSM == null)
        {
            objSM = StateManagerFactory.newStateManagerForEmbedded(om, obj, false);

            AbstractMemberMetaData ownerFmd = table.getOwnerFieldMetaData();
            objSM.addEmbeddedOwner(sm, ownerFmd.getAbsoluteFieldNumber());
        }
        return objSM;
    }

    /**
     * Convenience method to return if the RDBMS supports batching and the user wants batching.
     * @return If batching of statements is permissible
     */
    protected boolean allowsBatching()
    {
        if (((RDBMSAdapter)dba).supportsOption(RDBMSAdapter.STATEMENT_BATCHING) &&
            storeMgr.getOMFContext().getPersistenceConfiguration().getIntProperty("datanucleus.rdbms.statementBatchLimit") != 0)
        {
            return true;
        }
        return false;
    }
}
