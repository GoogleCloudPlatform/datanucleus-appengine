/**********************************************************************
Copyright (c) 2003 Erik Bengtson and others. All rights reserved. 
Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License. 
 

Contributors:
    ...
**********************************************************************/
package org.datanucleus.store.mapped;

import org.datanucleus.store.mapped.mapping.JavaTypeMapping;

/**
 * Maintain an index for the mapping field vs columns in a JDBC statement.
 * Each field for a Request (in a Statement) must have one instance of this
 * containing the field Number + Mapping + the columns
 * <PRE> 
 * e.g.
 * CLASS                 FIELDNUMBER     MAPPING            TABLE                EXPRESSION INDEX (JDBC)
 * -----------------     -----------     --------------     ----------------     ----------------
 * class A           -->             -->                --> TABLE_A            
 * {
 *    int fieldA;    --> 1           --> IntegerMapping --> COL_FIELDA       --> 1
 *    String fieldB; --> 2           --> StringMapping  --> COL_FIELDB_PART1 --> 2
 *                   -->             -->                --> COL_FIELDB_PART2 --> 3
 *    ...
 * }
 * </PRE> 
 */
public class StatementExpressionIndex
{
    /** the mapping to the field **/
    JavaTypeMapping mapping;

    /** the index for a column in the statement **/
    int[] expressionIndex;

    /** the index for a parameter in the statement **/
    int[] parameterIndex;

    /** Any name applied in the field selection (SELECT xxx AS yyy). Only applies for cases with 1 column. */
    String columnName;

    /**
     * Accessor for the expression index(es).
     * @return The expression index
     */
    public int[] getExpressionIndex()
    {
        return expressionIndex;
    }

    /**
     * Accessor for the mapping for the field.
     * @return The mapping
     */
    public JavaTypeMapping getMapping()
    {
        return mapping;
    }

    /**
     * Accessor for the column name (if any).
     * @return The column name.
     */
    public String getColumnName()
    {
        if (columnName != null)
        {
            return columnName;
        }
        else if (mapping != null && mapping.getFieldMetaData() != null)
        {
            return mapping.getFieldMetaData().getName();
        }
        return null;
    }

    /**
     * Mutator for the JDBC expression index(es).
     * This is the position in the JDBC result set.
     * @param is The expression index
     */
    public void setExpressionIndex(int[] is)
    {
        expressionIndex = is;
    }

    /**
     * Mutator for the mapping for the field.
     * @param mapping The mapping
     */
    public void setMapping(JavaTypeMapping mapping)
    {
        this.mapping = mapping;
    }

    /**
     * Mutator for the column name (alias).
     * Overrides the name of the field that the mapping refers to.
     * @param colName The name of the column (alias).
     */
    public void setColumnName(String colName)
    {
        this.columnName = colName;
    }

    /**
     * Accessor for the parameter index(es).
     * @return The parameter index
     */
    public int[] getParameterIndex()
    {
        return parameterIndex;
    }

    /**
     * @param is The parameter index
     */
    public void setParameterIndex(int[] is)
    {
        parameterIndex = is;
    }

    /**
     * Method to return a string version of this object.
     * @return String version
     **/
    public String toString()
    {
        StringBuffer buffer = new StringBuffer();
        buffer.append("mapping: "+mapping);
        buffer.append("\n");
        buffer.append("parameterIndex: "+parameterIndex);
        buffer.append("\n");
        buffer.append("expressionIndex: "+expressionIndex);
        buffer.append("\n");
        return buffer.toString();
    }
}