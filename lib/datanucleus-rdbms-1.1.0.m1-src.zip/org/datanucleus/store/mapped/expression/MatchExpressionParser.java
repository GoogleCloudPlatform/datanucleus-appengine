/**********************************************************************
Copyright (c) 2004 Erik Bengtson and others. All rights reserved.
Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.

Contributors:
    ...
**********************************************************************/
package org.datanucleus.store.mapped.expression;

import java.text.CharacterIterator;
import java.text.StringCharacterIterator;

/**
 * Parser for a Match Expression.
 **/
public class MatchExpressionParser
{
    private final String input;
    private final CharacterIterator ci;
    private final char zeroOrMoreChar;
    private final char anyChar;
    private final char escapeChar;

    /**
     * Constructor
     * @param input 
     *              The input string
     * @param zeroOrMoreChar 
     *              The pattern string for representing zero or more characters.
     *              Most of databases will use the percent sign character.
     * @param anyChar
     *              The pattern string for representing one character.
     *              Most of databases will use the underscore character.
     * @param escapeChar
     *              The pattern string for representing to escape zeroOrMoreChar or anyChar.
     *              Most of databases will use the backslash \ character.
     **/
    public MatchExpressionParser(String input, char zeroOrMoreChar, char anyChar, char escapeChar)
    {
        this.input = input;
        this.zeroOrMoreChar = zeroOrMoreChar;
        this.anyChar = anyChar;
        this.escapeChar =escapeChar;
        ci = new StringCharacterIterator(input);
    }

    private boolean parseNextChar(char c)
    {
        int savedIdx = ci.getIndex();
        if (ci.next() == c)
        {
            return true;
        }
        else
        {
            ci.setIndex(savedIdx);
            return false;
        }
    }

    /**
     * Parse a pattern expression
     * @return the parsed expression
     */
    public String parsePattern()
    {
        StringBuffer lit = new StringBuffer();
        char c;

        while ( (c = ci.current()) != CharacterIterator.DONE)
        {

            if (c == '\\') //escape for java match expression 
            {
                lit.append( parseEscapedCharacter() );
            }
            else if( c == '.' )
            {
                if( parseNextChar('*') )
                {
                    lit.append(zeroOrMoreChar);
                }
                else
                {
                    lit.append(anyChar);                    
                }
            }           
            else if( c == anyChar )
            {
                lit.append( "" + escapeChar + anyChar );
            }           
            else if( c == zeroOrMoreChar )
            {
                lit.append( "" + escapeChar + zeroOrMoreChar );
            }           
            else
            {
                lit.append(c);
            }
            ci.next();
        }

        return lit.toString();
    }

    private String parseEscapedCharacter()
    {
        char c;

        c = ci.next();
        if( c == CharacterIterator.DONE )
        {
            return escapeChar + "\\";
        }
        else if( c == '.' )
        {
            return ".";
        }
        else if( c == '\\' )
        {
            // Creating a new String with \\ will swallow the escape \, so we add it back on
            // Added as a specific case as a reminder that we need to retain the escaping
            return escapeChar + "\\" + escapeChar + c;
        }
        return escapeChar + "\\" + c;
    }

    public String toString()
    {
        return input;
    }
}