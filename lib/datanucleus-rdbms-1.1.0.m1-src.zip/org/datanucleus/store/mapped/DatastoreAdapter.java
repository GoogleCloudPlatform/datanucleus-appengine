/**********************************************************************
Copyright (c) 2005 Erik Bengtson and others. All rights reserved.
Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
 

Contributors:
    ...
**********************************************************************/
package org.datanucleus.store.mapped;

import java.sql.Timestamp;
import java.util.Collection;

import org.datanucleus.ClassLoaderResolver;
import org.datanucleus.ManagedConnection;
import org.datanucleus.store.mapped.expression.ExpressionConversionAdapter;
import org.datanucleus.store.mapped.expression.ExpressionLogicSetAdapter;
import org.datanucleus.store.mapped.expression.ExpressionMethodAdapter;
import org.datanucleus.store.mapped.expression.ExpressionOperatorAdapter;
import org.datanucleus.store.mapped.expression.ExpressionPatternAdapter;
import org.datanucleus.store.mapped.expression.NumericExpression;
import org.datanucleus.store.mapped.expression.QueryExpression;
import org.datanucleus.store.mapped.expression.ScalarExpression;
import org.datanucleus.store.mapped.mapping.JavaTypeMapping;
import org.datanucleus.store.mapped.mapping.MappingManager;
import org.datanucleus.store.schema.StoreSchemaHandler;

/**
 * Definition of a datastore adapter.
 */
public interface DatastoreAdapter extends ExpressionConversionAdapter, ExpressionOperatorAdapter, 
    ExpressionMethodAdapter, ExpressionPatternAdapter, ExpressionLogicSetAdapter
{
    /**
     * Whether this datastore adapter support identity fields.
     * The column could be things like "AUTOINCREMENT", "IDENTITY", "SERIAL" in SQL.
     */
    public static final String IDENTITY_COLUMNS = "IdentityColumns";

    /**
     * Whether we support sequences.
     */
    public static final String SEQUENCES = "Sequences";

    /**
     * Whether Types.BIT is really mapped as BOOLEAN.
     */
    public static final String BIT_IS_REALLY_BOOLEAN = "BitIsReallyBoolean";

    /**
     * Whether we support Boolean comparisons.
     */
    public static final String BOOLEAN_COMPARISON = "BooleanExpression";

    public static final String ESCAPE_EXPRESSION_IN_LIKE_PREDICATE = "EscapeExpressionInLikePredicate";

    /**
     * Whether this datastore supports "SELECT a.* FROM (SELECT * FROM TBL1 INNER JOIN TBL2 ON tbl1.x = tbl2.y ) a"
     * If the database does not support the SQL statement generated is like 
     * "SELECT a.* FROM (TBL1 INNER JOIN TBL2 ON tbl1.x = tbl2.y ) a"
     */
    public static final String PROJECTION_IN_TABLE_REFERENCE_JOINS = "ProjectionInTableReferenceJoins";

    /**
     * Accessor for whether the SQL extensions CUBE, ROLLUP are supported.
     */
    public static final String ANALYSIS_METHODS = "AnalysisMethods";

    /**
     * Accessor for the options that are supported by this datastore adapter and the underlying datastore.
     * @return The options (Collection<String>)
     */
    public Collection getSupportedOptions();

    /**
     * Accessor for whether the supplied option is supported.
     * @param option The option
     * @return Whether supported.
     */
    public boolean supportsOption(String option);

    /**
     * Accessor for the Mapping Manager for field mapping management.
     * @return The Mapping Manager.
     */
    public abstract MappingManager getMappingManager();

    /**
     * Accessor for the Vendor ID for this datastore.
     * @return Vendor id for this datastore
     */
    public abstract String getVendorID();

    /**
     * Initialise the types for this datastore.
     * @param handler SchemaHandler that we initialise the types for
     * @param mconn Managed connection to use
     */
    public void initialiseTypes(StoreSchemaHandler handler, ManagedConnection mconn);

    /**
     * Remove all mappings from the mapping manager that don't have a datastore type initialised.
     * @param handler Schema handler
     * @param mconn Managed connection to use
     */
    public void removeUnsupportedMappings(StoreSchemaHandler handler, ManagedConnection mconn);

    /**
     * Method to check if a word is reserved for this datastore.
     * @param word The word
     * @return Whether it is reserved
     */
    public abstract boolean isReservedKeyword(String word);

    /**
     * Creates the auxiliary functions/procedures in the datastore 
     * @param conn the connection to the datastore
     */
    public abstract void initialiseDatastore(Object conn);

    /**
     * Accessor for the quote string to use when quoting identifiers.
     * @return The quote string for the identifier
     */
    public abstract String getIdentifierQuoteString();

    /**
     * Accessor for a new query statement.
     * @param container The table to query 
     * @param rangeVar A range variable for the query
     * @param clr the ClassLoaderResolver
     * @return The Query Statement
     **/
    public abstract QueryExpression newQueryStatement(DatastoreContainerObject container, 
            DatastoreIdentifier rangeVar, ClassLoaderResolver clr);

    /**
     * Accessor for the mapping for the specified class assuming that the type is not serialised and not embedded.
     * @param c Java type
     * @param storeMgr the StoreManager
     * @return The mapping for the class.
     */
    public abstract JavaTypeMapping getMapping(Class c, MappedStoreManager storeMgr);

    /**
     * Accessor for the mapping for the specified class.
     * TODO Why use this and not the one with ClassLoaderResolver ?
     * @param c Java type
     * @param storeMgr the StoreManager
     * @param serialised Whether the type is serialised
     * @param embedded Whether the type is embedded
     * @param fieldName Name of field (for logging only)
     * @return The mapping for the class.
     */
    public abstract JavaTypeMapping getMapping(Class c, MappedStoreManager storeMgr, 
            boolean serialised, boolean embedded, String fieldName);

    /**
     * Accessor for the mapping for the specified class assuming that the type is not serialised and not embedded.
     * @param c Class to query
     * @param storeMgr The Store Manager
     * @param clr The ClassLoaderResolver
     * @return The mapping for the class.
     */
    public JavaTypeMapping getMapping(Class c, MappedStoreManager storeMgr, ClassLoaderResolver clr);

    /**
     * Accessor for the mapping for the specified class.
     * TODO Why use this and not the one without ClassLoaderResolver ?
     * @param c Class to query
     * @param storeMgr The Store Manager
     * @param clr The ClassLoaderResolver
     * @param serialised Whether the type is serialised
     * @param embedded Whether the type is embedded
     * @return The mapping for the class.
     */
    public JavaTypeMapping getMapping(Class c, MappedStoreManager storeMgr, ClassLoaderResolver clr, 
            boolean serialised, boolean embedded);

    /**
     * Utility to return the adapter time in case there are rounding issues with millisecs etc.
     * @param time The timestamp
     * @return The time in millisecs
     */
    public long getAdapterTime(Timestamp time);

    /**
     * Accessor for the datastore major version number.
     * @return Major version number
     */
    public int getDatastoreMajorVersion();

    /**
     * Accessor for the datastore minor version number.
     * @return Minor version number
     */
    public int getDatastoreMinorVersion();
    
    /**
     * Method to generate a modulus expression. The binary % operator is said to
     * yield the remainder of its operands from an implied division; the
     * left-hand operand is the dividend and the right-hand operand is the divisor.
     * @param operand1 the left expression
     * @param operand2 the right expression
     * @return The Expression for modulus
     */
    public NumericExpression modOperator(ScalarExpression operand1, ScalarExpression operand2);

    /**
     * Accessor for a numeric expression to represent the method call, with passed argument.
     * @param method The method (case insensitive)
     * @param expr The argument to the method
     * @return The numeric expression that results
     */
    public NumericExpression getNumericExpressionForMethod(String method, ScalarExpression expr);

    /**
     * Verifies if the given <code>columnDef</code> is an identity field type for the datastore.
     * @param columnDef the datastore type name
     * @return true when the <code>columnDef</code> has values for identity generation in the datastore
     **/
    boolean isIdentityFieldDataType(String columnDef);

    /**
     * Whether the datastore will support setting the query fetch size to the supplied value.
     * @param size The value to set to
     * @return Whether it is supported.
     */
    boolean supportsQueryFetchSize(int size);

    /**
     * Method to return this object as a string.
     * @return String version of this object.
     */
    public String toString();
}