/**********************************************************************
Copyright (c) 2007 Andy Jefferson and others. All rights reserved.
Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.

Contributors:
    ...
**********************************************************************/
package org.datanucleus.store.mapped.scostore;

import org.datanucleus.StateManager;
import org.datanucleus.ManagedConnection;
import org.datanucleus.store.mapped.mapping.JavaTypeMapping;
import org.datanucleus.store.mapped.MappedStoreManager;
import org.datanucleus.store.mapped.DatastoreContainerObject;
import org.datanucleus.store.mapped.exceptions.MappedDatastoreException;
import org.datanucleus.store.StoreManager;

/**
 * Specialization interface for {@link AbstractCollectionStore}.
 * {@link AbstractCollectionStore} delegates to instances of this interface for behavior
 * that is tied to a specific datastore implementation.
 */
public interface AbstractCollectionStoreSpecialization extends ElementContainerStoreSpecialization
{
    /**
     * @see AbstractCollectionStore#updateEmbeddedElement
     */
    boolean updateEmbeddedElement(StateManager sm, Object element, int fieldNumber, Object value, JavaTypeMapping fieldMapping,
        MappedStoreManager storeMgr, DatastoreContainerObject containerTable, JavaTypeMapping ownerMapping, JavaTypeMapping elementMapping,
        org.datanucleus.store.mapped.scostore.ElementContainerStore bcs);

    /**
     * @see AbstractCollectionStore#contains
     */
    boolean contains(StateManager sm, Object element, MappedStoreManager storeMgr, JavaTypeMapping ownerMapping,
        DatastoreContainerObject containerTable, JavaTypeMapping elementMapping, org.datanucleus.store.mapped.scostore.ElementContainerStore.ElementInfo[] elementInfo,
        JavaTypeMapping relationDiscriminatorMapping, boolean elementsAreSerialised, org.datanucleus.store.mapped.scostore.AbstractCollectionStore acs);

    /**
     * @see AbstractCollectionStore#internalRemove
     */
    int[] internalRemove(StateManager ownerSM, ManagedConnection conn, boolean batched, Object element, boolean executeNow,
        JavaTypeMapping relationDiscriminatorMapping, org.datanucleus.store.mapped.scostore.AbstractCollectionStore acs, org.datanucleus.store.mapped.scostore.ElementContainerStore.ElementInfo[] elementInfo,
        DatastoreContainerObject containerTable, JavaTypeMapping ownerMapping, JavaTypeMapping elementMapping,
        boolean elementsAreSerialised) throws MappedDatastoreException;

    /**
     * @see AbstractCollectionStore#getRemoveStmt
     */
    String getRemoveStmt(org.datanucleus.store.mapped.scostore.AbstractCollectionStore acs, org.datanucleus.store.mapped.scostore.ElementContainerStore.ElementInfo[] elementInfo,
        DatastoreContainerObject containerTable, JavaTypeMapping ownerMapping, JavaTypeMapping elementMapping,
        boolean elementsAreSerialised);

    /**
     * @see AbstractCollectionStore#getContainsStmt()  
     */
    String getContainsStmt(JavaTypeMapping ownerMapping, DatastoreContainerObject containerTable, JavaTypeMapping elementMapping,
        StoreManager storeMgr, org.datanucleus.store.mapped.scostore.ElementContainerStore.ElementInfo[] elementInfo, JavaTypeMapping relationDiscriminatorMapping,
        boolean elementsAreSerialised, org.datanucleus.store.mapped.scostore.AbstractCollectionStore acs);
}
