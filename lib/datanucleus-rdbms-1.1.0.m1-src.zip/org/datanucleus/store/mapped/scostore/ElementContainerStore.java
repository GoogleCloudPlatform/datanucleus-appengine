/**********************************************************************
Copyright (c) 2005 Andy Jefferson and others. All rights reserved.
Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License. 


Contributors:
    ...
**********************************************************************/
package org.datanucleus.store.mapped.scostore;

import java.util.Arrays;
import java.util.Collection;
import java.util.HashSet;
import java.util.Iterator;

import org.datanucleus.ClassLoaderResolver;
import org.datanucleus.FetchPlan;
import org.datanucleus.FetchPlan.FetchPlanForClass;
import org.datanucleus.ObjectManager;
import org.datanucleus.ObjectManagerHelper;
import org.datanucleus.StateManager;
import org.datanucleus.exceptions.NucleusUserException;
import org.datanucleus.metadata.AbstractClassMetaData;
import org.datanucleus.metadata.AbstractMemberMetaData;
import org.datanucleus.metadata.CollectionMetaData;
import org.datanucleus.metadata.DiscriminatorStrategy;
import org.datanucleus.metadata.FieldPersistenceModifier;
import org.datanucleus.metadata.IdentityType;
import org.datanucleus.sco.SCOUtils;
import org.datanucleus.store.FieldValues;
import org.datanucleus.store.StoreManager;
import org.datanucleus.store.fieldmanager.FieldManager;
import org.datanucleus.store.mapped.DatastoreClass;
import org.datanucleus.store.mapped.DatastoreContainerObject;
import org.datanucleus.store.mapped.DatastoreIdentifier;
import org.datanucleus.store.mapped.IdentifierFactory;
import org.datanucleus.store.mapped.StatementExpressionIndex;
import org.datanucleus.store.mapped.expression.QueryExpression;
import org.datanucleus.store.mapped.mapping.AbstractContainerMapping;
import org.datanucleus.store.mapped.mapping.EmbeddedElementPCMapping;
import org.datanucleus.store.mapped.mapping.JavaTypeMapping;
import org.datanucleus.store.mapped.mapping.Mappings;
import org.datanucleus.store.mapped.mapping.ReferenceMapping;
import org.datanucleus.store.query.ResultObjectFactory;
import org.datanucleus.util.ClassUtils;

/**
 * Representation of the store of an element-based container.
 * This is used to represent either a collection or an array.
 * There are 3 types of situation that we try to cater for with respect to elements.
 * <UL>
 * <LI><B>element-type</B> is PC with "new-table" or "superclass-table" inheritance. In this case we will have
 * <I>elementInfo</I> with 1 entry.</LI>
 * <LI><B>element-type</B> is PC with "subclass-table" inheritance. In this case we will have <I>elementInfo</I>
 * with "n" entries (1 for each subclass type with its own table). We also have <I>emd</I> being the MetaData
 * for the element-type.</LI>
 * <LI><B>element-type</B> is Reference type. In this case we will have <I>elementInfo</I> with "n" entries
 * (1 for each implementation type).</LI>
 * <LI><B>element-type</B> is non-PC. In this case we have no <I>elementInfo</I> and no <I>emd</I></LI>
 * </UL>
 */
public abstract class ElementContainerStore extends BaseContainerStore
{
    /** Flag to set whether the iterator statement will use a discriminator or not. */
    protected boolean iterateUsingDiscriminator = false;

    /**
     * Information for the elements of this container.
     * When the "element-type" table is new-table, or superclass-table then there is 1 value here.
     * When the "element-type" table uses subclass-table, or when it is a reference type then there can be multiple.
     */
    protected ElementInfo[] elementInfo;

    /** Inner class wrapping the information required for a valid element type. */
    public class ElementInfo
    {
        AbstractClassMetaData cmd; // MetaData for the element class
        DatastoreClass table; // Table storing the element

        /**
         * Constructor
         * @param cmd the AbstractClassMetaData
         * @param table the DatastoreClass
         */
        public ElementInfo(AbstractClassMetaData cmd, DatastoreClass table)
        {
            this.cmd = cmd;
            this.table = table;
        }

        /**
         * Accessor for the class name
         * @return the class name
         */
        public String getClassName()
        {
            return cmd.getFullClassName();
        }

        /**
         * Accessor for the AbstractClassMetaData
         * @return the AbstractClassMetaData
         */
        public AbstractClassMetaData getAbstractClassMetaData()
        {
            return cmd;
        }

        /**
         * Accessor for the table of the element
         * @return the DatastoreClass
         */
        public DatastoreClass getDatastoreClass()
        {
            return table;
        }

        /**
         * Accessor the discriminator strategy of the element
         * @return the strategy for the discriminator
         */
        public DiscriminatorStrategy getDiscriminatorStrategy()
        {
            return cmd.getDiscriminatorStrategy();
        }

        /**
         * Accessor the discriminator mapping of the element (in its table)
         * @return the JavaTypeMapping for the discriminator
         */
        public JavaTypeMapping getDiscriminatorMapping()
        {
            return table.getDiscriminatorMapping(false);
        }
    }

    /** MetaData for the "element-type" class. Not used for reference types since no metadata is present for the declared type. */
    protected AbstractClassMetaData emd;

    /** Table containing the link between owner and element. Not set when using FK relations. */
    protected DatastoreContainerObject containerTable;

    /** Mapping for the element. */
    protected JavaTypeMapping elementMapping;

    /** Type of the element. */
    protected String elementType;

    /** Whether the elements are embedded. */
    protected boolean elementsAreEmbedded;

    /** Whether the elements are serialised. */
    protected boolean elementsAreSerialised;

    /** Whether the element is of a persistent-interface (defined using "<interface>") type. */
    protected boolean elementIsPersistentInterface = false;

    /**
     * Mapping for an ordering column to allow for duplicates in the container.
     * Can also be used for ordering elements in a List/array.
     * Can also be used where we have an embedded object and so need to form the PK with something.
     */
    protected JavaTypeMapping orderMapping;

    /** Optional mapping to distinguish elements of one collection from another when sharing the join table. */
    protected JavaTypeMapping relationDiscriminatorMapping;

    /** Value to use to discriminate between elements of this collection from others using the same join table. */
    protected String relationDiscriminatorValue;

    /** Identifier for elements in JDOQL queries. */
    protected final DatastoreIdentifier elmIdentifier;

    /** ClassLoader resolver. */
    protected ClassLoaderResolver clr;

    /** Association strategy. */
    protected final ElementContainerStoreSpecialization elementContainerStoreSpecialization;

    /**
     * Constructor.
     * @param storeMgr Manager for the store
     * @param clr ClassLoader resolver
     */
    protected ElementContainerStore(StoreManager storeMgr, ClassLoaderResolver clr, ElementContainerStoreSpecialization elementContainerStoreSpecialization)
    {
        super(storeMgr);
        this.clr = clr;

        elmIdentifier = this.storeMgr.getIdentifierFactory().newIdentifier(IdentifierFactory.TABLE, "ELEMENT");

        this.elementContainerStoreSpecialization = elementContainerStoreSpecialization;
    }

    /**
     * Convenience method to find the element information relating to the element type.
     * Used specifically for the "element-type" of a collection/array to find the elements
     * which have table information. Not used for reference types.
     * @return Element information relating to the element type
     */
    protected ElementInfo[] getElementInformationForClass()
    {
        ElementInfo[] info = null;
        DatastoreClass tbl;
        String[] clsNames;
        if (!clr.classForName(elementType).isInterface())
        {
            tbl = storeMgr.getDatastoreClass(elementType, clr);
            clsNames = new String[] {elementType};
        }
        else
        {
            clsNames = storeMgr.getOMFContext().getMetaDataManager().getClassesImplementingInterface(elementType, clr);
            tbl = storeMgr.getDatastoreClass(clsNames[0], clr);
        }
        if (tbl == null)
        {
            AbstractClassMetaData[] subclassCmds = storeMgr.getClassesManagingTableForClass(emd, clr);
            info = new ElementInfo[subclassCmds.length];
            for (int i=0;i<subclassCmds.length;i++)
            {
                DatastoreClass table = storeMgr.getDatastoreClass(subclassCmds[i].getFullClassName(), clr);
                info[i] = new ElementInfo(subclassCmds[i], table);
            }
        }
        else
        {
            info = new ElementInfo[clsNames.length];
            for (int i=0; i<clsNames.length; i++)
            {
                AbstractClassMetaData cmd = storeMgr.getOMFContext().getMetaDataManager().getMetaDataForClass(clsNames[i], clr);
                DatastoreClass table = storeMgr.getDatastoreClass(cmd.getFullClassName(), clr);
                info[i] = new ElementInfo(cmd, table);
            }
        }
        return info;
    }

    /**
     * Accessor for whether the store has an order mapping, to allow for duplicates or ordering.
     * @return Whether an order mapping is present.
     */
    public boolean hasOrderMapping()
    {
        return (orderMapping != null);
    }

    /**
     * Accessor for the element type stored in this container.
     * @return The element type.
     **/
    public String getElementType()
    {
        return elementType;
    }

    /**
     * Method to validate an element against the accepted type.
     * @param clr The ClassLoaderResolver
     * @param element The element to validate
     * @return Whether it is valid.
     **/ 
    protected boolean validateElementType(ClassLoaderResolver clr, Object element)
    {
        if (element == null)
        {
            return true;
        }

        Class primitiveElementClass = ClassUtils.getPrimitiveTypeForType(element.getClass());
        if (primitiveElementClass != null)
        {
            
            // Allow for the element type being primitive, and the user wanting to store its wrapper
            String elementTypeWrapper = elementType;
            Class elementTypeClass = clr.classForName(elementType);
            if (elementTypeClass.isPrimitive())
            {
                elementTypeWrapper = ClassUtils.getWrapperTypeForPrimitiveType(elementTypeClass).getName();
            }
            return clr.isAssignableFrom(elementTypeWrapper, element.getClass());
        }
        return clr.isAssignableFrom(elementType, element.getClass());
    }

    /**
     * Method to check if an element is already persistent or is persistent but managed by 
     * a different persistence manager.
     * @param sm The state manager of this owner
     * @param element The element
     * @return Whether it is valid for reading.
     */
    protected boolean validateElementForReading(StateManager sm, Object element)
    {
        if (!validateElementType(sm.getObjectManager().getClassLoaderResolver(), element))
        {
            return false;
        }

        if (element != null && !elementsAreEmbedded && !elementsAreSerialised)
        {
            ObjectManager om = sm.getObjectManager();
            if ((!om.getApiAdapter().isPersistent(element) ||
                 om != ObjectManagerHelper.getObjectManager(element)) && !om.getApiAdapter().isDetached(element))
            {
                return false;
            }
        }

        return true;
    }

    /**
     * Method to check if an element is already persistent, or is managed by a different
     * Persistencemanager. If not persistent, this will persist it.
     * @param sm The state manager of this owner
     * @param element The element
     * @param fieldValues any initial field values to use if persisting the element
     * @return Whether the element was persisted during this call
     */
    protected boolean validateElementForWriting(StateManager sm, Object element, FieldValues fieldValues)
    {
        // Check the element type for this collection
        if (!elementIsPersistentInterface &&
            !validateElementType(sm.getObjectManager().getClassLoaderResolver(), element))
        {
            throw new ClassCastException(LOCALISER.msg("056033", element.getClass().getName(), 
                ownerMemberMetaData.getFullFieldName(), elementType));
        }

        boolean persisted = false;
        if (elementsAreEmbedded || elementsAreSerialised)
        {
            // Element is embedded/serialised so has no id
        }
        else
        {
            ObjectManager om = sm.getObjectManager();
            StateManager elementSM = om.findStateManager(element);
            if (elementSM != null && elementSM.isEmbedded())
            {
                // Element is already with StateManager and is embedded in another field!
                throw new NucleusUserException(LOCALISER.msg("056028", 
                    ownerMemberMetaData.getFullFieldName(), element));
            }

            persisted = SCOUtils.validateObjectForWriting(om, element, fieldValues);
        }
        return persisted;
    }

    /**
     * Convenience method to populate the passed PreparedStatement with the value for the element.
     * Not used with embedded PC elements.
     * @param om Object Manager
     * @param ps The PreparedStatement
     * @param element The element
     * @param jdbcPosition Position in JDBC statement to populate
     * @return The next position in the JDBC statement
     */
    public int populateElementInStatement(ObjectManager om, Object ps, Object element, int jdbcPosition)
    {
        if (!storeMgr.insertValuesOnInsert(elementMapping.getDataStoreMapping(0)))
        {
            // Dont try to insert any mappings with insert parameter that isnt ? (e.g Oracle)
            return jdbcPosition;
        }
        elementMapping.setObject(om, ps, Mappings.getParametersIndex(jdbcPosition, elementMapping), element);
        return jdbcPosition + elementMapping.getNumberOfDatastoreFields();
    }

    /**
     * Convenience method to populate the passed PreparedStatement with the value for the order index.
     * @param om Object Manager
     * @param ps The PreparedStatement
     * @param idx The order value
     * @param jdbcPosition Position in JDBC statement to populate
     * @return The next position in the JDBC statement
     */
    protected int populateOrderInStatement(ObjectManager om, Object ps, int idx, int jdbcPosition)
    {
        orderMapping.setObject(om, ps, Mappings.getParametersIndex(jdbcPosition, orderMapping), new Integer(idx));
        return jdbcPosition + orderMapping.getNumberOfDatastoreFields();
    }


    /**
     * Convenience method to populate the passed PreparedStatement with the field values from
     * the embedded element starting at the specified jdbc position.
     * @param sm State Manager of the owning container
     * @param element The embedded element
     * @param ps The PreparedStatement
     * @param jdbcPosition JDBC position in the statement to start at
     * @param ownerFieldMetaData The meta data for the owner field
     * @return The next JDBC position
     */
    public int populateEmbeddedElementFieldsInStatement(StateManager sm,
                                                           Object element,
                                                           Object ps,
                                                           int jdbcPosition,
                                                           AbstractMemberMetaData ownerFieldMetaData)
    {
        EmbeddedElementPCMapping embeddedMapping = (EmbeddedElementPCMapping)elementMapping;
        StatementExpressionIndex[] statementExpressionIndex = 
            new StatementExpressionIndex[emd.getNoOfManagedMembers() + emd.getNoOfInheritedManagedMembers()];
        int[] elementFieldNumbers = new int[embeddedMapping.getNumberOfJavaTypeMappings()];
        for (int i=0;i<embeddedMapping.getNumberOfJavaTypeMappings();i++)
        {
            JavaTypeMapping fieldMapping = embeddedMapping.getJavaTypeMapping(i);
            int absFieldNum = emd.getAbsolutePositionOfMember(fieldMapping.getFieldMetaData().getName());
            elementFieldNumbers[i] = absFieldNum;
            if (fieldMapping != null)
            {
                statementExpressionIndex[absFieldNum] = new StatementExpressionIndex();
                statementExpressionIndex[absFieldNum].setMapping(fieldMapping);
                int[] jdbcParamPositions = new int[fieldMapping.getNumberOfDatastoreFields()];
                for (int j=0;j<fieldMapping.getNumberOfDatastoreFields();j++)
                {
                    jdbcParamPositions[j] = jdbcPosition++;
                }
                statementExpressionIndex[absFieldNum].setParameterIndex(jdbcParamPositions);
            }
        }

        StateManager elementSM = getStateManagerForEmbeddedPCObject(sm, element, ownerFieldMetaData);
        elementSM.setPcObjectType(StateManager.EMBEDDED_COLLECTION_ELEMENT_PC);
        FieldManager fm = storeMgr.getFieldManagerForStatementGeneration(elementSM, ps, 
            statementExpressionIndex, true);
        elementSM.provideFields(elementFieldNumbers, fm);

        return jdbcPosition;
    }

    /**
     * Accessor for an iterator through the container elements.
     * @param ownerSM State Manager for the container.
     * @return The Iterator
     */
    public abstract Iterator iterator(StateManager ownerSM);

    /**
     * Clear the association from owner to all elements.
     * Provides cascade-delete when the elements being deleted are PC types.
     * @param ownerSM State Manager for the container. 
     */
    public void clear(StateManager ownerSM)
    {
        Collection dependentElements = null;
        CollectionMetaData collmd = ownerMemberMetaData.getCollection();
        if (collmd.isDependentElement() && !collmd.isEmbeddedElement() && !collmd.isSerializedElement())
        {
            // Retain the dependent elements that need deleting after clearing
            dependentElements = new HashSet();
            Iterator iter = iterator(ownerSM);
            while (iter.hasNext())
            {
                dependentElements.add(iter.next());
            }
        }
        elementContainerStoreSpecialization.executeClear(ownerSM, this);

        // Cascade-delete
        if (dependentElements != null && dependentElements.size() > 0)
        {
            Iterator iter = dependentElements.iterator();
            while (iter.hasNext())
            {
                Object obj = iter.next();
                if (ownerSM.getObjectManager().getApiAdapter().isDeleted(obj))
                {
                    // Element is tagged for deletion so will be deleted at flush(), and we dont need it immediately
                }
                else
                {
                    ownerSM.getObjectManager().deleteObjectInternal(obj);
                }
            }
        }
    }


    /**
     * Method to return the size of the container.
     * @param sm The state manager.
     * @return The size.
     **/
    public int size(StateManager sm)
    {
        return elementContainerStoreSpecialization.getSize(sm, this);
    }

    // ----------------------------- Query Methods --------------------------------

    /**
     * Method to generate a new result object factory from which to retrieve element objects.
     * @param sm State Manager for owner
     * @param stmt The query
     * @param ignoreCache Whether to ignore the cache
     * @param useFetchPlan Whether to use the current FetchPlan
     * @return The Result object factory
     */
    public ResultObjectFactory newResultObjectFactory(StateManager sm,
            QueryExpression stmt, boolean ignoreCache, boolean useFetchPlan)
    {
        ClassLoaderResolver clr = sm.getObjectManager().getClassLoaderResolver();
        // TODO Allow for more than just the first elementTable (currently take the columns to select from the first element table only)
        if (elementsAreEmbedded || elementsAreSerialised)
        {
            return storeMgr.newResultObjectFactory(null , null, emd, null, null, null, ignoreCache, false,
                stmt.hasMetaDataExpression(), null, clr.classForName(elementType));
        }
        else if (elementMapping instanceof ReferenceMapping)
        {
            // Element = Reference (Interface/Object)
            // TODO Respect any fetch plan for the implementation class
            // This selects the id column(s) in the join table of all implementations of the reference type
            // It is processed by ReferenceMapping where it decides which of the implementation types is stored in this row.
            JavaTypeMapping[] implMappings = ((ReferenceMapping)elementMapping).getJavaTypeMapping();
            for (int i=0;i<implMappings.length;i++)
            {
                stmt.select(implMappings[i]);
            }
            return storeMgr.newResultObjectFactory(elementInfo != null ? elementInfo[0].getDatastoreClass() : null, null, emd, 
                    null, null, null, ignoreCache, false, 
                    stmt.hasMetaDataExpression(), null, clr.classForName(elementType));
        }
        else
        {
            // Element = PC
            int[] datastoreIndex = null;
            int[] versionIndex = null;

            // Select any datastore/version columns
            if (stmt.getTableExpression(elmIdentifier) != null)
            {
                if (elementInfo[0].getDatastoreClass().getIdentityType() == IdentityType.DATASTORE)
                {
                    datastoreIndex = stmt.select(elmIdentifier, elementInfo[0].getDatastoreClass().getDataStoreObjectIdMapping(), true);
                }
                JavaTypeMapping verMapping = elementInfo[0].getDatastoreClass().getVersionMapping(true);
                if (verMapping != null)
                {
                    versionIndex = stmt.select(elmIdentifier, verMapping, true);
                }
            }
            else
            {
                if (elementInfo[0].getDatastoreClass().getIdentityType() == IdentityType.DATASTORE)
                {
                    datastoreIndex = stmt.select(stmt.getMainTableAlias(), 
                        elementInfo[0].getDatastoreClass().getDataStoreObjectIdMapping(),true);
                }
                JavaTypeMapping verMapping = elementInfo[0].getDatastoreClass().getVersionMapping(true);
                if (verMapping != null)
                {
                    versionIndex = stmt.select(stmt.getMainTableAlias(), verMapping, true);
                }
            }

            StatementExpressionIndex[] statementExpressionIndex = null;

            // Start with PK fields (if any)
            int[] prefetchFieldNumbers = null;
            int[] pkFieldNumbers = null;
            if (emd.getIdentityType() == IdentityType.APPLICATION)
            {
                pkFieldNumbers = new int[emd.getPKMemberPositions().length];
                for (int i=0;i<pkFieldNumbers.length;i++)
                {
                    pkFieldNumbers[i] = emd.getPKMemberPositions()[i];
                }
            }
            if (useFetchPlan)
            {
                // Add on any FetchPlan fields
                FetchPlan fp = sm.getObjectManager().getFetchPlan();
                fp.manageFetchPlanForClass(emd);
                FetchPlanForClass fpc = fp.getFetchPlanForClass(emd);
                int fpFieldNumbers[] = fpc.getFieldsInActualFetchPlan();

                if (pkFieldNumbers != null)
                {
                    // Merge FP and PK fields
                    int totalFieldCount = pkFieldNumbers.length + fpFieldNumbers.length;
                    for (int i=0;i<pkFieldNumbers.length;i++)
                    {
                        if (Arrays.binarySearch(fpFieldNumbers, pkFieldNumbers[i]) >= 0)
                        {
                            totalFieldCount--; // Already got this as a PK field
                        }
                    }

                    int prefetchNum = 0;
                    prefetchFieldNumbers = new int[totalFieldCount];
                    for (int i=0;i<pkFieldNumbers.length;i++)
                    {
                        prefetchFieldNumbers[prefetchNum++] = pkFieldNumbers[i];
                    }
                    for (int i=0;i<fpFieldNumbers.length;i++)
                    {
                        if (Arrays.binarySearch(pkFieldNumbers, fpFieldNumbers[i]) < 0)
                        {
                            prefetchFieldNumbers[prefetchNum++] = fpFieldNumbers[i];
                        }
                    }
                }
                else
                {
                    prefetchFieldNumbers = fpFieldNumbers;
                }
            }
            else
            {
                if (pkFieldNumbers != null)
                {
                    prefetchFieldNumbers = pkFieldNumbers;
                }
                else
                {
                    prefetchFieldNumbers = new int[0];
                }
            }

            // Populate the StatementExpressionIndex for all fields to be fetched, 
            // eliminating non-persistent and container fields
            int fn[] = new int[prefetchFieldNumbers.length];
            int prefetchFieldCount = 0;
            statementExpressionIndex = new StatementExpressionIndex[
                emd.getNoOfInheritedManagedMembers() + emd.getNoOfManagedMembers()];
            for (int i=0; i<prefetchFieldNumbers.length; ++i)
            {
                AbstractMemberMetaData fmd = 
                    emd.getMetaDataForManagedMemberAtAbsolutePosition(prefetchFieldNumbers[i]);
                if (fmd.getPersistenceModifier() == FieldPersistenceModifier.PERSISTENT)
                {
                    JavaTypeMapping m = elementInfo[0].getDatastoreClass().getFieldMapping(fmd);
                    if (m != null && m.includeInFetchStatement() && !(m instanceof AbstractContainerMapping))
                    {
                        // Field is not a container, and is to be fetched (eliminates fields as FKs in other class)
                        statementExpressionIndex[prefetchFieldNumbers[i]] = new StatementExpressionIndex();
                        statementExpressionIndex[prefetchFieldNumbers[i]].setMapping(m);
                        fn[prefetchFieldCount++] = prefetchFieldNumbers[i];
                    }
                }
            }

            int[] fieldNumbers = new int[prefetchFieldCount];
            System.arraycopy(fn, 0, fieldNumbers, 0, prefetchFieldCount);
            if (stmt.getTableExpression(elmIdentifier) != null)
            {
                Mappings.selectMapping(stmt, elmIdentifier, statementExpressionIndex);
            }
            else
            {
                Mappings.selectMapping(stmt, statementExpressionIndex);
            }

            return storeMgr.newResultObjectFactory(elementInfo != null ? elementInfo[0].getDatastoreClass() : null,
                fieldNumbers, emd, statementExpressionIndex, datastoreIndex, versionIndex,
                ignoreCache, iterateUsingDiscriminator,
                stmt.hasMetaDataExpression(), null, clr.classForName(elementType));
        }
    }

    public ElementInfo[] getElementInfo()
    {
        return elementInfo;
    }

    public JavaTypeMapping getElementMapping()
    {
        return elementMapping;
    }

    public JavaTypeMapping getOrderMapping()
    {
        return orderMapping;
    }

    public JavaTypeMapping getRelationDiscriminatorMapping()
    {
        return relationDiscriminatorMapping;
    }

    public String getRelationDiscriminatorValue()
    {
        return relationDiscriminatorValue;
    }

    public DatastoreContainerObject getContainerTable()
    {
        return containerTable;
    }

}
