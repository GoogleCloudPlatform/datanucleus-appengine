/******************************************************************
Copyright (c) 2004 Andy Jefferson and others. All rights reserved. 
Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
 

Contributors:
2004 Erik Bengtson - added datastore mapping accessors
    ...
*****************************************************************/
package org.datanucleus.store.mapped.mapping;

import org.datanucleus.ClassLoaderResolver;
import org.datanucleus.metadata.AbstractMemberMetaData;
import org.datanucleus.metadata.ColumnMetaData;
import org.datanucleus.plugin.PluginManager;
import org.datanucleus.store.mapped.DatastoreAdapter;
import org.datanucleus.store.mapped.DatastoreContainerObject;
import org.datanucleus.store.mapped.DatastoreField;
import org.datanucleus.store.mapped.MappedStoreManager;

/**
 * Representation of a MappingManager, mapping a java mapping type to a datastore mapping type.
 * Allows a java mapping type to map to multiple datastore mapping types.
 * Allows a default datastore mapping type be assigned to each java mapping type.
 * 
 * @version $Revision: 1.29 $
 */
public interface MappingManager
{
    /**
     * Initialise the datastore mapping. 
     * @param mgr the PlyginManager
     * @param clr the ClassLoaderResolver
     * @param vendorId the datastore vendor id
     */
    void loadDatastoreMapping(PluginManager mgr, ClassLoaderResolver clr, String vendorId);

    // --------------------------------------------- Java Types ---------------------------------------------

    /**
     * Accessor for a mapping, for a java type.
     * @param c The java type
     * @param serialised Whether the type is serialised
     * @param embedded Whether the type is embedded
     * @param storeMgr Manager for the datastore
     * @param fieldName Name of the field (for logging only)
     * @return The mapping
     */
    JavaTypeMapping getMapping(Class c, boolean serialised, boolean embedded, MappedStoreManager storeMgr, 
            String fieldName);

    /**
     * Accessor for a mapping, for a java type.
     * @param c The java type
     * @param serialised Whether the type is serialised
     * @param embedded Whether the type is embedded
     * @param storeMgr Manager of the store
     * @param clr ClassLoader resolver
     * @return The mapping
     */
    JavaTypeMapping getMapping(Class c, boolean serialised, boolean embedded, MappedStoreManager storeMgr, 
            ClassLoaderResolver clr);

    /**
     * Accessor for a mapping for a field, mapped to a table
     * @param table The table
     * @param fmd MetaData for the field
     * @param dba Datastore adapter
     * @param clr ClassLoader resolver
     * @param mappingFieldType Field type for the mapping
     * @return The mapping
     */
    JavaTypeMapping getMapping(DatastoreContainerObject table, AbstractMemberMetaData fmd, 
            DatastoreAdapter dba, ClassLoaderResolver clr, int mappingFieldType);

    // ----------------------------------------- Datastore Types ---------------------------------------------

    /**
     * Method to create the datastore mapping for a java type mapping at a particular index.
     * @param mapping The java mapping
     * @param fmd MetaData for the field
     * @param index Index of the datastore field
     * @param srm Store Manager
     * @param column The column
     * @return The datastore mapping
     */
    DatastoreMapping createDatastoreMapping(JavaTypeMapping mapping, AbstractMemberMetaData fmd, int index, 
            MappedStoreManager srm, DatastoreField column);

    /**
     * Method to create the datastore mapping for a particular column and java type.
     * @param mapping The java mapping
     * @param storeMgr Store Manager
     * @param column The column
     * @param javaType The java type (isnt this stored in the java mapping ?)
     * @return The datastore mapping
     */
    DatastoreMapping createDatastoreMapping(JavaTypeMapping mapping, MappedStoreManager storeMgr, 
            DatastoreField column, String javaType);

    /**
     * Method to create a datastore field (column) in a container (table).
     * @param mapping The java mapping
     * @param javaType The java type
     * @param datastoreFieldIndex The index of the datastore field to create
     * @return The datastore field
     */
    DatastoreField createDatastoreField(JavaTypeMapping mapping, String javaType, int datastoreFieldIndex);

    /**
     * Method to create a datastore field (column) in a container (table).
     * To be used for serialised PC element/key/value in a join table.
     * @param mapping The java mapping
     * @param javaType The java type
     * @param colmd MetaData for the column to create
     * @return The datastore field
     */
    DatastoreField createDatastoreField(JavaTypeMapping mapping, String javaType, ColumnMetaData colmd);

    /**
     * Method to create a datastore field for a PersistenceCapable mapping.
     * @param fmd MetaData for the field
     * @param datastoreContainer The container in the datastore
     * @param mapping The java mapping
     * @param colmd MetaData for the column to create
     * @param reference The field to reference
     * @param clr ClassLoader resolver
     * @return The datastore field
     */
    DatastoreField createDatastoreField(AbstractMemberMetaData fmd, DatastoreContainerObject datastoreContainer, 
            JavaTypeMapping mapping, ColumnMetaData colmd, DatastoreField reference, ClassLoaderResolver clr);

    /**
     * Utility to register a datastore mapping for a java type, and the SQL/JDBC types it can be mapped to.
     * This can also be called to change the default setting of a mapping - just supply the same
     * values of java/JDBC/SQL types and a different default value
     * @param javaTypeName Name of the java type
     * @param datastoreMappingType The datastore mapping
     * @param jdbcType The JDBC type that can be used
     * @param sqlType The SQL type that can be used
     * @param dflt Whether this type should be used as the default mapping for this Java type
     */
    void registerDatastoreMapping(String javaTypeName, Class datastoreMappingType, String jdbcType, 
            String sqlType, boolean dflt);
}