package javax.persistence;

public interface OrderByItem
{

}
