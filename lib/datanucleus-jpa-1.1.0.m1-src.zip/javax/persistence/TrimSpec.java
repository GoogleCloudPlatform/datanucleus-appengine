package javax.persistence;

public enum TrimSpec {
    LEADING, TRAILING, BOTH 
}
