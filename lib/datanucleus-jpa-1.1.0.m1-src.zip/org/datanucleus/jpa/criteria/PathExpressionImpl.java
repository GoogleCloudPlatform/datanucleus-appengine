/**********************************************************************
Copyright (c) 2009 Andy Jefferson and others. All rights reserved.
Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.

Contributors:
    ...
**********************************************************************/
package org.datanucleus.jpa.criteria;

import javax.persistence.Aggregate;
import javax.persistence.Expression;
import javax.persistence.PathExpression;
import javax.persistence.Predicate;
import javax.persistence.Subquery;
import javax.persistence.TrimSpec;

/**
 * Implementation of a JPA PathExpression.
 */
public class PathExpressionImpl implements PathExpression
{
    /* (non-Javadoc)
     * @see javax.persistence.PathExpression#avg()
     */
    public Aggregate avg()
    {
        // TODO Auto-generated method stub
        return null;
    }

    /* (non-Javadoc)
     * @see javax.persistence.PathExpression#count()
     */
    public Aggregate count()
    {
        // TODO Auto-generated method stub
        return null;
    }

    /* (non-Javadoc)
     * @see javax.persistence.PathExpression#get(java.lang.String)
     */
    public PathExpression get(String attributeName)
    {
        // TODO Auto-generated method stub
        return null;
    }

    /* (non-Javadoc)
     * @see javax.persistence.PathExpression#isEmpty()
     */
    public Predicate isEmpty()
    {
        // TODO Auto-generated method stub
        return null;
    }

    /* (non-Javadoc)
     * @see javax.persistence.PathExpression#max()
     */
    public Aggregate max()
    {
        // TODO Auto-generated method stub
        return null;
    }

    /* (non-Javadoc)
     * @see javax.persistence.PathExpression#min()
     */
    public Aggregate min()
    {
        // TODO Auto-generated method stub
        return null;
    }

    /* (non-Javadoc)
     * @see javax.persistence.PathExpression#size()
     */
    public Expression size()
    {
        // TODO Auto-generated method stub
        return null;
    }

    /* (non-Javadoc)
     * @see javax.persistence.PathExpression#sum()
     */
    public Aggregate sum()
    {
        // TODO Auto-generated method stub
        return null;
    }

    /* (non-Javadoc)
     * @see javax.persistence.PathExpression#type()
     */
    public Expression type()
    {
        // TODO Auto-generated method stub
        return null;
    }

    /* (non-Javadoc)
     * @see javax.persistence.Expression#abs()
     */
    public Expression abs()
    {
        // TODO Auto-generated method stub
        return null;
    }

    /* (non-Javadoc)
     * @see javax.persistence.Expression#concat(java.lang.String[])
     */
    public Expression concat(String... str)
    {
        // TODO Auto-generated method stub
        return null;
    }

    /* (non-Javadoc)
     * @see javax.persistence.Expression#concat(javax.persistence.Expression[])
     */
    public Expression concat(Expression... str)
    {
        // TODO Auto-generated method stub
        return null;
    }

    /* (non-Javadoc)
     * @see javax.persistence.Expression#dividedBy(java.lang.Number)
     */
    public Expression dividedBy(Number num)
    {
        // TODO Auto-generated method stub
        return null;
    }

    /* (non-Javadoc)
     * @see javax.persistence.Expression#dividedBy(javax.persistence.Expression)
     */
    public Expression dividedBy(Expression expr)
    {
        // TODO Auto-generated method stub
        return null;
    }

    /* (non-Javadoc)
     * @see javax.persistence.Expression#in(java.lang.String[])
     */
    public Predicate in(String... strings)
    {
        // TODO Auto-generated method stub
        return null;
    }

    /* (non-Javadoc)
     * @see javax.persistence.Expression#in(java.lang.Number[])
     */
    public Predicate in(Number... nums)
    {
        // TODO Auto-generated method stub
        return null;
    }

    /* (non-Javadoc)
     * @see javax.persistence.Expression#in(java.lang.Enum<?>[])
     */
    public Predicate in(Enum<?>... enums)
    {
        // TODO Auto-generated method stub
        return null;
    }

    /* (non-Javadoc)
     * @see javax.persistence.Expression#in(java.lang.Class[])
     */
    public Predicate in(Class... classes)
    {
        // TODO Auto-generated method stub
        return null;
    }

    /* (non-Javadoc)
     * @see javax.persistence.Expression#in(javax.persistence.Expression[])
     */
    public Predicate in(Expression... params)
    {
        // TODO Auto-generated method stub
        return null;
    }

    /* (non-Javadoc)
     * @see javax.persistence.Expression#in(javax.persistence.Subquery)
     */
    public Predicate in(Subquery subquery)
    {
        // TODO Auto-generated method stub
        return null;
    }

    /* (non-Javadoc)
     * @see javax.persistence.Expression#isNull()
     */
    public Predicate isNull()
    {
        // TODO Auto-generated method stub
        return null;
    }

    /* (non-Javadoc)
     * @see javax.persistence.Expression#length()
     */
    public Expression length()
    {
        // TODO Auto-generated method stub
        return null;
    }

    /* (non-Javadoc)
     * @see javax.persistence.Expression#locate(java.lang.String)
     */
    public Expression locate(String str)
    {
        // TODO Auto-generated method stub
        return null;
    }

    /* (non-Javadoc)
     * @see javax.persistence.Expression#locate(javax.persistence.Expression)
     */
    public Expression locate(Expression str)
    {
        // TODO Auto-generated method stub
        return null;
    }

    /* (non-Javadoc)
     * @see javax.persistence.Expression#locate(java.lang.String, int)
     */
    public Expression locate(String str, int position)
    {
        // TODO Auto-generated method stub
        return null;
    }

    /* (non-Javadoc)
     * @see javax.persistence.Expression#locate(java.lang.String, javax.persistence.Expression)
     */
    public Expression locate(String str, Expression position)
    {
        // TODO Auto-generated method stub
        return null;
    }

    /* (non-Javadoc)
     * @see javax.persistence.Expression#locate(javax.persistence.Expression, int)
     */
    public Expression locate(Expression str, int position)
    {
        // TODO Auto-generated method stub
        return null;
    }

    /* (non-Javadoc)
     * @see javax.persistence.Expression#locate(javax.persistence.Expression, javax.persistence.Expression)
     */
    public Expression locate(Expression str, Expression position)
    {
        // TODO Auto-generated method stub
        return null;
    }

    /* (non-Javadoc)
     * @see javax.persistence.Expression#lower()
     */
    public Expression lower()
    {
        // TODO Auto-generated method stub
        return null;
    }

    /* (non-Javadoc)
     * @see javax.persistence.Expression#member(javax.persistence.PathExpression)
     */
    public Predicate member(PathExpression arg)
    {
        // TODO Auto-generated method stub
        return null;
    }

    /* (non-Javadoc)
     * @see javax.persistence.Expression#minus()
     */
    public Expression minus()
    {
        // TODO Auto-generated method stub
        return null;
    }

    /* (non-Javadoc)
     * @see javax.persistence.Expression#minus(java.lang.Number)
     */
    public Expression minus(Number num)
    {
        // TODO Auto-generated method stub
        return null;
    }

    /* (non-Javadoc)
     * @see javax.persistence.Expression#minus(javax.persistence.Expression)
     */
    public Expression minus(Expression expr)
    {
        // TODO Auto-generated method stub
        return null;
    }

    /* (non-Javadoc)
     * @see javax.persistence.Expression#mod(int)
     */
    public Expression mod(int num)
    {
        // TODO Auto-generated method stub
        return null;
    }

    /* (non-Javadoc)
     * @see javax.persistence.Expression#mod(javax.persistence.Expression)
     */
    public Expression mod(Expression expr)
    {
        // TODO Auto-generated method stub
        return null;
    }

    /* (non-Javadoc)
     * @see javax.persistence.Expression#plus(java.lang.Number)
     */
    public Expression plus(Number num)
    {
        // TODO Auto-generated method stub
        return null;
    }

    /* (non-Javadoc)
     * @see javax.persistence.Expression#plus(javax.persistence.Expression)
     */
    public Expression plus(Expression expr)
    {
        // TODO Auto-generated method stub
        return null;
    }

    /* (non-Javadoc)
     * @see javax.persistence.Expression#sqrt()
     */
    public Expression sqrt()
    {
        // TODO Auto-generated method stub
        return null;
    }

    /* (non-Javadoc)
     * @see javax.persistence.Expression#substring(int)
     */
    public Expression substring(int start)
    {
        // TODO Auto-generated method stub
        return null;
    }

    /* (non-Javadoc)
     * @see javax.persistence.Expression#substring(javax.persistence.Expression)
     */
    public Expression substring(Expression start)
    {
        // TODO Auto-generated method stub
        return null;
    }

    /* (non-Javadoc)
     * @see javax.persistence.Expression#substring(int, int)
     */
    public Expression substring(int start, int len)
    {
        // TODO Auto-generated method stub
        return null;
    }

    /* (non-Javadoc)
     * @see javax.persistence.Expression#substring(int, javax.persistence.Expression)
     */
    public Expression substring(int start, Expression len)
    {
        // TODO Auto-generated method stub
        return null;
    }

    /* (non-Javadoc)
     * @see javax.persistence.Expression#substring(javax.persistence.Expression, int)
     */
    public Expression substring(Expression start, int len)
    {
        // TODO Auto-generated method stub
        return null;
    }

    /* (non-Javadoc)
     * @see javax.persistence.Expression#substring(javax.persistence.Expression, javax.persistence.Expression)
     */
    public Expression substring(Expression start, Expression len)
    {
        // TODO Auto-generated method stub
        return null;
    }

    /* (non-Javadoc)
     * @see javax.persistence.Expression#times(java.lang.Number)
     */
    public Expression times(Number num)
    {
        // TODO Auto-generated method stub
        return null;
    }

    /* (non-Javadoc)
     * @see javax.persistence.Expression#times(javax.persistence.Expression)
     */
    public Expression times(Expression expr)
    {
        // TODO Auto-generated method stub
        return null;
    }

    /* (non-Javadoc)
     * @see javax.persistence.Expression#trim()
     */
    public Expression trim()
    {
        // TODO Auto-generated method stub
        return null;
    }

    /* (non-Javadoc)
     * @see javax.persistence.Expression#trim(javax.persistence.TrimSpec)
     */
    public Expression trim(TrimSpec spec)
    {
        // TODO Auto-generated method stub
        return null;
    }

    /* (non-Javadoc)
     * @see javax.persistence.Expression#trim(char)
     */
    public Expression trim(char c)
    {
        // TODO Auto-generated method stub
        return null;
    }

    /* (non-Javadoc)
     * @see javax.persistence.Expression#trim(char, javax.persistence.TrimSpec)
     */
    public Expression trim(char c, TrimSpec spec)
    {
        // TODO Auto-generated method stub
        return null;
    }

    /* (non-Javadoc)
     * @see javax.persistence.Expression#trim(javax.persistence.Expression)
     */
    public Expression trim(Expression expr)
    {
        // TODO Auto-generated method stub
        return null;
    }

    /* (non-Javadoc)
     * @see javax.persistence.Expression#trim(javax.persistence.Expression, javax.persistence.TrimSpec)
     */
    public Expression trim(Expression expr, TrimSpec spec)
    {
        // TODO Auto-generated method stub
        return null;
    }

    /* (non-Javadoc)
     * @see javax.persistence.Expression#upper()
     */
    public Expression upper()
    {
        // TODO Auto-generated method stub
        return null;
    }
}