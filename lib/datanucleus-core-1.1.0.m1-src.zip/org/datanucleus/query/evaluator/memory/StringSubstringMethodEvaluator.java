/**********************************************************************
Copyright (c) 2008 Andy Jefferson and others. All rights reserved.
Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.

Contributors:
    ...
**********************************************************************/
package org.datanucleus.query.evaluator.memory;

import org.datanucleus.ObjectManagerFactoryImpl;
import org.datanucleus.exceptions.NucleusException;
import org.datanucleus.query.expression.InvokeExpression;
import org.datanucleus.query.expression.Literal;
import org.datanucleus.util.Localiser;

/**
 * Evaluator for the method "{stringExpr}.substring(stringExpr [,pos])".
 */
public class StringSubstringMethodEvaluator implements InvocationEvaluator
{
    /** Localisation utility for output messages */
    protected static final Localiser LOCALISER = Localiser.getInstance("org.datanucleus.Localisation",
        ObjectManagerFactoryImpl.class.getClassLoader());

    /* (non-Javadoc)
     * @see org.datanucleus.query.evaluator.memory.InvocationEvaluator#evaluate(org.datanucleus.query.expression.InvokeExpression, org.datanucleus.query.evaluator.memory.InMemoryExpressionEvaluator)
     */
    public Object evaluate(InvokeExpression expr, Object invokedValue, InMemoryExpressionEvaluator eval)
    {
        String method = expr.getOperation();

        if (invokedValue == null)
        {
            return null;
        }
        if (!(invokedValue instanceof String))
        {
            throw new NucleusException(LOCALISER.msg("021011", method, invokedValue.getClass().getName()));
        }
        int arg1 = -1;
        int arg2 = -1;
        Literal param1 = (Literal)expr.getParameters().get(0);
        if (param1.getLiteral() instanceof Number)
        {
            arg1 = ((Number)param1.getLiteral()).intValue();
        }
        String result = null;
        if (expr.getParameters().size() == 2)
        {
            Literal param2 = (Literal)expr.getParameters().get(1);
            if (param2.getLiteral() instanceof Number)
            {
                arg2 = ((Number)param2.getLiteral()).intValue();
            }
            result = ((String)invokedValue).substring(arg1, arg2);
        }
        else
        {
            result = ((String)invokedValue).substring(arg1);
        }

        return result;
    }

    /* (non-Javadoc)
     * @see org.datanucleus.query.evaluator.memory.InvocationEvaluator#supportsType(java.lang.Class)
     */
    public boolean supportsType(Class cls)
    {
        if (cls == null)
        {
            return false;
        }
        return String.class.isAssignableFrom(cls);
    }
}