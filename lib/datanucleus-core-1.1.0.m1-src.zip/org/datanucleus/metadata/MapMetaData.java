/**********************************************************************
Copyright (c) 2004 Andy Jefferson and others. All rights reserved.
Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
 

Contributors:
2004 Erik Bengtson - add dependent keys and values
    ...
**********************************************************************/
package org.datanucleus.metadata;

import java.security.AccessController;
import java.security.PrivilegedAction;
import java.util.List;
import java.util.Set;

import org.datanucleus.ClassLoaderResolver;
import org.datanucleus.api.ApiAdapter;
import org.datanucleus.exceptions.ClassNotResolvedException;
import org.datanucleus.exceptions.NucleusUserException;
import org.datanucleus.util.ClassUtils;
import org.datanucleus.util.NucleusLogger;
import org.datanucleus.util.StringUtils;

/**
 * Representation of the Meta-Data for a Map.
 */
public class MapMetaData extends ContainerMetaData
{
    /** Representation of the key of the map. */
    protected ContainerComponent key;

    /** Representation of the value of the map. */
    protected ContainerComponent value;

    /**
     * Constructor to create a copy of the passed metadata.
     * @param mapmd The metadata to copy
     */
    public MapMetaData(MapMetaData mapmd)
    {
        key = new ContainerComponent();
        key.embedded = mapmd.key.embedded;
        key.serialized = mapmd.key.serialized;
        key.dependent = mapmd.key.dependent;
        key.type = mapmd.key.type;
        key.classMetaData = mapmd.key.classMetaData;

        value = new ContainerComponent();
        value.embedded = mapmd.value.embedded;
        value.serialized = mapmd.value.serialized;
        value.dependent = mapmd.value.dependent;
        value.type = mapmd.value.type;
        value.classMetaData = mapmd.value.classMetaData;
    }

    /**
     * Default constructor. Set the fields using setters, before populate().
     */
    public MapMetaData()
    {
        key = new ContainerComponent();
        value = new ContainerComponent();
    }

    /**
     * Method to populate any defaults, and check the validity of the MetaData.
     * @param clr ClassLoaderResolver to use for loading any key/value types 
     * @param primary the primary ClassLoader to use (or null)
     */
    public void populate(ClassLoaderResolver clr, ClassLoader primary)
    {
        AbstractMemberMetaData mmd = (AbstractMemberMetaData)parent;
        if (!StringUtils.isWhitespace(key.type) && key.type.indexOf(',') > 0)
        {
            throw new InvalidMetaDataException(LOCALISER, "044143", mmd.getName(), mmd.getClassName());
        }
        if (!StringUtils.isWhitespace(value.type) && value.type.indexOf(',') > 0)
        {
            throw new InvalidMetaDataException(LOCALISER, "044144", mmd.getName(), mmd.getClassName());
        }

        ApiAdapter api = getMetaDataManager().getApiAdapter();

        // Make sure the type in "key", "value" is set
        key.populate(((AbstractMemberMetaData)parent).getAbstractClassMetaData().getPackageName(), 
            clr, primary);
        value.populate(((AbstractMemberMetaData)parent).getAbstractClassMetaData().getPackageName(), 
            clr, primary);

        // Check the field type and see if it is castable to a Map
        Class field_type = getMemberMetaData().getType();
        if (!java.util.Map.class.isAssignableFrom(field_type))
        {
            throw new InvalidMetaDataException(LOCALISER,
                    "044145",
                    getFieldName(),getMemberMetaData().getClassName(false));
        }

        // "key-type"
        if (key.type == null)
        {
            throw new InvalidMetaDataException(LOCALISER,
                    "044146",
                    getFieldName(),getMemberMetaData().getClassName(false));
        }

        // Check that the key type exists
        Class keyTypeClass = null;
        try
        {
            keyTypeClass = clr.classForName(key.type, primary);
        }
        catch (ClassNotResolvedException cnre)
        {
            try
            {
                // Maybe the user specified a java.lang class without fully-qualifying it
                // This is beyond the scope of the JDO spec which expects java.lang cases to be fully-qualified
                keyTypeClass = clr.classForName(ClassUtils.getJavaLangClassForType(key.type), primary);
            }
            catch (ClassNotResolvedException cnre2)
            {
                throw new InvalidMetaDataException(LOCALISER,
                    "044147",
                    getFieldName(),getMemberMetaData().getClassName(false),
                    key.type);
            }
        }

        if (!keyTypeClass.getName().equals(key.type))
        {
            // The value-type has been resolved from what was specified in the MetaData - update to the fully-qualified name
            NucleusLogger.METADATA.info(LOCALISER.msg("044148", getFieldName(), getMemberMetaData().getClassName(false), 
                key.type, keyTypeClass.getName()));
            key.type = keyTypeClass.getName();
        }

        // "embedded-key"
        if (key.embedded == null)
        {
            // Assign default for "embedded-key" based on 18.13.2 of JDO 2 spec
            if (getMetaDataManager().getOMFContext().getTypeManager().isDefaultEmbeddedType(keyTypeClass))
            {
                key.embedded = Boolean.TRUE;
            }
            else if (api.isPersistable(keyTypeClass) ||
                Object.class.isAssignableFrom(keyTypeClass) ||
                keyTypeClass.isInterface())
            {
                key.embedded = Boolean.FALSE;
            }
            else
            {
                key.embedded = Boolean.TRUE;
            }
        }
        if (key.embedded == Boolean.FALSE)
        {
            // If the user has set a non-PC/non-Interface as not embedded, correct it since not supported.
            // Note : this fails when using in the enhancer since not yet PC
            if (!api.isPersistable(keyTypeClass) && !keyTypeClass.isInterface() &&
                keyTypeClass != java.lang.Object.class)
            {
                key.embedded = Boolean.TRUE;
            }
        }
        KeyMetaData keymd = ((AbstractMemberMetaData)parent).getKeyMetaData();
        if (keymd != null && keymd.getEmbeddedMetaData() != null)
        {
            // If the user has specified <embedded>, set to true
            key.embedded = Boolean.TRUE;
        }

        // "value-type"
        if (value.type == null)
        {
            throw new InvalidMetaDataException(LOCALISER, "044149",  getFieldName(),
                getMemberMetaData().getClassName(false));
        }

        // Check that the value-type exists
        Class valueTypeClass = null;
        try
        {
            valueTypeClass = clr.classForName(value.type);
        }
        catch (ClassNotResolvedException cnre)
        {
            try
            {
                // Maybe the user specified a java.lang class without fully-qualifying it
                // This is beyond the scope of the JDO spec which expects java.lang cases to be fully-qualified
                valueTypeClass = clr.classForName(ClassUtils.getJavaLangClassForType(value.type));
            }
            catch (ClassNotResolvedException cnre2)
            {
                throw new InvalidMetaDataException(LOCALISER, "044150", getFieldName(),
                    getMemberMetaData().getClassName(false), value.type);
            }
        }

        if (!valueTypeClass.getName().equals(value.type))
        {
            // The value-type has been resolved from what was specified in the MetaData - update to the fully-qualified name
            NucleusLogger.METADATA.info(LOCALISER.msg("044151", getFieldName(), getMemberMetaData().getClassName(false),
                value.type, valueTypeClass.getName()));
            value.type = valueTypeClass.getName();
        }

        // "embedded-value"
        if (value.embedded == null)
        {
            // Assign default for "embedded-value" based on 18.13.2 of JDO 2 spec
            if (getMetaDataManager().getOMFContext().getTypeManager().isDefaultEmbeddedType(valueTypeClass))
            {
                value.embedded = Boolean.TRUE;
            }
            else if (api.isPersistable(valueTypeClass) ||
                Object.class.isAssignableFrom(valueTypeClass) ||
                valueTypeClass.isInterface())
            {
                value.embedded = Boolean.FALSE;
            }
            else
            {
                value.embedded = Boolean.TRUE;
            }
        }
        if (value.embedded == Boolean.FALSE)
        {
            // If the user has set a non-PC/non-Interface as not embedded, correct it since not supported.
            // Note : this fails when using in the enhancer since not yet PC
            if (!api.isPersistable(valueTypeClass) && !valueTypeClass.isInterface() &&
                valueTypeClass != java.lang.Object.class)
            {
                value.embedded = Boolean.TRUE;
            }
        }
        ValueMetaData valuemd = ((AbstractMemberMetaData)parent).getValueMetaData();
        if (valuemd != null && valuemd.getEmbeddedMetaData() != null)
        {
            // If the user has specified <embedded>, set to true
            value.embedded = Boolean.TRUE;
        }

        key.classMetaData = getMemberMetaData().getAbstractClassMetaData().getMetaDataManager().getMetaDataForClassInternal(keyTypeClass, clr);
        value.classMetaData = getMemberMetaData().getAbstractClassMetaData().getMetaDataManager().getMetaDataForClassInternal(valueTypeClass, clr);

        // Cater for Key with mapped-by needing to be PK (for JPA)
        if (keymd != null && keymd.mappedBy != null && keymd.mappedBy.equals("#PK")) // Special value set by JPAMetaDataHandler
        {
            // Need to set the mapped-by of <key> to be the PK of the <value>
            if (value.classMetaData.getNoOfPrimaryKeyMembers() != 1)
            {
                // TODO Localise this
                throw new NucleusUserException("DataNucleus does not support use of <map-key> with no name field when the" +
                    " value class has a composite primary key");
            }
            int[] valuePkFieldNums = value.classMetaData.getPKMemberPositions();
            keymd.mappedBy = value.classMetaData.getMetaDataForManagedMemberAtAbsolutePosition(valuePkFieldNums[0]).name;
        }

        setPopulated();
    }

    // ----------------------------- Accessors ---------------------------------

    /**
     * Accessor for the key-type tag value.
     * May be comma-separated if several key types are possible.
     * @return key-type tag value
     */
    public String getKeyType()
    {
        return key.type;
    }

    /**
     * Accessor for the Key ClassMetaData
     * @return key ClassMetaData
     */
    public AbstractClassMetaData getKeyClassMetaData()
    {
        return key.classMetaData;
    }

    /**
     * Initialize the key and values metadata
     */
    public void initialise(final ClassLoaderResolver clr)
    {
        super.initialise(clr);
        if (key.classMetaData != null && !key.classMetaData.isInitialised() && !key.classMetaData.initialising)
        {
            // Do as PrivilegedAction since uses reflection
            // [JDOAdapter.isValidPrimaryKeyClass calls reflective methods]
            AccessController.doPrivileged(new PrivilegedAction()
            {
                public Object run()
                {
                    key.classMetaData.initialise(clr);
                    return null;
                }
            });
        }
        if (value.classMetaData != null && !value.classMetaData.isInitialised() && !value.classMetaData.initialising)
        {
            // Do as PrivilegedAction since uses reflection
            // [JDOAdapter.isValidPrimaryKeyClass calls reflective methods]
            AccessController.doPrivileged(new PrivilegedAction()
            {
                public Object run()
                {
                    value.classMetaData.initialise(clr);
                    return null;
                }
            });
        }
    }
    
    /**
     * Accessor for the value-type tag value.
     * May be comma-separated if several value types are possible.
     * @return value-type tag value
     */
    public String getValueType()
    {
        return value.type;
    }

    /**
     * Accessor for the Value ClassMetaData
     * @return value ClassMetaData
     */
    public AbstractClassMetaData getValueClassMetaData()
    {
        return value.classMetaData;
    }

    /**
     * Accessor for the embedded-key tag value.
     * @return embedded-key tag value
     */
    public boolean isEmbeddedKey()
    {
        if (key.embedded == null)
        {
            return false;
        }
        else
        {
            return key.embedded.booleanValue();
        }
    }

    /**
     * Accessor for the embedded-value tag value.
     * @return embedded-value tag value
     */
    public boolean isEmbeddedValue()
    {
        if (value.embedded == null)
        {
            return false;
        }
        else
        {
            return value.embedded.booleanValue();
        }
    }

    /**
     * Accessor for the serialized-key tag value.
     * @return serialized-key tag value
     */
    public boolean isSerializedKey()
    {
        if (key.serialized == null)
        {
            return false;
        }
        else
        {
            return key.serialized.booleanValue();
        }
    }

    /**
     * Accessor for the serialized-value tag value.
     * @return serialized-value tag value
     */
    public boolean isSerializedValue()
    {
        if (value.serialized == null)
        {
            return false;
        }
        else
        {
            return value.serialized.booleanValue();
        }
    }

    /**
     * Accessor for the dependent-key attribute indicates that the map's
     * key contains references that are to be deleted if the referring instance is deleted.
     * @return dependent-key tag value
     */
    public boolean isDependentKey()
    {
        if (key.dependent == null)
        {
            return false;
        }
        else if (key.classMetaData == null)
        {
            return false;
        }
        else
        {
            return key.dependent.booleanValue();
        }
    }

    /**
     * Accessor for the dependent-value attribute indicates that the
     * map's value contains references that are to be deleted if the
     * referring instance is deleted.
     * @return dependent-value tag value
     */
    public boolean isDependentValue()
    {
        if (value.dependent == null)
        {
            return false;
        }
        else if (value.classMetaData == null)
        {
            return false;
        }
        else
        {
            return value.dependent.booleanValue();
        }
    }

    public MapMetaData setKeyType(String type)
    {
        key.setType(type);
        return this;
    }

    public MapMetaData setEmbeddedKey(String embedded)
    {
        key.setEmbedded(embedded);
        return this;
    }

    public MapMetaData setEmbeddedKey(boolean embedded)
    {
        key.setEmbedded(embedded);
        return this;
    }

    public MapMetaData setSerializedKey(String serialized)
    {
        key.setSerialized(serialized);
        return this;
    }

    public MapMetaData setSerializedKey(boolean serialized)
    {
        key.setSerialized(serialized);
        return this;
    }

    public MapMetaData setDependentKey(String dependent)
    {
        key.setDependent(dependent);
        return this;
    }

    public MapMetaData setDependentKey(boolean dependent)
    {
        key.setDependent(dependent);
        return this;
    }

    public MapMetaData setValueType(String type)
    {
        value.setType(type);
        return this;
    }

    public MapMetaData setEmbeddedValue(String embedded)
    {
        value.setEmbedded(embedded);
        return this;
    }

    public MapMetaData setEmbeddedValue(boolean embedded)
    {
        value.setEmbedded(embedded);
        return this;
    }

    public MapMetaData setSerializedValue(String serialized)
    {
        value.setSerialized(serialized);
        return this;
    }

    public MapMetaData setSerializedValue(boolean serialized)
    {
        value.setSerialized(serialized);
        return this;
    }

    public MapMetaData setDependentValue(String dependent)
    {
        value.setDependent(dependent);
        return this;
    }

    public MapMetaData setDependentValue(boolean dependent)
    {
        value.setDependent(dependent);
        return this;
    }

    // ----------------------------- Utilities ---------------------------------
 
    /**
     * Accessor for all ClassMetaData referenced by this array.
     * @param orderedCMDs List of ordered ClassMetaData objects (added to).
     * @param referencedCMDs Set of all ClassMetaData objects (added to).
     * @param clr the ClassLoaderResolver 
     */
    void getReferencedClassMetaData(final List orderedCMDs, final Set referencedCMDs,
            final ClassLoaderResolver clr) 
    {
        AbstractClassMetaData key_cmd=getMetaDataManager().getMetaDataForClass(key.type,clr);
        if (key_cmd != null)
        {
            key_cmd.getReferencedClassMetaData(orderedCMDs, referencedCMDs, clr);
        }

        AbstractClassMetaData value_cmd=getMetaDataManager().getMetaDataForClass(value.type,clr);
        if (value_cmd != null)
        {
            value_cmd.getReferencedClassMetaData(orderedCMDs, referencedCMDs, clr);
        }
    }

    /**
     * Returns a string representation of the object.
     * @param prefix prefix string
     * @param indent indent string
     * @return a string representation of the object.
     */
    public String toString(String prefix,String indent)
    {
        StringBuffer sb = new StringBuffer();
        sb.append(prefix).append("<map key-type=\"").append(key.type).append("\" value-type=\"").append(value.type).append("\"");
        if (key.embedded != null)
        {
            sb.append(" embedded-key=\"").append(key.embedded).append("\"");
        }
        if (value.embedded != null)
        {
            sb.append(" embedded-value=\"").append(value.embedded).append("\"");
        }
        if (key.dependent != null)
        {
            sb.append(" dependent-key=\"").append(key.dependent).append("\"");
        }
        if (value.dependent != null)
        {
            sb.append(" dependent-value=\"").append(value.dependent).append("\"");
        }
        if (key.serialized != null)
        {
            sb.append(" serialized-key=\"").append(key.serialized).append("\"");
        }
        if (value.serialized != null)
        {
            sb.append(" serialized-value=\"").append(value.serialized).append("\"");
        }
        sb.append(">\n");

        // Add extensions
        sb.append(super.toString(prefix + indent,indent));

        sb.append(prefix).append("</map>\n");
        return sb.toString();
    }
}