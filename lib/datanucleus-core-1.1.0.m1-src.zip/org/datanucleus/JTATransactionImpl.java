/**********************************************************************
Copyright (c) 2006 Jorg von Frantzius and others. All rights reserved.
Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.

Contributors:
2006 Andy Jefferson - localised, adapted to latest CVS
2007 GUido Anzuoni - move TX Manager lookup to OMFContext
2008 J�rg von Frantzius - Fix bugs and test with JBOSS 4.0.3
    ...
**********************************************************************/
package org.datanucleus;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.transaction.NotSupportedException;
import javax.transaction.RollbackException;
import javax.transaction.Status;
import javax.transaction.Synchronization;
import javax.transaction.SystemException;
import javax.transaction.TransactionManager;
import javax.transaction.UserTransaction;

import org.datanucleus.exceptions.TransactionActiveOnBeginException;
import org.datanucleus.exceptions.TransactionNotActiveException;
import org.datanucleus.transaction.NucleusTransactionException;
import org.datanucleus.util.NucleusLogger;

/**
 * A transaction that is synchronized with a Java Transaction Service (JTA) transaction.
 * Works only in a J2EE environments where a TranactionManager is present
 * <p>
 * When this feature is turned on, transactions must be controlled using javax.transaction.UserTransaction,
 * not e.g. using PM.currentTransaction().begin(). Should also work for SessionBeans, as 
 * per spec UserTransaction reflects SessionBean-based tx demarcation. 
 * 
 * {@link org.datanucleus.Transaction}
 * TODO Merge functionality with JTAJCATransactionImpl when Joerg/Erik document what each are providing.
 */
public class JTATransactionImpl extends TransactionImpl implements Synchronization 
{
    /** TransactionManager. **/
    private TransactionManager tm;

    /** JTA transaction we currently are synchronized with. Null when there is no JTA transaction active or not yet detected. */
    private javax.transaction.Transaction jtaTx;

    private boolean registeredSync = false;

    private boolean rollingback = false;

    /**
     * Constructor.
     * @param om Object Manager
     */
    JTATransactionImpl(ObjectManager om)
    {
        super(om);
        // tell the TransactionManager to not do anything with the actual datastore connection
        // as it is managed by the JTA (commit(), rollback() etc)
        om.getOMFContext().getTransactionManager().setContainerManagedConnections(true);
        joinTransaction();
    }

    /**
     * Accessor for whether the transaction is active.
     * @return Whether the transaction is active.
     **/
    public boolean isActive()
    {
        boolean isActive = super.isActive();
        // we can rely on super.isActive() only if we had registered our Synchronization object:
        // when UT got marked for rollback before we could register sync, we cannot register
        // sync anymore and will set our state to active without registering sync
        if (isActive && registeredSync)
        {
            return true;
        }
        else 
        {
            joinTransaction();
            return super.isActive();
        }
    }
    
    /* 
     * "16.1.3 Stateless Session Bean with Bean Managed Transactions":
     * "acquiring a PersistenceManager
     * without beginning a UserTransaction results in the PersistenceManager being
     * able to manage transaction boundaries via begin, commit, and rollback methods on javax.
     * jdo.Transaction. The PersistenceManager will automatically begin the User-
     * Transaction during javax.jdo.Transaction.begin and automatically
     * commit the UserTransaction during javax.jdo.Transaction.commit"
     */
    public void begin()
    {
        joinTransaction();
        if (active)
        {
            throw new TransactionActiveOnBeginException(this);
        }

        UserTransaction utx;
        try
        {
            utx = getUserTransaction();
        }
        catch (NamingException e)
        {
            throw om.getApiAdapter().getExceptionForException("Failed to obtain UserTransaction", e);
        }
        
        try
        {
            utx.begin();
        }
        catch (NotSupportedException e)
        {
            throw om.getApiAdapter().getExceptionForException("Failed to begin UserTransaction", e);
        }
        catch (SystemException e)
        {
            throw om.getApiAdapter().getExceptionForException("Failed to begin UserTransaction", e);
        }

        // this will result in super.begin() being called
        joinTransaction();
    }

    /* 
	 * Allow UserTransaction demarcation
     */
    public void commit()
    {
        if (!active)
        {
            throw new TransactionNotActiveException();
        }

        UserTransaction utx;
        try
        {
            utx = getUserTransaction();
        }
        catch (NamingException e)
        {
            throw om.getApiAdapter().getExceptionForException("Failed to obtain UserTransaction", e);
        }
        
        try
        {
            utx.commit();
        }
        catch (Exception e)
        {
            throw om.getApiAdapter().getExceptionForException("Failed to commit UserTransaction", e);
        }

        // this will result in super.begin() being called
        joinTransaction();
    }

    /* 
	 * Allow UserTransaction demarcation
     */
    public void rollback()
    {
        if (!active)
        {
            throw new TransactionNotActiveException();
        }

        UserTransaction utx;
        try
        {
            utx = getUserTransaction();
        }
        catch (NamingException e)
        {
            throw om.getApiAdapter().getExceptionForException("Failed to obtain UserTransaction", e);
        }
        
        try
        {
            // this will result in afterCompletion() being called
            utx.rollback();
        }
        catch (Exception e)
        {
            throw om.getApiAdapter().getExceptionForException("Failed to rollback UserTransaction", e);
        }
    }
    
    /* 
	 * Allow UserTransaction demarcation
     */
    public void setRollbackOnly()
    {
        if (!active)
        {
            throw new TransactionNotActiveException();
        }

        UserTransaction utx;
        try
        {
            utx = getUserTransaction();
        }
        catch (NamingException e)
        {
            throw om.getApiAdapter().getExceptionForException("Failed to obtain UserTransaction", e);
        }
        
        try
        {
            // this will result in afterCompletion() being called
            utx.setRollbackOnly();
        }
        catch (Exception e)
        {
            throw om.getApiAdapter().getExceptionForException("Failed to rollback-only UserTransaction", e);
        }
    }
    
    // ------------------- Methods to get the JTA transaction for synchronising --------------------------

    /**
     * Synchronize our active state with that of the JTA tx, if it exists.
     * Look for an active JTA transaction. if there is one, begin() ourselves
     * and register synchronization. We must poll because there is no
     * way of getting notified of a newly begun transaction.<p>
     */
    private synchronized void joinTransaction()
    {       

        try
        {
            if (tm == null)
            {
                tm = obtainTransactionManager();
            }
            
            jtaTx = tm.getTransaction();
            
            if (jtaTx != null )
            {
                if (!om.getOMFContext().getPersistenceConfiguration().isJcaMode())
                {
                    try 
                    {
                        jtaTx.registerSynchronization(this);
                        registeredSync  = true;
                    } catch (RollbackException rb)
                    {
                        // thrown when the the jtaTx was marked for "rollback only" before
                        // we were able to call registerSynchronization()
                        markedForRollbackAction();
                        return;
                    }
                }
                
                if (!active && jtaTx.getStatus() == Status.STATUS_ACTIVE)
                {
    
                    //the transaction is active here
                    internalBegin();
                    return;
                }
                else if (rollbackOnly && jtaTx.getStatus() == Status.STATUS_ROLLEDBACK)
                {
                    // will see this only with XA: http://publib.boulder.ibm.com/infocenter/wsadhelp/v5r1m2/topic/com.sun.j2ee.api.doc/javax/transaction/Status.html#STATUS_ROLLEDBACK

                    rollback();
                } 
                else if (!rollbackOnly && jtaTx.getStatus() == Status.STATUS_MARKED_ROLLBACK)
                {
                    // jtaTx is marked for rollback, and by definition the jdo tx
                    // must be active in that case (so user can detect that it is 
                    // still active but did not finish successfully, so he can
                    // rollback the UserTransaction).
                    // begin() immediately wants to obtain a connection,
                    // which is not possible if jtaTx is marked for rollback:
                    // switch to active without connection,
                    markedForRollbackAction();
                    
                } else if ( rollbackOnly && jtaTx.getStatus() == Status.STATUS_NO_TRANSACTION )
                {
                    // If a transaction was marked for rollback before we could
                    // register synchronization, we won't be called back when it
                    // is rolled back. Seeing a STATUS_NO_TRANSACTION in combination
                    // with rollbackOnly tells us it had been rolled back in
                    // the meantime
                    rollback();
                }
            }
            else if (active && rollbackOnly && !rollingback) 
            {
                // the JTA tx got destroyed after being marked for rollback
                // without us having had the chance to catch up inbetween.
                // the following rollback will call isActive(), make sure
                // we don't infinite loop by coming here again during rollback()
                rollingback = true;
                try 
                {
                    super.rollback();
                }
                finally
                {
                    rollingback = false;
                    active = false;
                    rollbackOnly = false;
                    registeredSync = false;
                }
            }
        }
        catch (SystemException se)
        {
            throw new NucleusTransactionException(LOCALISER.msg("015026"), se);
        }
    }

    private void markedForRollbackAction()
    {
        // we can come here everytime e.g. isActive() is called while UT is marked for rollback,
        // guard call to setRollbackOnly() so it happens only once
        if (!rollbackOnly)
        {
            NucleusLogger.TRANSACTION.warn("UserTransaction is marked for rollback, probably had a timeout. Any subsequent " +
                    "operation requiring a database connection will fail.");
            active = true;
            super.setRollbackOnly();
            if (NucleusLogger.TRANSACTION.isDebugEnabled())
            {
                NucleusLogger.TRANSACTION.debug(LOCALISER.msg("Transaction.StartedForConnection"));
            }
        }
    }
    
    
    /**
     * Accessor for the JTA TransactionManager. Unfortunately, before J2EE 5 there is no specified way to do it, 
     * only appserver-specific ways. Taken from http://www.onjava.com/pub/a/onjava/2005/07/20/transactions.html.
     * <P>
     * In J2EE 5, we'll be able to use the following
     * https://glassfish.dev.java.net/nonav/javaee5/api/s1as-javadocs/javax/transaction/TransactionSynchronizationRegistry.html
     * @return The TransactionManager
     * @throws NucleusTransactionException if an error occurs obtaining the transaction manager
     */
    private TransactionManager obtainTransactionManager()
    {
        TransactionManager tm = om.getOMFContext().getJtaTransactionManager();
        if (tm == null)
        {
            throw new NucleusTransactionException(LOCALISER.msg("015030"));
        }
        else
        {
            return tm;
        }
    }
    
    private static boolean INSIDE_JBOSS = System.getProperty("jboss.server.name")!=null; 
    
    private UserTransaction getUserTransaction() throws NamingException
    {
        Context ctx = new InitialContext();
        UserTransaction ut;
        if (INSIDE_JBOSS)
        {
            // JBOSS unfortunately doesn't always provide UserTransaction at the J2EE standard location
            // see e.g. http://docs.jboss.org/admin-devel/Chap4.html
            ut = (UserTransaction) ctx.lookup("UserTransaction");
        }
        else
        {
            ut = (UserTransaction) ctx.lookup("java:comp/UserTransaction");
        }

        return ut;
    }
    
    
    // --------------------------- methods for javax.transaction.Synchronization -----------------------------

    /**
     * The beforeCompletion method is called by the transaction manager prior to the start of the two-phase 
     * transaction commit process.
     * This is not called in JCA mode
     */
    public void beforeCompletion()
    {
        try
        {
            internalPreCommit();
            flush();
        }
        catch (Throwable th)
        {
            // TODO Localise these messages
            NucleusLogger.TRANSACTION.error("Exception flushing work in JTA transaction. Mark for rollback", th);
            try
            {
                jtaTx.setRollbackOnly();
            }
            catch (Exception e)
            {
                NucleusLogger.TRANSACTION.fatal("Cannot mark transaction for rollback after exception in beforeCompletion. PersistenceManager might be in inconsistent state", e);
            }
        }
    }

    protected void internalRollback()
    {
     // prevent super from calling into TransactionManager
    }
    
    /**
     * This method is called by the transaction manager after the transaction is committed or rolled back.
     * Must be synchronized because some callees expect to be owner of this object's monitor (internalPostCommit() 
     * calls closeSQLConnection() which calls notifyAll()).
     * @param status The status
     */
    public synchronized void afterCompletion(int status)
    {
        try
        {
            if (status == Status.STATUS_ROLLEDBACK)
            {
                super.rollback();
            }
            else if (status == Status.STATUS_COMMITTED)
            {
                internalPostCommit();
            }
            else
            {
                // this method is called after*Completion*(), so we can expect not to be confronted with intermediate status codes
                // TODO Localise this
                NucleusLogger.TRANSACTION.fatal("Received unexpected transaction status + " + status);
            }
        }
        catch (Throwable th)
        {
            // TODO Localise this
            NucleusLogger.TRANSACTION.error("Exception during afterCompletion in JTA transaction. PersistenceManager might be in inconsistent state");
        }
        finally
        {
            // done with this jtaTx. Make us synchronizeWithJta() again,
            // as there there is no callback for a newly begun tx
            jtaTx = null;
            registeredSync = false;
        }
        if (active)
        {
            throw new NucleusTransactionException("internal error, must not be active after afterCompletion()!");
        }
    }   
}