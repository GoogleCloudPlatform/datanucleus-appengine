package org.datanucleus.metadata;

import org.datanucleus.ClassLoaderResolver;

/**
 * Lister Interface with operations invoked upon events in the MetaDataManager 
 */
public interface MetaDataManagerListener
{
    /**
     * Method invoked after a class/interface is initialised
     * @param cmd
     * @param clr
     */
    void postClassInitialised(AbstractClassMetaData cmd, ClassLoaderResolver clr);

    void postFileMetaDataLoaded(FileMetaData filemd, ClassLoaderResolver clr, ClassLoader primary);
    
}
