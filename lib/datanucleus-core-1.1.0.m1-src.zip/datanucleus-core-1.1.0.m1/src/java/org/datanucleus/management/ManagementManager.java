/**********************************************************************
Copyright (c) 2006 Erik Bengtson and others. All rights reserved.
Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.

Contributors:
     ...
***********************************************************************/
package org.datanucleus.management;

import org.datanucleus.OMFContext;
import org.datanucleus.exceptions.NucleusException;
import org.datanucleus.util.NucleusLogger;
import org.datanucleus.util.StringUtils;

/**
 * Management interface for JPOX. Management operations and attributes
 * are exposed through this interface that holds statistics linked to a PMF instance.
 * 
 * The mechanics for starting and stopping JMX servers are not defined here,
 * and must be done by plug-ins, by providing the implementation of
 * {@link ManagementServer}.
 * 
 * This Manager controls the lifecycle of management servers.
 * 
 * A management server is started when an instance of this class is created,
 * and its shutdown when the close operation is invoked
 * 
 * The management server startup is triggered when the Manager gets enabled.
 */
public class ManagementManager
{
    /** the ObjectManagerFactory context that owns this management **/
    final private OMFContext omfContext;
    
    /** whether this is closed **/
    private boolean closed = false;

    /** the Management Server **/
    private ManagementServer mgmtServer;
    
    /**
     * Constructor for Management
     * @param ctxt the ObjectManagerFactory context that we are operating for
     */
    public ManagementManager(OMFContext ctxt)
    {
        this.omfContext = ctxt;
        startManagementServer();
    }

    /**
     * Object the Management Server
     * @return the Management Server
     */
    public ManagementServer getManagementServer()
    {
        return mgmtServer;
    }

    /**
     * Whether this Manager is not closed
     * @return true if this Manager is open
     */
    public boolean isOpen()
    {
        return !closed;
    }

    /**
     * Close a instance.
     * @throws NucleusException if the manager is closed
     */
    public synchronized void close()
    {
        assertNotClosed();
        stopManagementServer();
        this.closed = true;
    }

    /**
     * Assert that this instance is open
     */
    private void assertNotClosed()
    {
        if (this.closed)
        {
            throw new NucleusException("Management instance is closed and cannot be used. You must adquire a new OMFContext").setFatal();
        }
    }

    /**
     * Start Management Server
     */
    private void startManagementServer()
    {
        if (mgmtServer == null)
        {
            try
            {
                mgmtServer = (ManagementServer) omfContext.getPluginManager().createExecutableExtension(
                    "org.datanucleus.management_server", "name", "default", "class", null, null);
                if (mgmtServer != null)
                {
                    NucleusLogger.MANAGEMENT.info("Starting Management Server");
                    mgmtServer.start();
                }
            }
            catch (Exception e)
            {
                mgmtServer = null;
                NucleusLogger.MANAGEMENT.error("Error instantiating or connecting to Management Server : " + 
                    StringUtils.getStringFromStackTrace(e));
            }
        }
    }
    
    /**
     * Shutdown Management Server
     */
    private void stopManagementServer()
    {
        if (mgmtServer != null)
        {
            NucleusLogger.MANAGEMENT.info("Stopping Management Server");
            mgmtServer.stop();
        }
    }
}